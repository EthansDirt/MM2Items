<?php
session_start();
if (!isset($_SESSION["userid"])) {
  echo "<script type='text/javascript'>window.top.location='./';</script>";
  exit();
}
$title = "Your Activity";
require_once("header.php");
?>
<main>
  <!-- Activity -->
  <section class="relative py-24">
    <picture class="pointer-events-none absolute inset-0 -z-10 dark:hidden">
      <img src="img/gradient_light.jpg" alt="gradient" class="h-full w-full" />
    </picture>
    <div class="container">
      <h1 class="font-display text-jacarta-700 py-16 text-center text-4xl font-medium dark:text-white">Activity</h1>

      <!-- Records / Filter -->
      <div class="lg:flex">
        <!-- Records -->
        <div class="mb-10 shrink-0 basis-8/12 space-y-5 lg:mb-0 lg:pr-10">


          <?php

          function time_elapsed_string($datetime, $full = false)
          {
            $now = new DateTime;
            $ago = new DateTime($datetime);
            $diff = $now->diff($ago);

            $diff->w = floor($diff->d / 7);
            $diff->d -= $diff->w * 7;

            $string = array(
              'y' => 'year',
              'm' => 'month',
              'w' => 'week',
              'd' => 'day',
              'h' => 'hour',
              'i' => 'minute',
              's' => 'second',
            );
            foreach ($string as $k => &$v) {
              if ($diff->$k) {
                $v = $diff->$k . ' ' . $v . ($diff->$k > 1 ? 's' : '');
              } else {
                unset($string[$k]);
              }
            }

            if (!$full) $string = array_slice($string, 0, 2);
            return $string ? implode(' ', $string) . ' ago' : 'just now';
          }

          foreach (array_reverse(getCurrentUserData()["History"], true) as $index => $history) {
            $type = $history["Type"];
            $t = $type;
            $gain = true;
            if ($type == "code") {
              $type = "Code Used";
              $name = "";
              $value = "Gained " . number_format($history["Gems"]) . " Points";
            } elseif ($type == "withdraw") {
              $type = "Withdrew";
              $name = "Gems";
              if ($history["Offer"]) {
                $name = $history["Offer"];
              }
              $gain = false;
              $value = "Cost: " . number_format($history["Gems"]) . " Points";
            } elseif ($type == "offer") {
              $type = "Offer Completed";
              $name = $history["Offer"];
              $value = "Gained " . number_format($history["Gems"]) . " Points";
            } elseif ($type == "referral") {
              $type = "Referral Earning";
              $name = $history["Offer"];
              $value = "Gained " . number_format($history["Gems"]) . " Points";
            }
            $time = time_elapsed_string($history["Date"]);
            if ($gain) {
              echo "<a class='$t dark:bg-jacarta-700 dark:border-jacarta-700 border-jacarta-100 relative flex items-center rounded-[1.25rem] border bg-white p-8 transition-shadow hover:shadow-lg'>
              <!--<figure class='mr-5 self-start'>
                <img src='img/avatars/avatar_2.png' alt='avatar 2' class='rounded-2lg' loading='lazy' />
              </figure>-->
  
              <div>
                <h3 class='font-display text-jacarta-700 mb-1 text-base font-semibold dark:text-white'>
                  $type $name</h3>
                <span class='text-jacarta-500 mb-3 block text-sm text-green'>$value</span>
                <span class='text-jacarta-300 block text-xs'>$time</span>
              </div>
  
              <div class='dark:border-jacarta-600 border-jacarta-100 ml-auto rounded-full border p-3'>
                <svg fill='#10B981' xmlns='http://www.w3.org/2000/svg' width='24' height='24' viewBox='0 0 24 24'>
                  <path d='M24 10h-10v-10h-4v10h-10v4h10v10h4v-10h10z' />
                </svg>
              </div>
            </a>";
            } else {
              echo "<a class='$t dark:bg-jacarta-700 dark:border-jacarta-700 border-jacarta-100 relative flex items-center rounded-[1.25rem] border bg-white p-8 transition-shadow hover:shadow-lg'>
            <!--<figure class='mr-5 self-start'>
              <img src='img/avatars/avatar_2.png' alt='avatar 2' class='rounded-2lg' loading='lazy' />
            </figure>-->

            <div>
              <h3 class='font-display text-jacarta-700 mb-1 text-base font-semibold dark:text-white'>
                $type $name</h3>
              <span class='text-jacarta-500 mb-3 block text-sm text-red'>$value</span>
              <span class='text-jacarta-300 block text-xs'>$time</span>
            </div>

            <div class='dark:border-jacarta-600 border-jacarta-100 ml-auto rounded-full border p-3'>
              <svg fill='#FF0000' xmlns='http://www.w3.org/2000/svg' width='24' height='24' viewBox='0 0 24 24'>
                <path d='M0 10h24v4h-24z' />
              </svg>
            </div>
          </a>";
            }
          }
          ?>
        </div>

        <script>
          function filter(type) {
            if (type == "all") {
              $(".withdraw").removeClass("hidden")
              $(".code").removeClass("hidden")
              $(".offer").removeClass("hidden")
              $(".referral").removeClass("hidden")
            }
            if (type == "withdraw") {
              $(".withdraw").removeClass("hidden")
              $(".code").addClass("hidden")
              $(".offer").addClass("hidden")
              $(".referral").addClass("hidden")
            }
            if (type == "code") {
              $(".withdraw").addClass("hidden")
              $(".code").removeClass("hidden")
              $(".offer").addClass("hidden")
              $(".referral").addClass("hidden")
            }
            if (type == "offer") {
              $(".withdraw").addClass("hidden")
              $(".code").addClass("hidden")
              $(".offer").removeClass("hidden")
              $(".referral").addClass("hidden")
            }
            if (type == "referral") {
              $(".withdraw").addClass("hidden")
              $(".code").addClass("hidden")
              $(".offer").addClass("hidden")
              $(".referral").removeClass("hidden")
            }
          }
        </script>

        <!-- Filters -->
        <aside class="basis-4/12 lg:pl-5">
          <form action="search" class="relative mb-12 block">
            <input type="search" class="text-jacarta-700 placeholder-jacarta-500 focus:ring-accent border-jacarta-100 w-full rounded-2xl border py-[0.6875rem] px-4 pl-10 dark:border-transparent dark:bg-white/[.15] dark:text-white dark:placeholder-white" placeholder="Search" />
            <button type="submit" class="absolute left-0 top-0 flex h-full w-12 items-center justify-center rounded-2xl">
              <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24" class="fill-jacarta-500 h-4 w-4 dark:fill-white">
                <path fill="none" d="M0 0h24v24H0z"></path>
                <path d="M18.031 16.617l4.283 4.282-1.415 1.415-4.282-4.283A8.96 8.96 0 0 1 11 20c-4.968 0-9-4.032-9-9s4.032-9 9-9 9 4.032 9 9a8.96 8.96 0 0 1-1.969 5.617zm-2.006-.742A6.977 6.977 0 0 0 18 11c0-3.868-3.133-7-7-7-3.868 0-7 3.132-7 7 0 3.867 3.132 7 7 7a6.977 6.977 0 0 0 4.875-1.975l.15-.15z"></path>
              </svg>
            </button>
          </form>

          <h3 class="font-display text-jacarta-500 mb-4 font-semibold dark:text-white">Filters</h3>
          <div class="flex flex-wrap">
            <button onclick="filter('offer')" class="dark:border-jacarta-600 dark:bg-jacarta-700 group dark:hover:bg-accent hover:bg-accent border-jacarta-100 mr-2.5 mb-2.5 inline-flex items-center rounded-xl border bg-white px-4 py-3 hover:border-transparent hover:text-white dark:text-white dark:hover:border-transparent">
              <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24" class="fill-jacarta-700 mr-2 h-4 w-4 group-hover:fill-white dark:fill-white">
                <path fill="none" d="M0 0h24v24H0z" />
                <path d="M6.5 2h11a1 1 0 0 1 .8.4L21 6v15a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1V6l2.7-3.6a1 1 0 0 1 .8-.4zM19 8H5v12h14V8zm-.5-2L17 4H7L5.5 6h13zM9 10v2a3 3 0 0 0 6 0v-2h2v2a5 5 0 0 1-10 0v-2h2z" />
              </svg>
              <span class="text-2xs font-medium">Earn</span>
            </button>
            <button onclick="filter('code')" class="dark:border-jacarta-600 dark:bg-jacarta-700 group dark:hover:bg-accent hover:bg-accent border-jacarta-100 mr-2.5 mb-2.5 inline-flex items-center rounded-xl border bg-white px-4 py-3 hover:border-transparent hover:text-white dark:text-white dark:hover:border-transparent">
              <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24" class="fill-jacarta-700 mr-2 h-4 w-4 group-hover:fill-white dark:fill-white">
                <path fill="none" d="M0 0h24v24H0z" />
                <path d="M10.9 2.1l9.899 1.415 1.414 9.9-9.192 9.192a1 1 0 0 1-1.414 0l-9.9-9.9a1 1 0 0 1 0-1.414L10.9 2.1zm.707 2.122L3.828 12l8.486 8.485 7.778-7.778-1.06-7.425-7.425-1.06zm2.12 6.364a2 2 0 1 1 2.83-2.829 2 2 0 0 1-2.83 2.829z" />
              </svg>
              <span class="text-2xs font-medium">Use Code</span>
            </button>
            <button onclick="filter('withdraw')" class="dark:border-jacarta-600 dark:bg-jacarta-700 group dark:hover:bg-accent hover:bg-accent border-jacarta-100 mr-2.5 mb-2.5 inline-flex items-center rounded-xl border bg-white px-4 py-3 hover:border-transparent hover:text-white dark:text-white dark:hover:border-transparent">
              <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24" class="fill-jacarta-700 mr-2 h-4 w-4 group-hover:fill-white dark:fill-white">
                <path fill="none" d="M0 0h24v24H0z" />
                <path d="M3 1a1 1 0 000 2h1.22l.305 1.222a.997.997 0 00.01.042l1.358 5.43-.893.892C3.74 11.846 4.632 14 6.414 14H15a1 1 0 000-2H6.414l1-1H14a1 1 0 00.894-.553l3-6A1 1 0 0017 3H6.28l-.31-1.243A1 1 0 005 1H3zM16 16.5a1.5 1.5 0 11-3 0 1.5 1.5 0 013 0zM6.5 18a1.5 1.5 0 100-3 1.5 1.5 0 000 3z" />
              </svg>
              <span class="text-2xs font-medium">Withdrawal</span>
            </button>
            <button onclick="filter('referral')" class="dark:border-jacarta-600 dark:bg-jacarta-700 group dark:hover:bg-accent hover:bg-accent border-jacarta-100 mr-2.5 mb-2.5 inline-flex items-center rounded-xl border bg-white px-4 py-3 hover:border-transparent hover:text-white dark:text-white dark:hover:border-transparent">
              <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24" class="fill-jacarta-700 mr-2 h-4 w-4 group-hover:fill-white dark:fill-white">
                <path fill="none" d="M0 0h24v24H0z" />
                <path d="M16.05 12.05L21 17l-4.95 4.95-1.414-1.414 2.536-2.537L4 18v-2h13.172l-2.536-2.536 1.414-1.414zm-8.1-10l1.414 1.414L6.828 6 20 6v2H6.828l2.536 2.536L7.95 11.95 3 7l4.95-4.95z" />
              </svg>
              <span class="text-2xs font-medium">Referral</span>
            </button>
            <button onclick="filter('all')" class="dark:border-jacarta-600 dark:bg-jacarta-700 group dark:hover:bg-accent hover:bg-accent border-jacarta-100 mr-2.5 mb-2.5 inline-flex items-center rounded-xl border bg-white px-4 py-3 hover:border-transparent hover:text-white dark:text-white dark:hover:border-transparent">
              <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24" class="fill-jacarta-700 mr-2 h-4 w-4 group-hover:fill-white dark:fill-white">
                <path fill="none" d="M0 0h24v24H0z" />
                <path fill-rule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clip-rule="evenodd" />
              </svg>
              <span class="text-2xs font-medium">All</span>
            </button>


          </div>
        </aside>
      </div>
    </div>
  </section>
  <!-- end activity -->
</main>

<?php
require_once("footer.php");
?>