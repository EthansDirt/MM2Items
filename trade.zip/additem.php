<?php
session_start();
include "commands.php";
if (!isset($_SESSION["userid"])) {
    jsonError("You are Not Logged In!");
}
if (getCurrentUserData()["Rank"] <= 0) {
    jsonError("You do not have permission to modify this!");
}
if (isset($_POST["price"]) and isset($_POST["name"]) and isset($_POST["img"]) and isset($_POST["gamename"]) and isset($_POST["game"])) {
    $img = $_POST["img"];
    $price = intval($_POST["price"]);
    $name = $conn->real_escape_string($_POST["name"]);
    $ign = $conn->real_escape_string($_POST["gamename"]);
    $game = "Murder Mystery 2";
    if ($_POST["game"] == "Adopt Me") {
        $game = "Adopt Me";
    }
    if ($_POST["game"] == "Clicker Simulator") {
        $game = "Clicker Simulator";
    }
    $a = newItem($ign,$game,$price,$img,$name);
    if (!$a) {
        jsonError($conn->error);
    }
    jsonError(false);
} else {
    jsonError("Feature Under Maintenance!");
}
?>