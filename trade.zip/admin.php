<?php
session_start();
include "commands.php";
if (!isset($_SESSION["userid"])) {
    jsonError("You are Not Logged In!");
}
if (getCurrentUserData()["Rank"] <= 0) {
    jsonError("You do not have permission to delete this!");
}
if (isset($_GET["id"])) {
    $_GET["id"] = urlencode($_GET["id"]);
    if ($_SESSION["userid"] == $_GET["id"]) {
        jsonError("You Can't un-admin Yourself");
    }
    if (!$conn->query("UPDATE `users` SET `Rank`=NOT(`Rank`) WHERE `UserId`='{$_GET['id']}'")) {
        jsonError($mysqli -> error);
    }
    jsonError(false,getUserData($_GET["id"])["Rank"] == 1 ? "Added as" : "Removed as");
} else {
    jsonError("Feature Under Maintenance!");
}
?>