<?php
include "commands.php";
if (isset($_GET["id"])) {
    $_GET["id"] = urlencode($_GET["id"]);
    $thumb = getThumbnail($_GET["id"]);
    if ($thumb) {
        jsonError(false, $thumb);
    }
    jsonError("Invalid UserId");
} elseif (isset($_GET["name"])) {
    $_GET["name"] = urlencode($_GET["name"]);
    if (strlen($_GET["name"]) < 3) {
        jsonError("Invalid Username");
    }
    $url = "https://api.roblox.com/users/get-by-username?username=" . $_GET["name"];

    $curl = curl_init($url);
    curl_setopt($curl, CURLOPT_URL, $url);
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
    $resp = curl_exec($curl);
    curl_close($curl);
    if (isset(json_decode($resp)->Id)) {
        $thumb = getThumbnail(json_decode($resp)->Id);
        if ($thumb) {
            jsonError(false, $thumb);
        } else {
            jsonError("Invalid UserId");
        }
    } else {
        jsonError("Invalid Username");
    }
} else {
    jsonError("Invalid Parameters");
}
?>