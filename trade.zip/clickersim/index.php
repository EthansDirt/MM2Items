<?php



/*use function PHPSTORM_META\type;

$load = sys_getloadavg();
if ($load[0] > 16) {
    header('HTTP/1.1 503 Too busy, try again later');
    die('{}');
}
require_once('../rate-limit.php');*/
if ($_SERVER['REMOTE_ADDR'] != "39.40.249.74") {
    echo $_SERVER['REMOTE_ADDR'];
    exit();
}

include "../commands.php";

$_POST = json_decode(file_get_contents("php://input"), true);



if (file_exists("data.json") == false) {

    $file = fopen("data.json", "w");

    fwrite($file, json_encode(array()));

    fclose($file);

}



function get_stock()

{

    $file = fopen("data.json", "r");

    $data = json_decode(fread($file, filesize("data.json")), true);

    fclose($file);

    return $data;

}



function set_stock($data)

{

    $file = fopen("data.json", "w");

    fwrite($file, json_encode($data));

    fclose($file);

}



if ($_POST and isset($_POST["condition"]) and isset($_POST["data"])) {

    if ($_POST["condition"] == "StockUpdate") {

        set_stock($_POST["data"]);

        jsonError(false);

    }

    if ($_POST["condition"] == "getWithdraws") {

        print(json_encode(getWithdraws("Clicker Simulator")));

        exit();

    }

    if ($_POST["condition"] == "completeWithdraw") {

        endWithdraw($_POST["data"],"Clicker Simulator",0);

        jsonError(false);

    }

    jsonError("Unknown Condition ".$_POST["condition"]);

}

jsonError("Invalid Input");

?>