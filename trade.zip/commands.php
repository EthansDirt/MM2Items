<?php

$servername = "localhost";

//RbxItems
if (strpos($_SERVER['SERVER_NAME'], "rbxitems") !== false) {
    $username = "bloxpuqq_bloxdbuser";
    $password = "BloxDB1";
    $database = "bloxpuqq_bloxdb";
}

//Localhost
if (strpos($_SERVER['SERVER_NAME'], "localhost") !== false) {
    $username = "bloxpuqq_bloxdbuser";
    $password = "BloxDB1";
    $database = "bloxpuqq_bloxdb";
}



$conn = new mysqli($servername, $username, $password, $database);



// Check connection

if ($conn->connect_error) {

    die("Connection failed: " . $conn->connect_error);
}



function jsonError($err, $message = false)
{
    echo json_encode(["Error" => $err, "Message" => $message]);
    exit();
}



if (isset($_SESSION["userid"])) {

    if (!$conn->query("SELECT * FROM `users` WHERE `UserId` = {$_SESSION['userid']}")->fetch_all()) {

        $conn->query("INSERT INTO `users`(`UserId`, `Username`) VALUES ('{$_SESSION['userid']}','{$_SESSION['username']}')");

        if (isset($_SESSION["ref"])) {
            
            $ref = $conn->query("SELECT `UserId` FROM `users` WHERE `RFC`='$_SESSION[ref]' OR `UserId` = '$_SESSION[ref]'")->fetch_assoc();
            if ($ref) {
                $conn->query("UPDATE `users` SET `Referrer`=$ref[UserId] WHERE `UserId`='{$_SESSION["userid"]}'");

                $conn->query("INSERT INTO `referral`(`Referee`, `Referrer`) VALUES ('{$_SESSION['userid']}','$ref[UserId]')");
            }
        }

        $_SESSION["ref"] = "";
    }
}



function getMM2Items()
{
    $out = [];
    global $conn;
    $c = $conn->query("SELECT * FROM `items` WHERE `Game`='Murder Mystery 2' ORDER BY `Price` DESC");
    while ($item = $c->fetch_assoc()) {
        $out[$item["DisplayName"]] = ["GameName" => $item["GameName"], "price" => intval($item["Price"]), "img" => urldecode($item["Image"])];
    }

    return $out;
}


function getAdoptMeItems()
{

    $out = [];
    global $conn;
    $c = $conn->query("SELECT * FROM `items` WHERE `Game`='Adopt Me' ORDER BY `Price` DESC");
    while ($item = $c->fetch_assoc()) {
        $out[$item["DisplayName"]] = ["GameName" => $item["GameName"], "price" => intval($item["Price"]), "img" => urldecode($item["Image"])];
    }

    return $out;
}

function getClickerSimItems()
{

    $out = [];
    global $conn;
    $c = $conn->query("SELECT * FROM `items` WHERE `Game`='Clicker Simulator' ORDER BY `Price` DESC");
    while ($item = $c->fetch_assoc()) {
        $out[$item["DisplayName"]] = ["GameName" => $item["GameName"], "price" => intval($item["Price"]), "img" => urldecode($item["Image"])];
    }

    return $out;
}

function getPetSimItems()
{

    $out = [];
    global $conn;
    $c = $conn->query("SELECT * FROM `items` WHERE `Game`='Pet Simulator X' ORDER BY `Price` DESC");
    while ($item = $c->fetch_assoc()) {
        $out[$item["DisplayName"]] = ["GameName" => $item["GameName"], "price" => intval($item["Price"]), "img" => urldecode($item["Image"])];
    }

    return $out;
}


function newItem($ign, $game, $price, $img, $name)
{
    global $conn;
    $img = urlencode($img);
    return $conn->query("INSERT INTO `items`(`GameName`, `Game`, `Price`, `Image`, `DisplayName`) VALUES ('$ign','$game','$price','$img','$name')");
}

function getUserData($id)

{

    global $conn;

    $result = $conn->query("SELECT * FROM `users` WHERE `UserId` = {$id}")->fetch_assoc();

    if (!$result) {

        return null;
    }

    $result["Referrals"] = $conn->query("SELECT * FROM `referral` WHERE `Referrer` = {$id}")->fetch_all();

    if (!$result["Referrals"]) {
        $result["Referrals"] = [];
    }

    foreach ($result["Referrals"] as $index => $value) {

        $result["Referrals"][$index] = $value[0];
    }

    $his = $conn->query("SELECT * FROM `history` WHERE `UserId` = {$id}");

    $result["History"] = [];

    while ($r = $his->fetch_assoc()) {

        $result["History"][$r["ID"]] = $r;
    }

    return $result;
}



function getUserName($id)

{

    global $conn;

    $result = $conn->query("SELECT `Username` FROM `users` WHERE `UserId` = {$id}")->fetch_all();

    if (!$result) {

        return null;
    }

    return $result[0][0];
}



function getGems($id)

{

    global $conn;

    $result = $conn->query("SELECT `Gems` FROM `users` WHERE `UserId` = {$id}")->fetch_all();

    if (!$result) {

        return null;
    }

    return $result[0][0];
}



function getThumbnail($id)

{

    $resp = file_get_contents("https://thumbnails.roblox.com/v1/users/avatar-headshot?userIds=" . $id . "&size=150x150&format=Png&isCircular=true");

    $resp = json_decode($resp, true);

    return $resp["data"][0]["imageUrl"];
}



function addGems($id, $count)
{

    global $conn;

    if ($count > 0) {

        $conn->query("UPDATE `users` SET `Gems`=`Gems`+{$count} WHERE `UserId`='{$id}'");
    } else {

        $count = $count * -1;

        $conn->query("UPDATE `users` SET `Gems`=`Gems`-{$count} WHERE `UserId`='{$id}'");
    }
}



function getWithdraws($game)
{

    global $conn;

    $result = $conn->query("SELECT * FROM `withdraws` WHERE `Game`='{$game}'");

    $outr = [];

    while ($r = $result->fetch_assoc()) {

        array_push($outr, [

            "UserId" => intval($r["UserId"]),

            "Items" => json_decode($r["Items"],true),

            "TID" => $r["TransactionID"]

        ]);
    }

    return $outr;
}



function existingWithdraw($id, $game)
{

    foreach (getWithdraws($game) as $index => $withdraw) {

        if ($withdraw["UserId"] == intval($id)) {

            return true;
        }
    }

    return false;
}



function newWithdraw($id, $game, $items)
{

    global $conn;

    if (existingWithdraw($id, $game)) {

        return false;
    }

    $items = json_encode($items);

    $conn->query("INSERT INTO `withdraws`(`UserId`, `Game`, `Items`, `TransactionID`) VALUES ('$id','$game','$items','$id')");

    return true;
}

function sendWithdrawDiscord($tid, $game, $newvalue, $stock)
{
    if ($game == "Murder Myster 2") {
        $d = '{
            "content": null,
            "embeds": [
              {
                "title": "Withdraw Complete",
                "color": 5832448,
                "fields": [
                  {
                    "name": "User",
                    "value": "USER",
                    "inline": true
                  },
                  {
                    "name": "Game",
                    "value": "Murder Mystery 2",
                    "inline": true
                  },
                  {
                    "name": "Item",
                    "value": "GEMS",
                    "inline": true
                  }
                ]
              }
            ]
          }';

        $d = json_decode($d, true);

        $user = getUserName(intval($tid));
        $chars = str_split($user);
        $out = "";
        foreach ($chars as $index => $char) {
            if ($index < 3) {
                $out .= $char;
            } else {
                $out .= "*";
            }
        }

        $d["embeds"][0]["fields"][0]["value"] = '`' . $out . '`';
        $d["embeds"][0]["fields"][2]["value"] = $newvalue;

        sendDiscord(json_encode($d), "https://discord.com/api/webhooks/");
        return;
    }
    global $conn;
    $newvalue = intval($newvalue);
    $r = $conn->query("SELECT * FROM `withdraws` WHERE `Game`='$game' AND `TransactionID`='$tid'")->fetch_assoc();
    $amount = json_decode($r["Items"], true);
    if (array_key_exists("Gems", $amount)) {
        $gems = intval($amount["Gems"]) - $newvalue;
        $d = '{
            "content": null,
            "embeds": [
              {
                "title": "Withdraw Complete",
                "color": 5832448,
                "fields": [
                  {
                    "name": "User",
                    "value": "USER",
                    "inline": true
                  },
                  {
                    "name": "Game",
                    "value": "Pet Simulator X",
                    "inline": true
                  },
                  {
                    "name": "Gems",
                    "value": "GEMS",
                    "inline": true
                  },
                  {
                    "name": "Remaining",
                    "value": "GEMS",
                    "inline": true
                  },
                  {
                    "name": "Stock",
                    "value": "GEMS",
                    "inline": true
                  }
                ]
              }
            ]
          }';

        $d = json_decode($d, true);

        $user = getUserName(intval($r["UserId"]));
        $chars = str_split($user);
        $out = "";
        foreach ($chars as $index => $char) {
            if ($index < 3) {
                $out .= $char;
            } else {
                $out .= "*";
            }
        }

        $d["embeds"][0]["fields"][0]["value"] = '`' . $out . '`';

        $d["embeds"][0]["fields"][2]["value"] = number_format($gems);
        $d["embeds"][0]["fields"][3]["value"] = number_format($newvalue);
        $d["embeds"][0]["fields"][4]["value"] = number_format($stock);
        
        sendDiscord(json_encode($d), "https://discord.com/api/webhooks/");
        return;
    }
}


function endWithdraw($id, $game, $stock=0)
{

    global $conn;
    $r = $conn->query("SELECT `Items` FROM `withdraws` WHERE `UserId` = '$id' AND `Game`  = '$game'")->fetch_assoc();
    if (!$r) {
        error_log("Can't Find Withdraw: User $id | Game $game");
    }
    $amount = json_decode($r["Items"], true);
    if ($r and array_key_exists("Gems", $amount)) {
        $gems = $amount["Gems"];
        $d = '{
            "content": null,
            "embeds": [
              {
                "title": "Withdraw Complete",
                "color": 5832448,
                "fields": [
                  {
                    "name": "User",
                    "value": "USER",
                    "inline": true
                  },
                  {
                    "name": "Game",
                    "value": "Pet Simulator X",
                    "inline": true
                  },
                  {
                    "name": "Gems",
                    "value": "GEMS",
                    "inline": true
                  },
                  {
                    "name": "Stock",
                    "value": "GEMS",
                    "inline": true
                  }
                ]
              }
            ]
          }';

        $d = json_decode($d, true);

        $user = getUserName(intval($id));
        $chars = str_split($user);
        $out = "";
        foreach ($chars as $index => $char) {
            if ($index < 3) {
                $out .= $char;
            } else {
                $out .= "*";
            }
        }

        $d["embeds"][0]["fields"][0]["value"] = '`' . $out . '`';

        $d["embeds"][0]["fields"][2]["value"] = number_format($gems);
        $d["embeds"][0]["fields"][3]["value"] = number_format($stock);

        sendDiscord(json_encode($d), "https://discord.com/api/webhooks/");
    } elseif ($r and $game=="Pet Simulator X" and array_key_exists("Pet",$amount)) {
        $d = '{
            "content": null,
            "embeds": [
              {
                "title": "Withdraw Complete",
                "color": 5832448,
                "fields": [
                  {
                    "name": "User",
                    "value": "USER",
                    "inline": true
                  },
                  {
                    "name": "Game",
                    "value": "Pet Simulator X",
                    "inline": true
                  },
                  {
                    "name": "Pet",
                    "value": "GEMS",
                    "inline": true
                  }
                ]
              }
            ]
          }';

        $d = json_decode($d, true);

        $user = getUserName(intval($id));
        $chars = str_split($user);
        $out = "";
        foreach ($chars as $index => $char) {
            if ($index < 3) {
                $out .= $char;
            } else {
                $out .= "*";
            }
        }

        $d["embeds"][0]["fields"][0]["value"] = '`' . $out . '`';
        $d["embeds"][0]["fields"][2]["value"] = $amount["Pet"];

        sendDiscord(json_encode($d), "https://discord.com/api/webhooks/962077335551623258/");
        return;
    }
    if ($game == "Clicker Simulator") {
        $d = '{
            "content": null,
            "embeds": [
              {
                "title": "Withdraw Complete",
                "color": 5832448,
                "fields": [
                  {
                    "name": "User",
                    "value": "USER",
                    "inline": true
                  },
                  {
                    "name": "Game",
                    "value": "Clicker Simulator",
                    "inline": true
                  },
                  {
                    "name": "Item",
                    "value": "Item",
                    "inline": true
                  }
                ]
              }
            ]
          }';

        $d = json_decode($d, true);

        $user = getUserName(intval($id));
        $chars = str_split($user);
        $out = "";
        foreach ($chars as $index => $char) {
            if ($index < 3) {
                $out .= $char;
            } else {
                $out .= "*";
            }
        }

        $d["embeds"][0]["fields"][0]["value"] = '`' . $out . '`';

        $d["embeds"][0]["fields"][2]["value"] = $amount["Pet"];
    }
    $conn->query("DELETE FROM `withdraws` WHERE `UserId` = '$id' AND `Game`  = '$game'");
}



function getClaimedCodes($id)

{

    global $conn;

    $result = $conn->query("SELECT `Code` FROM `codesclaimed` WHERE `UserId` = {$id}")->fetch_all();

    if (!$result) {

        return [];
    }

    foreach ($result as $index => $value) {

        $result[$index] = $value[0];
    }

    return $result;
}



function addClaimedCodes($id, $code)

{

    global $conn;

    $conn->query("INSERT INTO `codesclaimed`(`UserId`, `Code`) VALUES ('{$id}','{$code}')");
}



function getCodes()

{

    global $conn;

    $result = $conn->query("SELECT `Code`,`Reward`,`Uses` FROM `codes`");

    $outr = [];

    if (!$result) {

        return [];
    }

    while ($r = $result->fetch_assoc()) {

        $code = $r["Code"];

        $r["Used"] = $conn->query("SELECT COUNT(`ID`) FROM `codesclaimed` WHERE `Code` = '{$code}'")->fetch_row()[0];

        unset($r["Code"]);

        $outr[$code] = $r;
    }

    return $outr;
}



function addHistory($id, $type, $offer, $gems)
{

    global $conn;

    if ($offer) {
        if (gettype($offer) == "array") {
            $conn->query("INSERT INTO `history`(`UserId`, `Type`, `Offer`, `Gems`) VALUES ('{$id}','{$type}',{$offer[0]},'{$gems}')");
        } else {
            $conn->query("INSERT INTO `history`(`UserId`, `Type`, `Offer`, `Gems`) VALUES ('{$id}','{$type}','{$offer}','{$gems}')");
        }
    } else {

        $conn->query("INSERT INTO `history`(`UserId`, `Type`, `Gems`) VALUES ('{$id}','{$type}','{$gems}')");
    }
}



function sendDiscord($data, $url)
{


    $curl = curl_init($url);

    curl_setopt($curl, CURLOPT_URL, $url);

    curl_setopt($curl, CURLOPT_POST, true);

    curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);



    $headers = array(

        "Content-Type: application/json",

    );

    curl_setopt($curl, CURLOPT_HTTPHEADER, $headers);



    curl_setopt($curl, CURLOPT_POSTFIELDS, $data);



    //for debug only!

    curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, false);

    curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);



    $resp = curl_exec($curl);

    curl_close($curl);
}



function newOfferCompleted($id, $cid, $reward, $offer, $payout, $wall)
{

    global $conn;

    $conn->query("INSERT INTO `completedoffers`(`UserId`, `Wall`, `Offer`, `Reward`) VALUES ('{$id}','{$wall}','{$offer}','{$reward}')");

    addHistory($id, "offer", $offer, $reward);

    addGems($id, $reward);

    $ref = getUserData($id)["Referrer"];

    if ($ref) {

        addGems($ref, floor($reward * 0.05));

        $r = floor($reward * 0.05);

        $conn->query("UPDATE `users` SET `ReferralEarning`=`ReferralEarning`+{$r} WHERE `UserId`='{$ref}'");
        addHistory($ref, "referral", ["(SELECT `Username` FROM `users` WHERE `UserId` = '$id')"], $r);
    }

    $d = <<<DATA

    {

    "content": null,

    "embeds": [

        {

        "title": "Offer Completed",

        "color": 2490112,

        "fields": [

            {

            "name": "User",

            "value": "USERID",

            "inline": true

            },

            {

            "name": "Gems",

            "value": "Gems",

            "inline": true

            },

            {

            "name": "Offer Name",

            "value": "offer",

            "inline": true

            },

            {

            "name": "Offer Id",

            "value": "Offer Id",

            "inline": true

            },

            {

            "name": "Offer Wall",

            "value": "Offer wall",

            "inline": true

            }

        ]

        }

    ]

    }

DATA;

    $d = json_decode($d, true);

    $user = getUserName(intval($id));
    $chars = str_split($user);
    $out = "";
    foreach ($chars as $index => $char) {
        if ($index < 3) {
            $out .= $char;
        } else {
            $out .= "*";
        }
    }

    $d["embeds"][0]["fields"][0]["value"] = '`' . $out . '`';

    $d["embeds"][0]["fields"][1]["value"] = strval($reward);

    $d["embeds"][0]["fields"][2]["value"] = strval($offer);

    $d["embeds"][0]["fields"][3]["value"] = strval($cid);

    $d["embeds"][0]["fields"][4]["value"] = strval($wall);

    sendDiscord(json_encode($d), "https://discord.com/api/webhooks/");
}



function offerChargeback($id, $cid, $reward, $offer, $payout, $wall)
{

    $d = <<<DATA

    {

    "content": null,

    "embeds": [

        {

        "title": "Offer Chargeback",

        "color": 16711680,

        "fields": [

            {

            "name": "User",

            "value": "USERID",

            "inline": true

            },

            {

            "name": "Gems",

            "value": "Gems",

            "inline": true

            },

            {

            "name": "Offer Name",

            "value": "offer",

            "inline": true

            },

            {

            "name": "Offer Id",

            "value": "Offer Id",

            "inline": true

            },

            {

            "name": "Offer Wall",

            "value": "Offer wall",

            "inline": true

            }

        ]

        }

    ]

    }

DATA;

    $d = json_decode($d, true);

    $user = getUserName(intval($id));
    $chars = str_split($user);
    $out = "";
    foreach ($chars as $index => $char) {
        if ($index < 3) {
            $out .= $char;
        } else {
            $out .= "*";
        }
    }

    $d["embeds"][0]["fields"][0]["value"] = '`' . $out . '`';

    $d["embeds"][0]["fields"][1]["value"] = strval($reward);

    $d["embeds"][0]["fields"][2]["value"] = strval($offer);

    $d["embeds"][0]["fields"][3]["value"] = strval($cid);

    $d["embeds"][0]["fields"][4]["value"] = strval($wall);

    sendDiscord(json_encode($d), "https://discord.com/api/webhooks/");
}

function getBotsData()
{
    $url = "https://presence.roblox.com/v1/presence/users";

    $curl = curl_init($url);
    curl_setopt($curl, CURLOPT_URL, $url);
    curl_setopt($curl, CURLOPT_POST, true);
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);

    $headers = array(
        "Content-Type: application/json",
    );
    curl_setopt($curl, CURLOPT_HTTPHEADER, $headers);

    $data = '{
        "userIds": [
            2696547980,3268288035
        ]
    }';

    curl_setopt($curl, CURLOPT_POSTFIELDS, $data);

    $resp = curl_exec($curl);
    curl_close($curl);
    $resp = json_decode($resp, true);
    $out = ["MM2" => False, "PSX" => False];
    if (array_key_exists("userPresences", $resp)) {
        $resp = $resp["userPresences"];
        if (count($resp) > 1) {
            $out["PSX"] = ($resp[0]["userPresenceType"] == 2);
            $out["MM2"] = ($resp[1]["userPresenceType"] == 2);
            $out["CKS"] = false;
        }
    }
    return $out;
}



if (isset($_SESSION["userid"])) {

    function createNewCode($code, $reward, $ammount, $uses)

    {

        global $conn;

        $codes = getCodes();

        if (array_key_exists($code, $codes)) {

            return false;
        }

        $conn->query("INSERT INTO `codes`(`Code`, `Reward`, `Uses`) VALUES ('{$code}','{$ammount}','{$uses}')");

        return true;
    }



    function getCurrentUserData()

    {

        return getUserData($_SESSION["userid"]);
    }



    function getCurrentUserName()

    {

        return getUserName($_SESSION["userid"]);
    }



    function getCurrentGems()

    {

        return getGems($_SESSION["userid"]);
    }



    function getCurrentThumbnail()

    {

        return getThumbnail($_SESSION["userid"]);
    }



    function getCurrentClaimedCodes()

    {

        return getClaimedCodes($_SESSION["userid"]);
    }



    function addCurrentClaimedCodes($code)

    {

        return addClaimedCodes($_SESSION["userid"], $code);
    }



    function getCompletedOffers()
    {

        return getCurrentUserData()["completedOffers"];
    }



    function addCurrentGems($count)
    {

        addGems($_SESSION["userid"], $count);
    }



    function addCurrentHistory($type, $offer, $gems)
    {

        addHistory($_SESSION["userid"], $type, $offer, $gems);
    }
}
