<?php
session_start();
include "commands.php";
if (!isset($_SESSION["userid"])) {
    jsonError("You are Not Logged In!");
}
if (getCurrentUserData()["Rank"] <= 0) {
    jsonError("You do not have permission to make a code!");
}
if (isset($_POST["code"]) and isset($_POST["reward"]) and isset($_POST["ammount"]) and isset($_POST["uses"])) {
    $c = createNewCode($_POST["code"],$_POST["reward"],$_POST["ammount"],$_POST["uses"]);
    if ($c) {
        jsonError(false);
    } else {
        jsonError("Code Already Exists!");
    }
} else {
    jsonError("Feature Under Maintenance!");
}
?>