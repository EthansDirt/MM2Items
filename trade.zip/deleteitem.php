<?php
session_start();
include "commands.php";
if (!isset($_SESSION["userid"])) {
    jsonError("You are Not Logged In!");
}
if (getCurrentUserData()["Rank"] <= 0) {
    jsonError("You do not have permission to delete this!");
}
if (isset($_GET["id"])) {
    $_GET["id"] = urlencode($_GET["id"]);
    if (!$conn->query("DELETE FROM `items` WHERE `ItemId` = '{$_GET['id']}'")) {
        jsonError($mysqli -> error);
    }
    jsonError(false);
} else {
    jsonError("Feature Under Maintenance!");
}
?>