    <!-- end featured collections -->




    <!-- JS Scripts -->
    <script src="./js/app.bundle.js"></script>
</body>

</html>