<?php
require_once("commands.php");
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <?php
  if (!isset($title)) {
    $title = "RBXItems";
  }
  ?>
  <title><?php echo $title ?></title>

  <meta charset="utf-8" />
  <!--[if IE]><meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" /><![endif]-->
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
  <meta name="description" content="Join us today & earn easy points. Withdraw points into PSX Gems, MM2 Items, and Adopt Me Items!. Login with ROBLOX Username!" />
  <meta name="keywords" content="ROBLOX, Pet Simulator X, Pet Simulator, MM2, PSX, Gems, Murder Mystery, Murder Mystery 2, Adopt Me, Free, Pets, Weapons, Items, Offers, Adgate Media, Offer Wall, CPX Research, Withdraw, Completely Free, Free Robux, Free Money" />

  <meta property="og:title" content="RBXItems" />
  <meta property="og:type" content="website" />
  <meta property="og:url" content="http://rbxitems.com" />
  <meta property="og:image" content="http://rbxitems.com/img/plogo.png" />
  <meta property="og:description" content="Earn Pet Simulator X Gems and Murder Mystery 2 Items, by completing free and simple tasks" />
  <meta name="theme-color" content="#6a2d87">

  <!-- Css -->
  <link rel="stylesheet" href="./css/style.css" />

  <!--Scripts Import-->
  <script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>

  <!-- Dark Mode JS -->
  <script src="./js/darkMode.bundle.js"></script>

  <!-- Favicons -->
  <link rel="shortcut icon" href="img/plogo.svg" />
  <link rel="apple-touch-icon" href="img/plogo.svg" />
  <link rel="apple-touch-icon" sizes="72x72" href="img/plogo.svg" />
  <link rel="apple-touch-icon" sizes="114x114" href="img/plogo.svg" />
  <!-- Global site tag (gtag.js) - Google Analytics -->
  <script async src="https://www.googletagmanager.com/gtag/js?id=G-1ZRGQ6TEFP"></script>
  <script>
    window.dataLayer = window.dataLayer || [];

    function gtag() {
      dataLayer.push(arguments);
    }
    gtag('js', new Date());

    gtag('config', 'G-1ZRGQ6TEFP');
  </script>
</head>

<body class="dark:bg-jacarta-900 font-body text-jacarta-500 overflow-x-hidden" itemscope itemtype="http://schema.org/WebPage">
  <!-- Header -->
  <header class="js-page-header fixed top-0 z-20 w-full backdrop-blur transition-colors">
    <div class="flex items-center px-6 py-6 xl:px-24">
      <!-- Logo -->
      <a href="index.html" class="shrink-0">
        <img src="img/plogo.svg" style='height:100px' class="inline-block max-h-7" alt="Logo" />
        <img src="img/text-logo.svg" style='height:100px' class="inline-block max-h-7" alt="Text Logo" />
      </a>



      <!-- Menu / Actions -->
      <div class="js-mobile-menu dark:bg-jacarta-800 invisible fixed inset-0 z-10 ml-auto items-center bg-white opacity-0 lg:visible lg:relative lg:inset-auto lg:flex lg:bg-transparent lg:opacity-100 dark:lg:bg-transparent">
        <!-- Mobile Logo / Menu Close -->
        <div class="t-0 dark:bg-jacarta-800 fixed left-0 z-10 flex w-full items-center justify-between bg-white p-6 lg:hidden">
          <!-- Mobile Logo -->
          <a href="index.html" class="shrink-0">
            <img src="img/plogo.svg" style='height:100px' class="inline-block max-h-7" alt="Logo" />
            <img src="img/text-logo.svg" style='height:100px' class="inline-block max-h-7" alt="Text Logo" />
          </a>

          <!-- Mobile Menu Close -->
          <button class="js-mobile-close border-jacarta-100 hover:bg-accent focus:bg-accent group dark:hover:bg-accent ml-2 flex h-10 w-10 items-center justify-center rounded-full border bg-white transition-colors hover:border-transparent focus:border-transparent dark:border-transparent dark:bg-white/[.15]" aria-label="close mobile menu">
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24" class="fill-jacarta-700 h-4 w-4 transition-colors group-hover:fill-white group-focus:fill-white dark:fill-white">
              <path fill="none" d="M0 0h24v24H0z" />
              <path d="M12 10.586l4.95-4.95 1.414 1.414-4.95 4.95 4.95 4.95-1.414 1.414-4.95-4.95-4.95 4.95-1.414-1.414 4.95-4.95-4.95-4.95L7.05 5.636z" />
            </svg>
          </button>
        </div>

        <!-- Mobile Search -->
        <form action="search" class="relative mt-24 mb-8 w-full lg:hidden">

        </form>


















        <!-- Primary Nav -->
        <nav class="navbar w-full">
          <ul class="flex flex-col lg:flex-row">



            <li class="lg:hidden group">
              <a class="text-jacarta-700 font-display hover:text-accent focus:text-accent dark:hover:text-accent dark:focus:text-accent flex items-center justify-between py-3.5 text-base dark:text-white lg:px-5 show-on-mobile">
                <h1>You have </h1><?php echo number_format(getCurrentGems()); ?> Points
              </a>
            </li>





            <br>

            <?php
            if (isset($_SESSION["userid"]) and getUserData($_SESSION["userid"])["Rank"] >= 1) {
              echo '<li class="group">
                <a
                  href="users.html"
                  class="text-jacarta-700 font-display hover:text-accent focus:text-accent dark:hover:text-accent dark:focus:text-accent flex items-center justify-between py-3.5 text-base dark:text-white lg:px-5"
                  >Users</a
                >
              </li>
              <li class="group">
                <a
                  href="shop.html"
                  class="text-jacarta-700 font-display hover:text-accent focus:text-accent dark:hover:text-accent dark:focus:text-accent flex items-center justify-between py-3.5 text-base dark:text-white lg:px-5"
                  >Shop</a
                >
              </li>';
            }
            ?>

            <li class="group">
              <a href="dashboard.html" class="text-jacarta-700 font-display hover:text-accent focus:text-accent dark:hover:text-accent dark:focus:text-accent flex items-center justify-between py-3.5 text-base dark:text-white lg:px-5">Dashboard</a>
            </li>










            <li class="group">
              <a href="referral.html" class="text-jacarta-700 font-display hover:text-accent focus:text-accent dark:hover:text-accent dark:focus:text-accent flex items-center justify-between py-3.5 text-base dark:text-white lg:px-5">Referral</a>
            </li>






            <li class="js-nav-dropdown group relative">
              <a href="#" class="dropdown-toggle text-jacarta-700 font-display hover:text-accent focus:text-accent dark:hover:text-accent dark:focus:text-accent flex items-center justify-between py-3.5 text-base dark:text-white lg:px-5" id="navDropdown-1" aria-expanded="false" role="button" data-bs-toggle="dropdown">Withdraw
                <i class="lg:hidden">
                  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24" class="h-4 w-4 dark:fill-white">
                    <path fill="none" d="M0 0h24v24H0z" />
                    <path d="M12 13.172l4.95-4.95 1.414 1.414L12 16 5.636 9.636 7.05 8.222z" />
                  </svg>
                </i>
              </a>
              <ul class="dropdown-menu dark:bg-jacarta-800 left-0 top-[85%] z-10 hidden min-w-[200px] gap-x-4 whitespace-nowrap rounded-xl bg-white transition-all will-change-transform group-hover:visible group-hover:opacity-100 lg:invisible lg:absolute lg:grid lg:translate-y-4 lg:py-4 lg:px-2 lg:opacity-0 lg:shadow-2xl lg:group-hover:translate-y-2" aria-labelledby="navDropdown-1">
                <li>
                  <a href="withdrawmurder.html" class="dark:hover:bg-jacarta-600 hover:text-accent focus:text-accent hover:bg-jacarta-50 flex items-center rounded-xl px-5 py-2 transition-colors">
                    <span class="font-display text-jacarta-700 text-sm dark:text-white">Murder Mystery 2</span>
                  </a>
                </li>
                <li>
                  <a href="withdrawpsx.html" class="dark:hover:bg-jacarta-600 hover:text-accent focus:text-accent hover:bg-jacarta-50 flex items-center rounded-xl px-5 py-2 transition-colors">
                    <span class="font-display text-jacarta-700 text-sm dark:text-white">PSX Gems</span>
                  </a>
                </li>
                <li>
                  <a href="wadopt.html" class="dark:hover:bg-jacarta-600 hover:text-accent focus:text-accent hover:bg-jacarta-50 flex items-center rounded-xl px-5 py-2 transition-colors">
                    <span class="font-display text-jacarta-700 text-sm dark:text-white">Adopt me</span>
                  </a>
                </li>
              </ul>
            </li>

            <li class="group">
              <a href="javascript:void(0)" class="text-jacarta-700 font-display hover:text-accent focus:text-accent dark:hover:text-accent dark:focus:text-accent flex items-center justify-between py-3.5 text-base dark:text-white lg:px-5" data-bs-toggle="modal" data-bs-target="#tModal">Tip</a>
            </li>

            <li class="lg:hidden group">
              <a href="activity.html" class="text-jacarta-700 font-display hover:text-accent focus:text-accent dark:hover:text-accent dark:focus:text-accent flex items-center justify-between py-3.5 text-base dark:text-white lg:px-5 show-on-mobile">Activity</a>
            </li>









            <li class="lg:hidden group">
              <a href="logout" class="text-jacarta-700 font-display hover:text-accent focus:text-accent dark:hover:text-accent dark:focus:text-accent flex items-center justify-between py-3.5 text-base dark:text-white lg:px-5 show-on-mobile">Sign
                out</a>
            </li>











          </ul>
        </nav>


        <!-- Actions -->
        <div class="ml-8 hidden lg:flex xl:ml-12">
          <!-- Wallet -->
          <a href="activity.html" class="border-jacarta-100 hover:bg-accent focus:bg-accent group dark:hover:bg-accent flex h-10 w-10 items-center justify-center rounded-full border bg-white transition-colors hover:border-transparent focus:border-transparent dark:border-transparent dark:bg-white/[.15]">
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24" class="fill-jacarta-700 h-4 w-4 transition-colors group-hover:fill-white group-focus:fill-white dark:fill-white">
              <path fill="none" d="M0 0h24v24H0z" />
              <path d="M22 6h-7a6 6 0 1 0 0 12h7v2a1 1 0 0 1-1 1H3a1 1 0 0 1-1-1V4a1 1 0 0 1 1-1h18a1 1 0 0 1 1 1v2zm-7 2h8v8h-8a4 4 0 1 1 0-8zm0 3v2h3v-2h-3z" />
            </svg>
          </a>

          <!-- Profile -->
          <div class="js-nav-dropdown group-dropdown relative">
            <button class="dropdown-toggle border-jacarta-100 hover:bg-accent focus:bg-accent group dark:hover:bg-accent ml-2 flex h-10 w-10 items-center justify-center rounded-full border bg-white transition-colors hover:border-transparent focus:border-transparent dark:border-transparent dark:bg-white/[.15]" id="profileDropdown" aria-expanded="false" data-bs-toggle="dropdown" aria-label="profile">
              <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24" class="fill-jacarta-700 h-4 w-4 transition-colors group-hover:fill-white group-focus:fill-white dark:fill-white">
                <path fill="none" d="M0 0h24v24H0z" />
                <path d="M11 14.062V20h2v-5.938c3.946.492 7 3.858 7 7.938H4a8.001 8.001 0 0 1 7-7.938zM12 13c-3.315 0-6-2.685-6-6s2.685-6 6-6 6 2.685 6 6-2.685 6-6 6z" />
              </svg>
            </button>
            <div class="dropdown-menu dark:bg-jacarta-800 group-dropdown-hover:opacity-100 group-dropdown-hover:visible !-right-4 !top-[85%] !left-auto z-10 hidden min-w-[14rem] whitespace-nowrap rounded-xl bg-white transition-all will-change-transform before:absolute before:-top-3 before:h-3 before:w-full lg:invisible lg:absolute lg:grid lg:!translate-y-4 lg:py-4 lg:px-2 lg:opacity-0 lg:shadow-2xl" aria-labelledby="profileDropdown">

              <span class="max-w-[10rem] overflow-hidden text-ellipsis font-display text-jacarta-700 my-4 flex select-none items-center whitespace-nowrap px-5 leading-none dark:text-white"><?php echo getCurrentUserName(); ?></span>

              <div class="dark:border-jacarta-600 border-jacarta-100 mx-5 mb-6 rounded-lg border p-4">
                <span class="dark:text-jacarta-200 text-sm font-medium tracking-tight">Balance</span>
                <div class="flex items-center">
                  <svg xmlns="http://www.w3.org/2000/svg" width="22" height="16" fill="currentColor" class="bi bi-gem" viewBox="0 0 22 16">
                    <path d="M3.1.7a.5.5 0 0 1 .4-.2h9a.5.5 0 0 1 .4.2l2.976 3.974c.149.185.156.45.01.644L8.4 15.3a.5.5 0 0 1-.8 0L.1 5.3a.5.5 0 0 1 0-.6l3-4zm11.386 3.785-1.806-2.41-.776 2.413 2.582-.003zm-3.633.004.961-2.989H4.186l.963 2.995 5.704-.006zM5.47 5.495 8 13.366l2.532-7.876-5.062.005zm-1.371-.999-.78-2.422-1.818 2.425 2.598-.003zM1.499 5.5l5.113 6.817-2.192-6.82L1.5 5.5zm7.889 6.817 5.123-6.83-2.928.002-2.195 6.828z" />
                  </svg>
                  <span class="text-green text-lg font-bold"><?php echo number_format(getCurrentGems()); ?> Points</span>
                </div>
              </div>


              <a href="logout" class="dark:hover:bg-jacarta-600 hover:text-accent focus:text-accent hover:bg-jacarta-50 flex items-center space-x-2 rounded-xl px-5 py-2 transition-colors">
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24" class="fill-jacarta-700 h-4 w-4 transition-colors dark:fill-white">
                  <path fill="none" d="M0 0h24v24H0z" />
                  <path d="M12 22C6.477 22 2 17.523 2 12S6.477 2 12 2s10 4.477 10 10-4.477 10-10 10zM7 11V8l-5 4 5 4v-3h8v-2H7z" />
                </svg>
                <span class="font-display text-jacarta-700 mt-1 text-sm dark:text-white">Sign out</span>
              </a>
            </div>
          </div>

          <!-- Dark Mode -->
          <a href="#" class="border-jacarta-100 hover:bg-accent focus:bg-accent group dark:hover:bg-accent js-dark-mode-trigger ml-2 flex h-10 w-10 items-center justify-center rounded-full border bg-white transition-colors hover:border-transparent focus:border-transparent dark:border-transparent dark:bg-white/[.15]">
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24" class="fill-jacarta-700 dark-mode-light h-4 w-4 transition-colors group-hover:fill-white group-focus:fill-white dark:hidden">
              <path fill="none" d="M0 0h24v24H0z" />
              <path d="M11.38 2.019a7.5 7.5 0 1 0 10.6 10.6C21.662 17.854 17.316 22 12.001 22 6.477 22 2 17.523 2 12c0-5.315 4.146-9.661 9.38-9.981z" />
            </svg>
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24" class="fill-jacarta-700 dark-mode-dark hidden h-4 w-4 transition-colors group-hover:fill-white group-focus:fill-white dark:block dark:fill-white">
              <path fill="none" d="M0 0h24v24H0z" />
              <path d="M12 18a6 6 0 1 1 0-12 6 6 0 0 1 0 12zM11 1h2v3h-2V1zm0 19h2v3h-2v-3zM3.515 4.929l1.414-1.414L7.05 5.636 5.636 7.05 3.515 4.93zM16.95 18.364l1.414-1.414 2.121 2.121-1.414 1.414-2.121-2.121zm2.121-14.85l1.414 1.415-2.121 2.121-1.414-1.414 2.121-2.121zM5.636 16.95l1.414 1.414-2.121 2.121-1.414-1.414 2.121-2.121zM23 11v2h-3v-2h3zM4 11v2H1v-2h3z" />
            </svg>
          </a>
        </div>
      </div>

      <!-- Mobile Menu Actions -->
      <div class="ml-auto flex lg:hidden">
        <!-- Profile -->

        <div class="modal fade" id="initModal" tabindex="-1" aria-labelledby="loginLabel" aria-hidden="true">
          <div class="modal-dialog max-w-lg">
            <div class="modal-content">
              <div class="modal-header">
                <h5 class="modal-title" id="loginwalletLabel">Login with your roblox username </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close">
                  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24" class="fill-jacarta-700 h-6 w-6 dark:fill-white">
                    <path fill="none" d="M0 0h24v24H0z" />
                    <path d="M12 10.586l4.95-4.95 1.414 1.414-4.95 4.95 4.95 4.95-1.414 1.414-4.95-4.95-4.95 4.95-1.414-1.414 4.95-4.95-4.95-4.95L7.05 5.636z" />
                  </svg>
                </button>
              </div>

              <!-- Body -->
              <div class="modal-body p-6 text-center justify-center">


                <div class="mb-1">

                  <input type="text" id="item-name" class="dark:bg-jacarta-700 border-jacarta-100 hover:ring-accent/10 focus:ring-accent dark:border-jacarta-600 dark:placeholder:text-jacarta-300 w-full rounded-lg py-3 hover:ring-2 dark:text-white" placeholder="Your username" required />
                </div>




              </div>
              <!-- end body -->

              <div class="modal-footer">
                <div class="flex items-center justify-center space-x-4">

                  <div class="flex space-x-4">
                    <a href="dashboard.html" class="bg-accent shadow-accent-volume hover:bg-accent-dark w-36 rounded-full py-3 px-8 text-center font-semibold text-white transition-all" data-bs-toggle="modal" data-bs-target="#tipModal">
                      Proceed
                    </a>

                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>


        <!-- Dark Mode -->
        <a href="#" class="js-dark-mode-trigger border-jacarta-100 hover:bg-accent dark:hover:bg-accent focus:bg-accent group ml-2 flex h-10 w-10 items-center justify-center rounded-full border bg-white transition-colors hover:border-transparent focus:border-transparent dark:border-transparent dark:bg-white/[.15]">
          <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24" class="fill-jacarta-700 dark-mode-light h-4 w-4 transition-colors group-hover:fill-white group-focus:fill-white dark:hidden">
            <path fill="none" d="M0 0h24v24H0z" />
            <path d="M11.38 2.019a7.5 7.5 0 1 0 10.6 10.6C21.662 17.854 17.316 22 12.001 22 6.477 22 2 17.523 2 12c0-5.315 4.146-9.661 9.38-9.981z" />
          </svg>
          <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24" class="fill-jacarta-700 dark-mode-dark hidden h-4 w-4 transition-colors group-hover:fill-white group-focus:fill-white dark:block dark:fill-white">
            <path fill="none" d="M0 0h24v24H0z" />
            <path d="M12 18a6 6 0 1 1 0-12 6 6 0 0 1 0 12zM11 1h2v3h-2V1zm0 19h2v3h-2v-3zM3.515 4.929l1.414-1.414L7.05 5.636 5.636 7.05 3.515 4.93zM16.95 18.364l1.414-1.414 2.121 2.121-1.414 1.414-2.121-2.121zm2.121-14.85l1.414 1.415-2.121 2.121-1.414-1.414 2.121-2.121zM5.636 16.95l1.414 1.414-2.121 2.121-1.414-1.414 2.121-2.121zM23 11v2h-3v-2h3zM4 11v2H1v-2h3z" />
          </svg>
        </a>

        <!-- Mobile Menu Toggle -->
        <button class="js-mobile-toggle border-jacarta-100 hover:bg-accent dark:hover:bg-accent focus:bg-accent group ml-2 flex h-10 w-10 items-center justify-center rounded-full border bg-white transition-colors hover:border-transparent focus:border-transparent dark:border-transparent dark:bg-white/[.15]" aria-label="open mobile menu">
          <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24" class="fill-jacarta-700 h-4 w-4 transition-colors group-hover:fill-white group-focus:fill-white dark:fill-white">
            <path fill="none" d="M0 0h24v24H0z" />
            <path d="M18 18v2H6v-2h12zm3-7v2H3v-2h18zm-3-7v2H6V4h12z" />
          </svg>
        </button>
      </div>
    </div>
  </header>
  <div class="modal fade" id="tModal" tabindex="-1" aria-labelledby="initLabel" aria-hidden="true">
    <div class="modal-dialog max-w-lg">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="initLabel">Who Are You Tipping To</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close">
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24" class="fill-jacarta-700 h-6 w-6 dark:fill-white">
              <path fill="none" d="M0 0h24v24H0z" />
              <path d="M12 10.586l4.95-4.95 1.414 1.414-4.95 4.95 4.95 4.95-1.414 1.414-4.95-4.95-4.95 4.95-1.414-1.414 4.95-4.95-4.95-4.95L7.05 5.636z" />
            </svg>
          </button>
        </div>

        <!-- Body -->
        <div class="modal-body p-6 text-center justify-center">


          <div class="mb-1">
            <input type="text" id="tippee-name" class="dark:bg-jacarta-700 border-jacarta-100 hover:ring-accent/10 focus:ring-accent dark:border-jacarta-600 dark:placeholder:text-jacarta-300 w-full rounded-lg py-3 hover:ring-2 dark:text-white" placeholder="Reciever username" required />
          </div>




        </div>
        <!-- end body -->

        <div class="modal-footer">
          <div class="flex items-center justify-center space-x-4">

            <div class="flex space-x-4">
              <a href="javascript:void(0)" id='tipBtn' onclick='updateTipModal()' class="bg-accent shadow-accent-volume hover:bg-accent-dark w-36 rounded-full py-3 px-8 text-center font-semibold text-white transition-all">
                Proceed
              </a>

            </div>
          </div>
        </div>
      </div>
    </div>
  </div>

  <div class="modal fade" id="tipModal" tabindex="-1" aria-labelledby="tipLabel" aria-hidden="true">
    <div class="modal-dialog max-w-lg">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="tipLabel">Tipping</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close">
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24" class="fill-jacarta-700 h-6 w-6 dark:fill-white">
              <path fill="none" d="M0 0h24v24H0z" />
              <path d="M12 10.586l4.95-4.95 1.414 1.414-4.95 4.95 4.95 4.95-1.414 1.414-4.95-4.95-4.95 4.95-1.414-1.414 4.95-4.95-4.95-4.95L7.05 5.636z" />
            </svg>
          </button>
        </div>

        <!-- Script -->
        <script>
          function updateTipModal() {
            username = document.getElementById('tippee-name').value
            document.getElementById('tipBtn').onclick = null;
            document.getElementById('tipBtn').innerText = "Loading...";
            fetch('./avatar/?name=' + username).then(result => {
              result.json().then(data => {
                if (data["Error"]) {
                  document.getElementById('profsName').innerText = data["Error"]
                  document.getElementById('profsImg').classList.remove('hidden');
                  document.getElementById('profsImg').src = 'https://tr.rbxcdn.com/c4265017c98559993061733b1125a23c/150/150/AvatarHeadshot/Png/isCircular'
                  document.getElementById('profsText').innerHTML = "Can't Tip"
                  document.getElementById('profsButtons').innerHTML = `<a href="javascript:void(0)" class="text-accent shadow-white-volume hover:bg-accent-dark hover:shadow-accent-volume w-36 rounded-full bg-white py-3 px-8 text-center font-semibold transition-all hover:text-white" data-bs-toggle="modal" data-bs-target="#tipModal">
                Retry</a>`
                } else {
                  document.getElementById('tipCont').classList.remove('hidden');
                  document.getElementById('tipAm').value = null;
                  document.getElementById('profsName').innerText = username
                  document.getElementById('profsImg').classList.remove('hidden');
                  document.getElementById('profsImg').src = data["Message"]
                  document.getElementById('profsText').innerHTML = "Make sure this is the correct account.<br>This action is irreversible.<br><br>There will be a 2% Tax."
                  document.getElementById('profsButtons').innerHTML = `<a href="javascript:void(0)" onclick="tip()" class="text-accent shadow-white-volume hover:bg-accent-dark hover:shadow-accent-volume w-36 rounded-full bg-white py-3 px-8 text-center font-semibold transition-all hover:text-white">
                Yep </a>
              <a href="javascript:void(0)" class="text-accent shadow-white-volume hover:bg-accent-dark hover:shadow-accent-volume w-36 rounded-full bg-white py-3 px-8 text-center font-semibold transition-all hover:text-white" data-bs-toggle="modal" data-bs-target="#tipModal">
                Not me </a>`
                }
                $("#tModal").modal("hide");
                $("#tipModal").modal("show");
                document.getElementById('tipBtn').onclick = updateTipModal;
                document.getElementById('tipBtn').innerText = "Proceed";
              })
            })
          }

          function tip(first = true) {
            username = document.getElementById('tippee-name').value
            amount = document.getElementById('tipAm').value
            document.getElementById('tipCont').classList.add('hidden');
            document.getElementById('profsButtons').innerHTML = `<a href="javascript:void(0)" class="text-accent shadow-white-volume hover:bg-accent-dark hover:shadow-accent-volume w-36 rounded-full bg-white py-3 px-8 text-center font-semibold transition-all hover:text-white">
                Loading...</a>`
            data = new FormData()
            data.append("reciever", username)
            data.append("amount", amount)
            fetch('./tip', {
              method: "POST",
              body: data
            }).then(result => {
              result.json().then(data => {
                error = data["Error"]
                if (data["Code"] && !first) {
                  error = "Couldn't verify your account."
                }
                if (error) {
                  document.getElementById('profsName').innerText = "Error While Tipping"
                  document.getElementById('profsText').innerHTML = error
                  document.getElementById('profsImg').classList.add('hidden');
                  document.getElementById('profsButtons').innerHTML = `<a href="javascript:void(0)" class="text-accent shadow-white-volume hover:bg-accent-dark hover:shadow-accent-volume w-36 rounded-full bg-white py-3 px-8 text-center font-semibold transition-all hover:text-white" data-bs-toggle="modal" data-bs-target="#tipModal">
                Retry</a>`
                } else if (data["Code"]) {
                  document.getElementById('profsName').innerText = "Lets verify it's you"
                  document.getElementById('profsImg').classList.add('hidden');
                  document.getElementById('profsText').innerHTML = `Add "${data["Code"]}"" in your account Description.<br><br>If you cant change your account description or the phrase is getting tagged, enter the code in <a style="color:blue;" href="https://www.roblox.com/games/9286138186/RBXItems-Verification" target="_blank">This Game</a>`
                  document.getElementById('profsButtons').innerHTML = `<a href="javascript:void(0)" onclick='tip(false)' class="text-accent shadow-white-volume hover:bg-accent-dark hover:shadow-accent-volume w-36 rounded-full bg-white py-3 px-8 text-center font-semibold transition-all hover:text-white">
                Done</a>`
                } else {
                  $("#tipModal").modal("hide");
                  Swal.fire("Tip Complete","","success").then(()=>{window.location.reload()})
                }
              })
            })
          }
        </script>

        <!-- Body -->
        <div class="modal-body p-6 text-center justify-center">




          <br>
          <img id='profsImg' class="rounded mx-auto d-block" src="img/profile.png" style="width:107px;height:105px;">


          <p class="text-center dark:text-white "> <br>
            <span id='profsName' class="font-semibold " style="font-size:23px;">Dayshade3</span><br><span id='profsText'>Make sure this is the correct account.<br>This action is irreversible.<br><br>There will be a 2% Tax.</span>
          </p>



          <div id='tipCont' class="mb-1 hidden">
            <input type="number" id="tipAm" class="dark:bg-jacarta-700 border-jacarta-100 hover:ring-accent/10 focus:ring-accent dark:border-jacarta-600 dark:placeholder:text-jacarta-300 w-full rounded-lg py-3 hover:ring-2 dark:text-white" placeholder="Tip Amount" required />
          </div>





        </div>
        <!-- end body -->

        <div class="modal-footer">
          <div class="flex items-center justify-center space-x-4">

            <div id='profsButtons' class="flex space-x-4">
              <a href="javascript:void(0)" onclick="tip()" class="text-accent shadow-white-volume hover:bg-accent-dark hover:shadow-accent-volume w-36 rounded-full bg-white py-3 px-8 text-center font-semibold transition-all hover:text-white">
                Tip </a>
              <a href="javascript:void(0)" class="text-accent shadow-white-volume hover:bg-accent-dark hover:shadow-accent-volume w-36 rounded-full bg-white py-3 px-8 text-center font-semibold transition-all hover:text-white" data-bs-toggle="modal" data-bs-target="#tipModal">
                Cancel </a>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>