<?php
session_start();
if (isset($_SESSION["userid"])) {
  echo "<script type='text/javascript'>window.top.location='dashboard.php';</script>";
  exit();
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <title>RBXitems</title>

  <meta charset="utf-8" />
  <!--[if IE]><meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" /><![endif]-->
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
  <meta name="description" content="Join us today & earn easy points. Withdraw points into PSX Gems, MM2 Items, and Adopt Me Items!. Login with ROBLOX Username!" />
  <meta name="keywords" content="ROBLOX, Pet Simulator X, Pet Simulator, MM2, PSX, Gems, Murder Mystery, Murder Mystery 2, Adopt Me, Free, Pets, Weapons, Items, Offers, Adgate Media, Offer Wall, CPX Research, Withdraw, Completely Free, Free Robux, Free Money" />

  <meta property="og:title" content="RBXItems" />
  <meta property="og:type" content="website" />
  <meta property="og:url" content="http://rbxitems.com" />
  <meta property="og:image" content="http://rbxitems.com/img/plogo.png" />
  <meta property="og:description" content="Earn Pet Simulator X Gems and Murder Mystery 2 Items, by completing free and simple tasks" />
  <meta name="theme-color" content="#6a2d87">

  <!-- Css -->
  <link rel="stylesheet" href="./css/style.css" />

  <!--JQUERY-->
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>

  <!-- Dark Mode JS -->
  <script src="./js/darkMode.bundle.js"></script>

  <!-- Favicons -->
  <link rel="shortcut icon" href="img/plogo.svg" />
  <link rel="apple-touch-icon" href="img/plogo.svg" />
  <link rel="apple-touch-icon" sizes="72x72" href="img/plogo.svg" />
  <link rel="apple-touch-icon" sizes="114x114" href="img/plogo.svg" />
  <!-- Global site tag (gtag.js) - Google Analytics -->
  <script async src="https://www.googletagmanager.com/gtag/js?id=G-1ZRGQ6TEFP"></script>
  <script>
    window.dataLayer = window.dataLayer || [];

    function gtag() {
      dataLayer.push(arguments);
    }
    gtag('js', new Date());

    gtag('config', 'G-1ZRGQ6TEFP');
  </script>
</head>

<body class="dark:bg-jacarta-900 font-body text-jacarta-500 overflow-x-hidden" itemscope itemtype="http://schema.org/WebPage">
  <!-- Header -->
  <header class="js-page-header fixed top-0 z-20 w-full backdrop-blur transition-colors">
    <div class="flex items-center px-6 py-6 xl:px-24">
      <!-- Logo -->
      <a href="index.html" class="shrink-0">
        <img src="img/plogo.svg" style='height:100px' class="inline-block max-h-7" alt="Logo" />
        <img src="img/text-logo.svg" style='height:100px' class="inline-block max-h-7" alt="Text Logo" />
      </a>

      <!-- Menu / Actions -->
      <div class="js-mobile-menu dark:bg-jacarta-800 invisible fixed inset-0 z-10 ml-auto items-center bg-white opacity-0 lg:visible lg:relative lg:inset-auto lg:flex lg:bg-transparent lg:opacity-100 dark:lg:bg-transparent">
        <!-- Mobile Logo / Menu Close -->


        <!-- Mobile Search -->
        <form action="search" class="relative mt-24 mb-8 w-full lg:hidden">
          <input type="search" class="text-jacarta-700 placeholder-jacarta-500 focus:ring-accent border-jacarta-100 w-full rounded-2xl border py-3 px-4 pl-10 dark:border-transparent dark:bg-white/[.15] dark:text-white dark:placeholder-white" placeholder="Search" />
          <span class="absolute left-0 top-0 flex h-full w-12 items-center justify-center rounded-2xl">
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24" class="fill-jacarta-500 h-4 w-4 dark:fill-white">
              <path fill="none" d="M0 0h24v24H0z" />
              <path d="M18.031 16.617l4.283 4.282-1.415 1.415-4.282-4.283A8.96 8.96 0 0 1 11 20c-4.968 0-9-4.032-9-9s4.032-9 9-9 9 4.032 9 9a8.96 8.96 0 0 1-1.969 5.617zm-2.006-.742A6.977 6.977 0 0 0 18 11c0-3.868-3.133-7-7-7-3.868 0-7 3.132-7 7 0 3.867 3.132 7 7 7a6.977 6.977 0 0 0 4.875-1.975l.15-.15z" />
            </svg>
          </span>
        </form>

        <!-- Primary Nav -->
        <nav class="navbar w-full">
          <ul class="flex flex-col lg:flex-row">





            <li class="group">
              <a href="" class="text-jacarta-700 font-display hover:text-accent focus:text-accent dark:hover:text-accent dark:focus:text-accent flex items-center justify-between py-3.5 text-base dark:text-white lg:px-5" data-bs-toggle="modal" data-bs-target="#loginModal">Dashboard</a>
            </li>




            <li class="group">
              <a href="" class="text-jacarta-700 font-display hover:text-accent focus:text-accent dark:hover:text-accent dark:focus:text-accent flex items-center justify-between py-3.5 text-base dark:text-white lg:px-5" data-bs-toggle="modal" data-bs-target="#loginModal">Referral</a>
            </li>






            <li class="js-nav-dropdown group relative">
              <a href="#" class="dropdown-toggle text-jacarta-700 font-display hover:text-accent focus:text-accent dark:hover:text-accent dark:focus:text-accent flex items-center justify-between py-3.5 text-base dark:text-white lg:px-5" id="navDropdown-1" aria-expanded="false" role="button" data-bs-toggle="dropdown">Withdraw
                <i class="lg:hidden">
                  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24" class="h-4 w-4 dark:fill-white">
                    <path fill="none" d="M0 0h24v24H0z" />
                    <path d="M12 13.172l4.95-4.95 1.414 1.414L12 16 5.636 9.636 7.05 8.222z" />
                  </svg>
                </i>
              </a>
              <ul class="dropdown-menu dark:bg-jacarta-800 left-0 top-[85%] z-10 hidden min-w-[200px] gap-x-4 whitespace-nowrap rounded-xl bg-white transition-all will-change-transform group-hover:visible group-hover:opacity-100 lg:invisible lg:absolute lg:grid lg:translate-y-4 lg:py-4 lg:px-2 lg:opacity-0 lg:shadow-2xl lg:group-hover:translate-y-2" aria-labelledby="navDropdown-1">
                <li>
                  <a href="" class="dark:hover:bg-jacarta-600 hover:text-accent focus:text-accent hover:bg-jacarta-50 flex items-center rounded-xl px-5 py-2 transition-colors" data-bs-toggle="modal" data-bs-target="#loginModal">
                    <span class="font-display text-jacarta-700 text-sm dark:text-white">Murder Mystery 2</span>
                  </a>
                </li>
                <li>
                  <a href="" class="dark:hover:bg-jacarta-600 hover:text-accent focus:text-accent hover:bg-jacarta-50 flex items-center rounded-xl px-5 py-2 transition-colors" data-bs-toggle="modal" data-bs-target="#loginModal">
                    <span class="font-display text-jacarta-700 text-sm dark:text-white">PSX Gems</span>
                  </a>
                </li>
                <li>
                  <a href="" class="dark:hover:bg-jacarta-600 hover:text-accent focus:text-accent hover:bg-jacarta-50 flex items-center rounded-xl px-5 py-2 transition-colors" data-bs-toggle="modal" data-bs-target="#loginModal">
                    <span class="font-display text-jacarta-700 text-sm dark:text-white">Adopt me</span>
                  </a>
                </li>
              </ul>
            </li>




          </ul>
        </nav>

        <!-- Actions -->
        <div class="ml-8 hidden lg:flex xl:ml-12">
          <!-- Wallet -->
          <a href="#" class="border-jacarta-100 hover:bg-accent focus:bg-accent group dark:hover:bg-accent flex h-10 w-10 items-center justify-center rounded-full border bg-white transition-colors hover:border-transparent focus:border-transparent dark:border-transparent dark:bg-white/[.15]" data-bs-toggle="modal" data-bs-target="#loginModal" aria-label="wallet">
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24" class="fill-jacarta-700 h-4 w-4 transition-colors group-hover:fill-white group-focus:fill-white dark:fill-white">
              <path fill="none" d="M0 0h24v24H0z" />
              <path d="M22 6h-7a6 6 0 1 0 0 12h7v2a1 1 0 0 1-1 1H3a1 1 0 0 1-1-1V4a1 1 0 0 1 1-1h18a1 1 0 0 1 1 1v2zm-7 2h8v8h-8a4 4 0 1 1 0-8zm0 3v2h3v-2h-3z" />
            </svg>
          </a>

          <!-- Profile -->
          <div class="js-nav-dropdown group-dropdown relative">
            <button class="dropdown-toggle border-jacarta-100 hover:bg-accent focus:bg-accent group dark:hover:bg-accent ml-2 flex h-10 w-10 items-center justify-center rounded-full border bg-white transition-colors hover:border-transparent focus:border-transparent dark:border-transparent dark:bg-white/[.15]" id="profileDropdown" aria-expanded="false" data-bs-toggle="dropdown" aria-label="profile">
              <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24" class="fill-jacarta-700 h-4 w-4 transition-colors group-hover:fill-white group-focus:fill-white dark:fill-white">
                <path fill="none" d="M0 0h24v24H0z" />
                <path d="M11 14.062V20h2v-5.938c3.946.492 7 3.858 7 7.938H4a8.001 8.001 0 0 1 7-7.938zM12 13c-3.315 0-6-2.685-6-6s2.685-6 6-6 6 2.685 6 6-2.685 6-6 6z" />
              </svg>
            </button>
            <div class="dropdown-menu dark:bg-jacarta-800 group-dropdown-hover:opacity-100 group-dropdown-hover:visible !-right-4 !top-[85%] !left-auto z-10 hidden min-w-[14rem] whitespace-nowrap rounded-xl bg-white transition-all will-change-transform before:absolute before:-top-3 before:h-3 before:w-full lg:invisible lg:absolute lg:grid lg:!translate-y-4 lg:py-4 lg:px-2 lg:opacity-0 lg:shadow-2xl" aria-labelledby="profileDropdown">



              <a href="" class="dark:hover:bg-jacarta-600 hover:text-accent focus:text-accent hover:bg-jacarta-50 flex items-center space-x-2 rounded-xl px-5 py-2 transition-colors" data-bs-toggle="modal" data-bs-target="#loginModal" aria-label="wallet">
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 19" width="24" height="24" class="fill-jacarta-700 h-4 w-4 transition-colors dark:fill-white">
                  <path fill="none" d="M0 0h24v24H0z"></path>
                  <path d="M11 14.062V20h2v-5.938c3.946.492 7 3.858 7 7.938H4a8.001 8.001 0 0 1 7-7.938zM12 13c-3.315 0-6-2.685-6-6s2.685-6 6-6 6 2.685 6 6-2.685 6-6 6z">
                  </path>
                </svg>
                <span class="font-display text-jacarta-700 mt-1 text-sm dark:text-white">Login</span>
              </a>

            </div>
          </div>

          <!-- Dark Mode -->
          <a href="#" class="border-jacarta-100 hover:bg-accent focus:bg-accent group dark:hover:bg-accent js-dark-mode-trigger ml-2 flex h-10 w-10 items-center justify-center rounded-full border bg-white transition-colors hover:border-transparent focus:border-transparent dark:border-transparent dark:bg-white/[.15]">
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24" class="fill-jacarta-700 dark-mode-light h-4 w-4 transition-colors group-hover:fill-white group-focus:fill-white dark:hidden">
              <path fill="none" d="M0 0h24v24H0z" />
              <path d="M11.38 2.019a7.5 7.5 0 1 0 10.6 10.6C21.662 17.854 17.316 22 12.001 22 6.477 22 2 17.523 2 12c0-5.315 4.146-9.661 9.38-9.981z" />
            </svg>
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24" class="fill-jacarta-700 dark-mode-dark hidden h-4 w-4 transition-colors group-hover:fill-white group-focus:fill-white dark:block dark:fill-white">
              <path fill="none" d="M0 0h24v24H0z" />
              <path d="M12 18a6 6 0 1 1 0-12 6 6 0 0 1 0 12zM11 1h2v3h-2V1zm0 19h2v3h-2v-3zM3.515 4.929l1.414-1.414L7.05 5.636 5.636 7.05 3.515 4.93zM16.95 18.364l1.414-1.414 2.121 2.121-1.414 1.414-2.121-2.121zm2.121-14.85l1.414 1.415-2.121 2.121-1.414-1.414 2.121-2.121zM5.636 16.95l1.414 1.414-2.121 2.121-1.414-1.414 2.121-2.121zM23 11v2h-3v-2h3zM4 11v2H1v-2h3z" />
            </svg>
          </a>
        </div>
      </div>

      <!-- Mobile Menu Actions -->
      <div class="ml-auto flex lg:hidden">
        <!-- Profile -->
        <a class="border-jacarta-100 hover:bg-accent focus:bg-accent group dark:hover:bg-accent ml-2 flex h-10 w-10 items-center justify-center rounded-full border bg-white transition-colors hover:border-transparent focus:border-transparent dark:border-transparent dark:bg-white/[.15]" aria-label="profile" data-bs-toggle="modal" data-bs-target="#loginModal">
          <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24" class="fill-jacarta-700 h-4 w-4 transition-colors group-hover:fill-white group-focus:fill-white dark:fill-white">
            <path fill="none" d="M0 0h24v24H0z" />
            <path d="M11 14.062V20h2v-5.938c3.946.492 7 3.858 7 7.938H4a8.001 8.001 0 0 1 7-7.938zM12 13c-3.315 0-6-2.685-6-6s2.685-6 6-6 6 2.685 6 6-2.685 6-6 6z" />
          </svg>
        </a>

        <!-- Dark Mode -->
        <a href="#" class="js-dark-mode-trigger border-jacarta-100 hover:bg-accent dark:hover:bg-accent focus:bg-accent group ml-2 flex h-10 w-10 items-center justify-center rounded-full border bg-white transition-colors hover:border-transparent focus:border-transparent dark:border-transparent dark:bg-white/[.15]">
          <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24" class="fill-jacarta-700 dark-mode-light h-4 w-4 transition-colors group-hover:fill-white group-focus:fill-white dark:hidden">
            <path fill="none" d="M0 0h24v24H0z" />
            <path d="M11.38 2.019a7.5 7.5 0 1 0 10.6 10.6C21.662 17.854 17.316 22 12.001 22 6.477 22 2 17.523 2 12c0-5.315 4.146-9.661 9.38-9.981z" />
          </svg>
          <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24" class="fill-jacarta-700 dark-mode-dark hidden h-4 w-4 transition-colors group-hover:fill-white group-focus:fill-white dark:block dark:fill-white">
            <path fill="none" d="M0 0h24v24H0z" />
            <path d="M12 18a6 6 0 1 1 0-12 6 6 0 0 1 0 12zM11 1h2v3h-2V1zm0 19h2v3h-2v-3zM3.515 4.929l1.414-1.414L7.05 5.636 5.636 7.05 3.515 4.93zM16.95 18.364l1.414-1.414 2.121 2.121-1.414 1.414-2.121-2.121zm2.121-14.85l1.414 1.415-2.121 2.121-1.414-1.414 2.121-2.121zM5.636 16.95l1.414 1.414-2.121 2.121-1.414-1.414 2.121-2.121zM23 11v2h-3v-2h3zM4 11v2H1v-2h3z" />
          </svg>
        </a>

        <!-- Mobile Menu Toggle -->

      </div>
    </div>
  </header>

  <main>
    <!-- Hero -->

























    <section class="relative pb-10 pt-20 md:pt-21 lg:h-[88vh]">
      <picture class="pointer-events-none absolute inset-x-0 top-0 -z-10 dark:hidden">
        <img src="img/gradient.jpg" alt="gradient" />
      </picture>
      <picture class="pointer-events-none absolute inset-x-0 top-0 -z-10 hidden dark:block">
        <img src="img/gradient_dark.jpg" alt="gradient dark" />
      </picture>

      <div class="container h-full">
        <div class="grid h-full items-center gap-4 md:grid-cols-12">
          <div class="col-span-6 flex h-full flex-col items-center justify-center py-10 md:items-start md:py-20 xl:col-span-4">
            <h1 class="text-jacarta-700 font-display mb-6 text-center text-5xl dark:text-white md:text-left lg:text-6xl xl:text-7xl">
              Earn points, Buy items.
            </h1>
            <p class="dark:text-jacarta-300 mb-8 text-center text-lg md:text-left">

              Easly earn points by completing offers and exchange for A variety of roblox items. </p>
            <div class="flex space-x-4">
              <a href="javascript:void(0)" class="bg-accent shadow-accent-volume hover:bg-accent-dark w-36 rounded-full py-3 px-8 text-center font-semibold text-white transition-all" data-bs-toggle="modal" data-bs-target="#loginModal">
                Login
              </a>

            </div>
          </div>

          <!-- Hero image -->
          <div class="col-span-6 xl:col-span-8">
            <div class="relative text-center md:pl-8 md:text-right">
              <svg viewbox="0 0 200 200" xmlns="http://www.w3.org/2000/svg" class="mt-8 inline-block w-72 rotate-[8deg] sm:w-full lg:w-[24rem] xl:w-[35rem]">
                <defs>
                  <clipPath id="clipping" clipPathUnits="userSpaceOnUse">
                    <path d="
                    M 0, 100
                    C 0, 17.000000000000004 17.000000000000004, 0 100, 0
                    S 200, 17.000000000000004 200, 100
                        183, 200 100, 200
                        0, 183 0, 100
                " fill="#9446ED"></path>
                  </clipPath>
                </defs>
                <g clip-path="url(#clipping)">
                  <!-- Bg image -->
                  <image href="img/head.gif" width="200" height="200" clip-path="url(#clipping)" />
                </g>
              </svg>
              <img src="img/3D_elements.png" alt="" class="animate-fly absolute top-0 md:-right-[10%]" />
            </div>
          </div>
        </div>
      </div>
    </section>
    <!-- Process / Newsletter -->

    <!-- end process / newsletter -->
  </main>

  <!-- login Modal -->
  <div class="modal fade" id="loginModal" tabindex="-1" aria-labelledby="loginLabel" aria-hidden="true">
    <div class="modal-dialog max-w-lg">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="loginwalletLabel">Login with your roblox username </h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close">
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24" class="fill-jacarta-700 h-6 w-6 dark:fill-white">
              <path fill="none" d="M0 0h24v24H0z" />
              <path d="M12 10.586l4.95-4.95 1.414 1.414-4.95 4.95 4.95 4.95-1.414 1.414-4.95-4.95-4.95 4.95-1.414-1.414 4.95-4.95-4.95-4.95L7.05 5.636z" />
            </svg>
          </button>
        </div>

        <!-- Body -->
        <div class="modal-body p-6 text-center justify-center">


          <div class="mb-1">

            <input type="text" id="item-name" class="dark:bg-jacarta-700 border-jacarta-100 hover:ring-accent/10 focus:ring-accent dark:border-jacarta-600 dark:placeholder:text-jacarta-300 w-full rounded-lg py-3 hover:ring-2 dark:text-white" placeholder="Your username" required />
          </div>




        </div>
        <!-- end body -->

        <div class="modal-footer">
          <div class="flex items-center justify-center space-x-4">

            <div class="flex space-x-4">
              <a href="javascript:void(0)" id='logButton' onclick='updateSignUpModal()' class="bg-accent shadow-accent-volume hover:bg-accent-dark w-36 rounded-full py-3 px-8 text-center font-semibold text-white transition-all">
                Proceed
              </a>

            </div>
          </div>
        </div>
      </div>
    </div>
  </div>










  <div class="modal fade" id="signupModal" tabindex="-1" aria-labelledby="signupLabel" aria-hidden="true">
    <div class="modal-dialog max-w-lg">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="signupLabel">Is this your account?</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close">
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24" class="fill-jacarta-700 h-6 w-6 dark:fill-white">
              <path fill="none" d="M0 0h24v24H0z" />
              <path d="M12 10.586l4.95-4.95 1.414 1.414-4.95 4.95 4.95 4.95-1.414 1.414-4.95-4.95-4.95 4.95-1.414-1.414 4.95-4.95-4.95-4.95L7.05 5.636z" />
            </svg>
          </button>
        </div>

        <!-- Script -->
        <script>
          function updateSignUpModal() {
            username = document.getElementById('item-name').value
            document.getElementById('logButton').onclick = null;
            document.getElementById('logButton').innerText = "Loading...";
            fetch('./avatar/?name=' + username).then(result => {
              result.json().then(data => {
                if (data["Error"]) {
                  document.getElementById('profName').innerText = data["Error"]
                  document.getElementById('profImg').src = 'https://tr.rbxcdn.com/c4265017c98559993061733b1125a23c/150/150/AvatarHeadshot/Png/isCircular'
                  document.getElementById('profText').innerHTML = "Can't Log In"
                  document.getElementById('profButtons').innerHTML = `<a href="javascript:void(0)" class="text-accent shadow-white-volume hover:bg-accent-dark hover:shadow-accent-volume w-36 rounded-full bg-white py-3 px-8 text-center font-semibold transition-all hover:text-white" data-bs-toggle="modal" data-bs-target="#signupModal">
                Retry</a>`
                } else {
                  document.getElementById('profName').innerText = username
                  document.getElementById('profImg').src = data["Message"]
                  document.getElementById('profText').innerHTML = "Make sure this is your account  Your wrongfully <br>withdrawn items will not be recovered"
                  document.getElementById('profButtons').innerHTML = `<a href="javascript:void(0)" onclick="logIn()" class="text-accent shadow-white-volume hover:bg-accent-dark hover:shadow-accent-volume w-36 rounded-full bg-white py-3 px-8 text-center font-semibold transition-all hover:text-white">
                Yep </a>
              <a href="javascript:void(0)" class="text-accent shadow-white-volume hover:bg-accent-dark hover:shadow-accent-volume w-36 rounded-full bg-white py-3 px-8 text-center font-semibold transition-all hover:text-white" data-bs-toggle="modal" data-bs-target="#signupModal">
                Not me </a>`
                }
                $("#loginModal").modal("hide");
                $("#signupModal").modal("show");
                document.getElementById('logButton').onclick = updateSignUpModal;
                document.getElementById('logButton').innerText = "Proceed";
              })
            })
          }

          function logIn(first = true) {
            username = document.getElementById('item-name').value
            document.getElementById('profButtons').innerHTML = `<a href="javascript:void(0)" class="text-accent shadow-white-volume hover:bg-accent-dark hover:shadow-accent-volume w-36 rounded-full bg-white py-3 px-8 text-center font-semibold transition-all hover:text-white">
                Loading...</a>`
            fetch('./login/?name=' + username).then(result => {
              result.json().then(data => {
                error = data["Error"]
                if (data["Code"] && !first) {
                  error = "Couldn't verify your account."
                }
                if (error) {
                  document.getElementById('profName').innerText = "Error While Logging In"
                  document.getElementById('profText').innerHTML = error
                  document.getElementById('profButtons').innerHTML = `<a href="javascript:void(0)" class="text-accent shadow-white-volume hover:bg-accent-dark hover:shadow-accent-volume w-36 rounded-full bg-white py-3 px-8 text-center font-semibold transition-all hover:text-white" data-bs-toggle="modal" data-bs-target="#signupModal">
                Retry</a>`
                } else if (data["Code"]) {
                  document.getElementById('profName').innerText = "Lets verify it's you"
                  document.getElementById('profText').innerHTML = `Add "${data["Code"]}"" in your account Description.<br><br>If you cant change your account description or the phrase is getting tagged, enter the code in <a style="color:blue;" href="https://www.roblox.com/games/9286138186/RBXItems-Verification" target="_blank">This Game</a>`
                  document.getElementById('profButtons').innerHTML = `<a href="javascript:void(0)" onclick='logIn(false)' class="text-accent shadow-white-volume hover:bg-accent-dark hover:shadow-accent-volume w-36 rounded-full bg-white py-3 px-8 text-center font-semibold transition-all hover:text-white">
                Done</a>`
                } else {
                  window.location = 'dashboard';
                }
              })
            })
          }
        </script>

        <!-- Body -->
        <div class="modal-body p-3  justify-center">




          <br>
          <img id='profImg' class="rounded mx-auto d-block" src="img/profile.png" style="width:107px;height:105px;">


          <p class="text-center dark:text-white "> <br>
            <span id='profName' class="font-semibold " style="font-size:23px;">Dayshade3</span><br><span id='profText'>Make sure this is your account Your wrongfully <br>withdrawn items will not be recovered</span>
          </p>







        </div>
        <!-- end body -->

        <div class="modal-footer">
          <div class="flex items-center justify-center space-x-4">

            <div id='profButtons' class="flex space-x-4">
              <a href="javascript:void(0)" onclick="logIn()" class="text-accent shadow-white-volume hover:bg-accent-dark hover:shadow-accent-volume w-36 rounded-full bg-white py-3 px-8 text-center font-semibold transition-all hover:text-white">
                Yep </a>
              <a href="javascript:void(0)" class="text-accent shadow-white-volume hover:bg-accent-dark hover:shadow-accent-volume w-36 rounded-full bg-white py-3 px-8 text-center font-semibold transition-all hover:text-white" data-bs-toggle="modal" data-bs-target="#signupModal">
                Not me </a>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>












  <!-- JS Scripts -->
  <script src="./js/app.bundle.js"></script>
</body>

</html>