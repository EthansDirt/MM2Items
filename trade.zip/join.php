<?php
session_start();
?>
<head>
  <meta property="og:title" content="RBXItems" />
  <meta property="og:type" content="website" />
  <meta property="og:image" content="http://rbxitems.com/img/plogo.png" />
  <meta property="og:description" content="Earn Pet Simulator X Gems and Murder Mystery 2 Items, by completing free and simple tasks" />
  <meta name="theme-color" content="#6a2d87">
</head>
<?php
if (isset($_SESSION["userid"])) {
    echo "<script type='text/javascript'>window.top.location='main.php';</script>";
    exit();
}
if (isset($_GET["ref"])) {
    $_SESSION["ref"] = $_GET["ref"];
    echo "<script type='text/javascript'>window.top.location='./';</script>";
    exit();
}
?>