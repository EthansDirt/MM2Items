<?php
session_start();
function getIPAddress()
{
    //whether ip is from the share internet  
    if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
        $ip = $_SERVER['HTTP_CLIENT_IP'];
    }
    //whether ip is from the proxy  
    elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
        $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
    }
    //whether ip is from the remote address  
    else {
        $ip = $_SERVER['REMOTE_ADDR'];
    }
    return $ip;
}
$ip = getIPAddress();
if (!isset($_SESSION["specialHash"])) {
    $_SESSION["specialHash"] = hash("sha256","gamb_".$ip);
}
if (isset($_SESSION["username"])) {
    echo '{"Error":"Already Logged In!"}';
} else {
    if ($_GET["name"]) {
        $url = "https://api.roblox.com/users/get-by-username?username=" . $_GET["name"];

        $curl = curl_init($url);
        curl_setopt($curl, CURLOPT_URL, $url);
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
        $resp = curl_exec($curl);
        curl_close($curl);
        if (isset(json_decode($resp)->Id)) {
            include "commands.php";
            if (getUserData(json_decode($resp)->Id) and getUserData(json_decode($resp)->Id)["Rank"] >= 1) {
                $code = hash('md5', 'gamb_' . $_GET["name"] . $_SESSION["specialHash"]);
                $words = file("words.txt");
                $id = json_decode($resp)->Id;
                $url = "https://users.roblox.com/v1/users/" . $id;

                $curl = curl_init($url);
                curl_setopt($curl, CURLOPT_URL, $url);
                curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
                $resp = curl_exec($curl);
                curl_close($curl);
                $desc = json_decode($resp)->description;
                $newcode = "";
                for ($i = 0; $i <= 15; $i++) {
                    $c = hexdec($code[$i * 2] . $code[$i * 2 + 1]);
                    $newcode = $newcode . rtrim($words[$c]) . " ";
                }
                $newcode = rtrim($newcode);
                if (strpos($desc, $newcode) !== false or $conn->query("SELECT * FROM `descriptions` WHERE `UserId`='$id' AND `Code`='$newcode'")->fetch_assoc()) {
                    $_SESSION["username"] = json_decode($resp)->name;
                    $_SESSION["userid"] = $id;
                    echo '{"Error":false}';
                } else {
                    echo '{"Error":false,"Code":"' . $newcode . '"}';
                }
            } else {
                $_SESSION["username"] = json_decode($resp)->Username;
                $_SESSION["userid"] = json_decode($resp)->Id;
                echo '{"Error":false}';
            }
        } else {
            echo '{"Error":"This username does not exist"}';
        }
    } else {
        echo '{"Error":"Roblox username can not be empty"}';
    }
}
