<?php
$load = sys_getloadavg();
if ($load[0] > 16) {
    header('HTTP/1.1 503 Too busy, try again later');
    die('{"stock":{"Murder Mystery 2":{}},"purchases":{"token":[],"item":{"Murder Mystery 2":{}}}}');
}
//require_once('../rate-limit.php');
if ($_SERVER['REMOTE_ADDR'] != "45.58.126.29") {
    echo $_SERVER['REMOTE_ADDR']; 
    exit();
}
$first_value = key($_POST);
if(gettype($first_value) == "string" && is_object(json_decode($first_value))){
    $_POST = json_decode($first_value,true);
}

foreach($_POST as $key => $value){
    if(gettype($value) == "string"){
        $_POST[$key] = str_replace("_"," ",$value);
    }
}

if(file_exists("data.json") == false){
    $file = fopen("data.json","w");
    fwrite($file,json_encode(array(
        "stock" => array(),
        "purchases" => array(
            "token" => array(),
            "item" => array()
        )
    )));
    fclose($file);
}

function get_data(){
    $file = fopen("data.json","r");
    $data = json_decode(fread($file,filesize("data.json")),true);
    fclose($file);
    return $data;
}

function set_data($data){
    $file = fopen("data.json","w");
    fwrite($file,json_encode($data));
    fclose($file);
}

if(gettype($_POST) == "string"){
    $_POST = json_decode($_POST,true);
}

$condition = "";
if(array_key_exists("condition",$_GET)){
    $condition = $_GET["condition"];
}elseif(array_key_exists("condition",$_POST)){
    $condition = $_POST["condition"];
}

if($condition == "ReplaceStock"){
    $stock = json_decode($_POST["stock"],true);
    $data = get_data();
    $data["stock"][$_POST["game"]] = $stock;
    set_data($data);
}elseif($condition == "ClearStock"){
    $game = $_POST["game"];
    $data = get_data();
    if(array_key_exists($game,$data["stock"])){
        $data["stock"][$game] = array();
    }
    set_data($data);
}elseif($condition == "GetStock"){
    $data = get_data();
    print(json_encode($data["stock"]));
}elseif($condition == "NewPurchase"){
    if($_POST["type"] == "Tokens"){
        $data = get_data();
        $new_data = array(
            "roblox" => intval($_POST["roblox"]),
            "price" => intval($_POST["price"]),
            "tokens" => intval($_POST["amount"]),
            "completed" => false
        );
        array_push($data["purchases"]["token"],$new_data);
        set_data($data);
    }
}elseif($condition == "GetData"){
    print(json_encode(get_data()));
}elseif($condition == "PurchaseComplete"){
    if($_GET["Type"] == "Tokens"){
        $userid = $_GET["roblox"];
        $data = get_data();
        $old = $data["purchases"]["token"];
        foreach($old as $i => $v){
            if($v["roblox"] == intval($userid)){
                $old[$i]["completed"] = true;
            }
        };
        unset($data["purchases"]["token"]);
        $data["purchases"]["token"] = $old;
        set_data($data);
    }
}elseif($condition == "GetPurchaseData"){
    $type = $_GET["Type"];
    $roblox = intval($_GET["roblox"]);
    $data = get_data();
    foreach($data["purchases"][$type] as $info){
        if($info["roblox"] == $roblox){
            print(json_encode($info));
            return;
        }
    }
    print("[]");
}elseif($condition == "ClearPurchaseData"){
    $type = $_POST["type"];
    $roblox = intval($_POST["roblox"]);
    $data = get_data();
    foreach($data["purchases"][$type] as $key => $info){
        if($info["roblox"] == $roblox){
            unset($data["purchases"][$type][$key]);
        }
    }
    set_data($data);
}elseif($condition == "SendItems"){
    $game = $_POST["game"];
    $roblox = intval($_POST["roblox"]);
    $items = json_decode($_POST["items"],true);
    $tid = $_POST["tid"];
    $data = get_data();
    $stock = $data["stock"][$game];
    
    // Checks if the item is already reserved here and will make a 40
    if($game == "Flee the Facility" && array_key_exists($game,$data["purchases"]["item"])){
        foreach($items as $PurchasedItem => $PurchasedItemAmount){
            $ClaimedAmount = 0;
            $StockCount = 0;
            foreach($stock as $ItemType => $ItemTypeData){
                $PurchasedItemType = "Hammers";
                if(strpos($PurchasedItem,"Gems")){
                    $PurchasedItemType = "Gems";
                }
                $RealItem = explode(" ".$ItemType,$PurchasedItem)[0];
                if($ItemType == $PurchasedItemType){
                    if(!array_key_exists($RealItem,$ItemTypeData) || $ItemTypeData[$RealItem] < $PurchasedItemAmount){
                        print(json_encode(array(
                           "Success" => false,
                           "Error" => "Item Taken From Inventory",
                           "Data" => array(
                               "Item" => $PurchasedItem
                            )
                        )));
                        return;
                    }
                }
                
                foreach($ItemTypeData as $StockItem => $StockData){
                    if($StockItem." ".$ItemType == $PurchasedItem){
                        foreach($data["purchases"]["item"][$game] as $OtherPurchase){
                            foreach($OtherPurchase["Items"] as $OtherPurchaseItem => $OtherPurchaseAmount){
                                if($OtherPurchaseItem == $PurchasedItem){
                                    $ClaimedAmount = $ClaimedAmount + $OtherPurchaseAmount;
                                    $StockCount = $StockData["Amount"];
                                }
                            }
                        }
                    }
                }
            }
            if($ClaimedAmount > 0 && $StockCount - $ClaimedAmount < $PurchasedItemAmount){
                print(json_encode(array(
                   "Success" => false,
                   "Error" => "Item Reserved",
                   "Data" => array(
                       "Item" => $PurchasedItem,
                       "Amount" => $ClaimedAmount,
                       "Remaining" => $StockCount - $ClaimedAmount
                   )
                )));
                return;
            }
        }
    }elseif($game == "Murder Mystery 2" && array_key_exists($game,$data["purchases"]["item"])){
        foreach($items as $PurchasedItem => $PurchasedItemAmount){
            $ClaimedAmount = 0;
            $StockCount = 0;
            if(!array_key_exists($PurchasedItem,$stock) || $stock[$PurchasedItem] < $PurchasedItemAmount){
                print(json_encode(array(
                    "Success" => false,
                    "Error" => "Item Taken From Inventory",
                    "Data" => array(
                        "Item" => $PurchasedItem
                    )
                )));
                return;
            }
            foreach($stock as $StockItem => $StockData){
                if($StockItem == $PurchasedItem){
                    foreach($data["purchases"]["item"][$game] as $OtherPurchase){
                        foreach($OtherPurchase["Items"] as $OtherPurchaseItem => $OtherPurchaseAmount){
                            if($OtherPurchaseItem == $PurchasedItem){
                                $ClaimedAmount = $ClaimedAmount + $OtherPurchaseAmount;
                                $StockCount = $StockData["Amount"];
                            }
                        }
                    }
                }
            }
            if($StockCount > 0 && $StockCount - $ClaimedAmount < $PurchasedItemAmount){
                print(json_encode(array(
                   "Success" => false,
                   "Error" => "Item Reserved",
                   "Data" => array(
                       "Item" => $PurchasedItem,
                       "Amount" => $ClaimedAmount,
                       "Remaining" => $StockCount - $ClaimedAmount
                   )
                )));
                return;
            }
        }
    }elseif($game == "Pet Simulator X" && array_key_exists($game,$data["purchases"]["item"])){
        $ClaimedAmount = 0;
        $StockCount = $data["stock"][$game]["Gems"];
        foreach($data["purchases"]["item"][$game] as $OtherPurchase){
            $ClaimedAmount = ($ClaimedAmount + $OtherPurchase["Items"]["Gems"]);
        }
        if($StockCount > 0 && $StockCount - $ClaimedAmount < $items["Gems"]){
            print(json_encode(array(
                "Success" => false,
                "Error" => "Item Reserved",
                "Data" => array(
                    "Item" => $items["Gems"],
                    "Amount" => $ClaimedAmount,
                    "Remaining" => $StockCount - $ClaimedAmount
                )
            )));
            return;
        }
    }
    
    if(array_key_exists($game,$data["purchases"]["item"])){
        foreach($data["purchases"]["item"][$game] as $Transaction){
            if($Transaction["UserId"] == $roblox){
                print(json_encode(array(
                    "Success" => false,
                    "Error" => "Already Purchased",
                )));
                return;
            }
        }
    }
    
    if(array_key_exists($game,$data["purchases"]["item"]) == false){
        $data["purchases"]["item"][$game] = array();
    }
    array_push($data["purchases"]["item"][$game],array(
        "Items" => $items,
        "UserId" => $roblox,
        "TID" => $tid
    ));
    set_data($data);
    print(json_encode(array(
        "Success" => true,
    )));
}elseif($condition == "GetGamePurchases"){
    $game = $_GET["game"];
    $data = get_data();
    if(array_key_exists($game,$data["purchases"]["item"]) == false){
        print("[]");
        return;
    }
    print(json_encode($data["purchases"]["item"][$game]));
}elseif($condition == "ItemsReceived"){
    $game = $_POST["game"];
    $roblox = intval($_POST["roblox"]);
    $data = get_data();
    if(array_key_exists($game,$data["purchases"]["item"]) == false){
        return;
    }
    foreach($data["purchases"]["item"][$game] as $index => $transaction){
        if($transaction["UserId"] == $roblox){
            include_once("../commands.php");
            sendWithdrawDiscord($roblox,"Murder Myster 2",array_keys($transaction["Items"])[0],0);
            unset($data["purchases"]["item"][$game][$index]);
        }
    }
    set_data($data);
}elseif($condition == "ChangeCurrencyAmount"){
    $game = $_POST["game"];
    $tid = $_POST["tid"];
    $currency = $_POST["currency"];
    $newvalue = intval($_POST["amount"]);
    $data = get_data();
    if(array_key_exists($game,$data["purchases"]["item"]) == false){
        return;
    }
    foreach($data["purchases"]["item"][$game] as $index => $transaction){
        if($transaction["TID"] == $tid){
            $data["purchases"]["item"][$game][$index]["Items"][$currency] = $newvalue;
        }
    }
    set_data($data);
}
?>