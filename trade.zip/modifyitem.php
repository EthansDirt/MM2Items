<?php
session_start();
include "commands.php";
if (!isset($_SESSION["userid"])) {
    jsonError("You are Not Logged In!");
}
if (getCurrentUserData()["Rank"] <= 0) {
    jsonError("You do not have permission to modify this!");
}
if (isset($_POST["id"]) and isset($_POST["price"]) and isset($_POST["name"]) and isset($_POST["img"])) {
    $img = urlencode($_POST["img"]);
    $id = urlencode($_POST["id"]);
    $price = intval($_POST["price"]);
    $name = $_POST["name"];
    if (!$conn->query("UPDATE `items` SET `Price`='$price',`DisplayName`='$name',`Image`='$img' WHERE `ItemId` = '$id'")) {
        jsonError($conn -> error);
    }
    jsonError(false);
} else {
    jsonError("Feature Under Maintenance!");
}
?>