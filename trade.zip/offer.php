<?php
session_start();
if (!isset($_SESSION["userid"])) {
  echo "<script type='text/javascript'>window.top.location='./';</script>";
  exit();
}
$title = "Dashboard";
require_once("header.php");
?>
<main>
  <!-- Hero Slider -->

  <!-- end hero slider -->

  <!-- Browse by Category -->

  <!-- end browse by category -->

  <!-- Hot Bids -->
  <section class="relative py-24">

    <div class="container">
      <h2 class="font-display text-jacarta-700 mb-8 text-center text-3xl dark:text-white">
        <br> <span class="mr-1 inline-block h-6 w-6 bg-contain bg-center text-xl"></span>
        <br> AdGate Media
      </h2>
      <br>
      <br>
      <div class="grid grid-cols-1 gap-12 md:grid-cols-2 lg:grid-cols-7">



        <div class="text-center">
          <div class="mb-6 inline-flex rounded-full bg-[#C4F2E3] p-3">
            <div class="bg-green inline-flex h-12 w-12 items-center justify-center rounded-full">
              <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24" class="h-5 w-5 fill-white">
                <path fill="none" d="M0 0h24v24H0z" />
                <path d="M3 13h8V3H3v10zm0 8h8v-6H3v6zm10 0h8V11h-8v10zm0-18v6h8V3h-8z" />
              </svg>
            </div>
          </div>
          <h3 class="font-display text-jacarta-700 mb-4 text-lg dark:text-white">Complete offers & tasks</h3>
          <p class="dark:text-jacarta-300 ">
            You can complete offers from the offerwall below to earn points.
          </p>
        </div>
        <div class="text-center">
          <div class="mb-6 inline-flex rounded-full bg-[#CDDFFB] p-3">
            <div class="bg-blue inline-flex h-12 w-12 items-center justify-center rounded-full">
              <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-bag-fill" viewBox="0 0 16 16 " style="fill: white;">
                <path d="M8 1a2.5 2.5 0 0 1 2.5 2.5V4h-5v-.5A2.5 2.5 0 0 1 8 1zm3.5 3v-.5a3.5 3.5 0 1 0-7 0V4H1v10a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V4h-3.5z" />
              </svg>
            </div>
          </div>
          <h3 class="font-display text-jacarta-700 mb-4 text-lg dark:text-white">Exchange points for items</h3>
          <p class="dark:text-jacarta-300">
            You can withdraw your points as different items. <br><br><br><br>
          </p>
        </div>
      </div>



      <div class="relative">
        <!-- Slider -->
        <div class="swiper card-slider-4-columns !py-5">
          <div class="swiper-wrapper">
            <!-- Slides -->
            
            <div class="swiper-slide">
              <article>
                <a href='offer.html' class="dark:bg-jacarta-700 dark:border-jacarta-700 border-jacarta-100 block rounded-[1.25rem] border bg-white p-[1.1875rem] transition-shadow hover:shadow-lg">
                  <figure>
                    <img src="./img/adgate.png" alt="item 1" style="height:271px;width:271px;" class="w-full rounded-[0.625rem]" loading="lazy" />
                  </figure>
                  <div class="mt-4 flex items-center justify-between">
                    <span class="font-display text-jacarta-700 hover:text-accent text-base dark:text-white">Adgate
                      Media</span>
                    <!--<span class="dark:border-jacarta-600 border-jacarta-100 flex items-center whitespace-nowrap rounded-md border py-1 px-2">
                      <span data-tippy-content="Gems">
                        <svg xmlns="http://www.w3.org/2000/svg" width="22" height="16" fill="currentColor" class="bi bi-gem" viewBox="0 0 22 16">
                          <path d="M3.1.7a.5.5 0 0 1 .4-.2h9a.5.5 0 0 1 .4.2l2.976 3.974c.149.185.156.45.01.644L8.4 15.3a.5.5 0 0 1-.8 0L.1 5.3a.5.5 0 0 1 0-.6l3-4zm11.386 3.785-1.806-2.41-.776 2.413 2.582-.003zm-3.633.004.961-2.989H4.186l.963 2.995 5.704-.006zM5.47 5.495 8 13.366l2.532-7.876-5.062.005zm-1.371-.999-.78-2.422-1.818 2.425 2.598-.003zM1.499 5.5l5.113 6.817-2.192-6.82L1.5 5.5zm7.889 6.817 5.123-6.83-2.928.002-2.195 6.828z" />
                        </svg>
                      </span>
                      <span class="text-green text-sm font-medium tracking-tight">+5</span>
                    </span>-->
                  </div>


                  <div class="mt-8 flex items-center justify-between">
                    <div class="text-accent font-display text-sm font-semibold" data-bs-toggle="modal" data-bs-target="#placeBidModal">
                      Enter </div>

                    <div class="flex items-center space-x-1">
                      <span class="js-likes relative cursor-pointer before:absolute before:h-4 before:w-4 before:bg-[url('../img/heart-fill.svg')] before:bg-cover before:bg-center before:bg-no-repeat before:opacity-0" data-tippy-content="Completed">
                        <svg xmlns="http://www.w3.org/2000/svg" x="0px" y="0px" width="20" height="20" viewBox="0 0 32 32" style=" fill:#000000;">
                          <path d="M 16 3 C 8.832031 3 3 8.832031 3 16 C 3 23.167969 8.832031 29 16 29 C 23.167969 29 29 23.167969 29 16 C 29 8.832031 23.167969 3 16 3 Z M 16 5 C 22.085938 5 27 9.914063 27 16 C 27 22.085938 22.085938 27 16 27 C 9.914063 27 5 22.085938 5 16 C 5 9.914063 9.914063 5 16 5 Z M 22.28125 11.28125 L 15 18.5625 L 10.71875 14.28125 L 9.28125 15.71875 L 14.28125 20.71875 L 15 21.40625 L 15.71875 20.71875 L 23.71875 12.71875 Z">
                          </path>
                        </svg>
                      </span>
                      <span class="dark:text-jacarta-200 text-sm"><?php echo $conn->query("SELECT COUNT(*) FROM `completedoffers` WHERE `Wall` = 'AdGate Media'")->fetch_row()[0] ?></span>
                    </div>
                  </div>
                </a>
              </article>
            </div>
            <div class="swiper-slide">
              <article>
                <a href='offer-ot.html' class="dark:bg-jacarta-700 dark:border-jacarta-700 border-jacarta-100 block rounded-[1.25rem] border bg-white p-[1.1875rem] transition-shadow hover:shadow-lg">
                  <figure>
                    <img src="./img/offertoro.png" alt="item 1" style="height:271px;width:271px;" class="w-full rounded-[0.625rem]" loading="lazy" />
                  </figure>
                  <div class="mt-4 flex items-center justify-between">
                    <span class="font-display text-jacarta-700 hover:text-accent text-base dark:text-white">OfferToro</span>
                    <!--<span class="dark:border-jacarta-600 border-jacarta-100 flex items-center whitespace-nowrap rounded-md border py-1 px-2">
                      <span data-tippy-content="Gems">
                        <svg xmlns="http://www.w3.org/2000/svg" width="22" height="16" fill="currentColor" class="bi bi-gem" viewBox="0 0 22 16">
                          <path d="M3.1.7a.5.5 0 0 1 .4-.2h9a.5.5 0 0 1 .4.2l2.976 3.974c.149.185.156.45.01.644L8.4 15.3a.5.5 0 0 1-.8 0L.1 5.3a.5.5 0 0 1 0-.6l3-4zm11.386 3.785-1.806-2.41-.776 2.413 2.582-.003zm-3.633.004.961-2.989H4.186l.963 2.995 5.704-.006zM5.47 5.495 8 13.366l2.532-7.876-5.062.005zm-1.371-.999-.78-2.422-1.818 2.425 2.598-.003zM1.499 5.5l5.113 6.817-2.192-6.82L1.5 5.5zm7.889 6.817 5.123-6.83-2.928.002-2.195 6.828z" />
                        </svg>
                      </span>
                      <span class="text-green text-sm font-medium tracking-tight">+5</span>
                    </span>-->
                  </div>


                  <div class="mt-8 flex items-center justify-between">
                    <div class="text-accent font-display text-sm font-semibold" data-bs-toggle="modal" data-bs-target="#placeBidModal">
                      Enter</div>

                    <div class="flex items-center space-x-1">
                      <span class="js-likes relative cursor-pointer before:absolute before:h-4 before:w-4 before:bg-[url('../img/heart-fill.svg')] before:bg-cover before:bg-center before:bg-no-repeat before:opacity-0" data-tippy-content="Completed">
                        <svg xmlns="http://www.w3.org/2000/svg" x="0px" y="0px" width="20" height="20" viewBox="0 0 32 32" style=" fill:#000000;">
                          <path d="M 16 3 C 8.832031 3 3 8.832031 3 16 C 3 23.167969 8.832031 29 16 29 C 23.167969 29 29 23.167969 29 16 C 29 8.832031 23.167969 3 16 3 Z M 16 5 C 22.085938 5 27 9.914063 27 16 C 27 22.085938 22.085938 27 16 27 C 9.914063 27 5 22.085938 5 16 C 5 9.914063 9.914063 5 16 5 Z M 22.28125 11.28125 L 15 18.5625 L 10.71875 14.28125 L 9.28125 15.71875 L 14.28125 20.71875 L 15 21.40625 L 15.71875 20.71875 L 23.71875 12.71875 Z">
                          </path>
                        </svg>
                      </span>
                      <span class="dark:text-jacarta-200 text-sm"><?php echo $conn->query("SELECT COUNT(*) FROM `completedoffers` WHERE `Wall` = 'OfferToro'")->fetch_row()[0] ?></span>
                    </div>
                  </div>
                </a>
              </article>
            </div>
            <div class="swiper-slide">
              <article>
                <a href='offer-pl.html' class="dark:bg-jacarta-700 dark:border-jacarta-700 border-jacarta-100 block rounded-[1.25rem] border bg-white p-[1.1875rem] transition-shadow hover:shadow-lg">
                  <figure>
                    <img src="./img/Personaly.svg" alt="item 1" style="height:271px;width:271px;" class="w-full rounded-[0.625rem]" loading="lazy" />
                  </figure>
                  <div class="mt-4 flex items-center justify-between">
                    <span class="font-display text-jacarta-700 hover:text-accent text-base dark:text-white">Persona.ly</span>
                    <!--<span class="dark:border-jacarta-600 border-jacarta-100 flex items-center whitespace-nowrap rounded-md border py-1 px-2">
                      <span data-tippy-content="Gems">
                        <svg xmlns="http://www.w3.org/2000/svg" width="22" height="16" fill="currentColor" class="bi bi-gem" viewBox="0 0 22 16">
                          <path d="M3.1.7a.5.5 0 0 1 .4-.2h9a.5.5 0 0 1 .4.2l2.976 3.974c.149.185.156.45.01.644L8.4 15.3a.5.5 0 0 1-.8 0L.1 5.3a.5.5 0 0 1 0-.6l3-4zm11.386 3.785-1.806-2.41-.776 2.413 2.582-.003zm-3.633.004.961-2.989H4.186l.963 2.995 5.704-.006zM5.47 5.495 8 13.366l2.532-7.876-5.062.005zm-1.371-.999-.78-2.422-1.818 2.425 2.598-.003zM1.499 5.5l5.113 6.817-2.192-6.82L1.5 5.5zm7.889 6.817 5.123-6.83-2.928.002-2.195 6.828z" />
                        </svg>
                      </span>
                      <span class="text-green text-sm font-medium tracking-tight">+5</span>
                    </span>-->
                  </div>


                  <div class="mt-8 flex items-center justify-between">
                    <div class="text-accent font-display text-sm font-semibold" data-bs-toggle="modal" data-bs-target="#placeBidModal">
                      Enter</div>

                    <div class="flex items-center space-x-1">
                      <span class="js-likes relative cursor-pointer before:absolute before:h-4 before:w-4 before:bg-[url('../img/heart-fill.svg')] before:bg-cover before:bg-center before:bg-no-repeat before:opacity-0" data-tippy-content="Completed">
                        <svg xmlns="http://www.w3.org/2000/svg" x="0px" y="0px" width="20" height="20" viewBox="0 0 32 32" style=" fill:#000000;">
                          <path d="M 16 3 C 8.832031 3 3 8.832031 3 16 C 3 23.167969 8.832031 29 16 29 C 23.167969 29 29 23.167969 29 16 C 29 8.832031 23.167969 3 16 3 Z M 16 5 C 22.085938 5 27 9.914063 27 16 C 27 22.085938 22.085938 27 16 27 C 9.914063 27 5 22.085938 5 16 C 5 9.914063 9.914063 5 16 5 Z M 22.28125 11.28125 L 15 18.5625 L 10.71875 14.28125 L 9.28125 15.71875 L 14.28125 20.71875 L 15 21.40625 L 15.71875 20.71875 L 23.71875 12.71875 Z">
                          </path>
                        </svg>
                      </span>
                      <span class="dark:text-jacarta-200 text-sm"><?php echo $conn->query("SELECT COUNT(*) FROM `completedoffers` WHERE `Wall` = 'Personaly'")->fetch_row()[0] ?></span>
                    </div>
                  </div>
                </a>
              </article>
            </div>
            <div class="swiper-slide">
              <article>
                <a href='offer-kw.html' class="dark:bg-jacarta-700 dark:border-jacarta-700 border-jacarta-100 block rounded-[1.25rem] border bg-white p-[1.1875rem] transition-shadow hover:shadow-lg">
                  <figure>
                    <img src="./img/kiwiwall.png" alt="item 1" style="height:271px;width:271px;" class="w-full rounded-[0.625rem]" loading="lazy" />
                  </figure>
                  <div class="mt-4 flex items-center justify-between">
                    <span class="font-display text-jacarta-700 hover:text-accent text-base dark:text-white">Kiwi Wall</span>
                    <!--<span class="dark:border-jacarta-600 border-jacarta-100 flex items-center whitespace-nowrap rounded-md border py-1 px-2">
                      <span data-tippy-content="Gems">
                        <svg xmlns="http://www.w3.org/2000/svg" width="22" height="16" fill="currentColor" class="bi bi-gem" viewBox="0 0 22 16">
                          <path d="M3.1.7a.5.5 0 0 1 .4-.2h9a.5.5 0 0 1 .4.2l2.976 3.974c.149.185.156.45.01.644L8.4 15.3a.5.5 0 0 1-.8 0L.1 5.3a.5.5 0 0 1 0-.6l3-4zm11.386 3.785-1.806-2.41-.776 2.413 2.582-.003zm-3.633.004.961-2.989H4.186l.963 2.995 5.704-.006zM5.47 5.495 8 13.366l2.532-7.876-5.062.005zm-1.371-.999-.78-2.422-1.818 2.425 2.598-.003zM1.499 5.5l5.113 6.817-2.192-6.82L1.5 5.5zm7.889 6.817 5.123-6.83-2.928.002-2.195 6.828z" />
                        </svg>
                      </span>
                      <span class="text-green text-sm font-medium tracking-tight">+5</span>
                    </span>-->
                  </div>


                  <div class="mt-8 flex items-center justify-between">
                    <div class="text-accent font-display text-sm font-semibold" data-bs-toggle="modal" data-bs-target="#placeBidModal">
                      Enter</div>

                    <div class="flex items-center space-x-1">
                      <span class="js-likes relative cursor-pointer before:absolute before:h-4 before:w-4 before:bg-[url('../img/heart-fill.svg')] before:bg-cover before:bg-center before:bg-no-repeat before:opacity-0" data-tippy-content="Completed">
                        <svg xmlns="http://www.w3.org/2000/svg" x="0px" y="0px" width="20" height="20" viewBox="0 0 32 32" style=" fill:#000000;">
                          <path d="M 16 3 C 8.832031 3 3 8.832031 3 16 C 3 23.167969 8.832031 29 16 29 C 23.167969 29 29 23.167969 29 16 C 29 8.832031 23.167969 3 16 3 Z M 16 5 C 22.085938 5 27 9.914063 27 16 C 27 22.085938 22.085938 27 16 27 C 9.914063 27 5 22.085938 5 16 C 5 9.914063 9.914063 5 16 5 Z M 22.28125 11.28125 L 15 18.5625 L 10.71875 14.28125 L 9.28125 15.71875 L 14.28125 20.71875 L 15 21.40625 L 15.71875 20.71875 L 23.71875 12.71875 Z">
                          </path>
                        </svg>
                      </span>
                      <span class="dark:text-jacarta-200 text-sm"><?php echo $conn->query("SELECT COUNT(*) FROM `completedoffers` WHERE `Wall` = 'Kiwi Wall'")->fetch_row()[0] ?></span>
                    </div>
                  </div>
                </a>
              </article>
            </div>
            <div class="swiper-slide">
              <article>
                <a href='offer-am.html' class="dark:bg-jacarta-700 dark:border-jacarta-700 border-jacarta-100 block rounded-[1.25rem] border bg-white p-[1.1875rem] transition-shadow hover:shadow-lg">
                  <figure>
                    <img src="./img/adscend.svg" alt="item 1" style="height:271px;width:271px;" class="w-full rounded-[0.625rem]" loading="lazy" />
                  </figure>
                  <div class="mt-4 flex items-center justify-between">
                    <span class="font-display text-jacarta-700 hover:text-accent text-base dark:text-white">Adscend Media</span>
                    <!--<span class="dark:border-jacarta-600 border-jacarta-100 flex items-center whitespace-nowrap rounded-md border py-1 px-2">
                      <span data-tippy-content="Gems">
                        <svg xmlns="http://www.w3.org/2000/svg" width="22" height="16" fill="currentColor" class="bi bi-gem" viewBox="0 0 22 16">
                          <path d="M3.1.7a.5.5 0 0 1 .4-.2h9a.5.5 0 0 1 .4.2l2.976 3.974c.149.185.156.45.01.644L8.4 15.3a.5.5 0 0 1-.8 0L.1 5.3a.5.5 0 0 1 0-.6l3-4zm11.386 3.785-1.806-2.41-.776 2.413 2.582-.003zm-3.633.004.961-2.989H4.186l.963 2.995 5.704-.006zM5.47 5.495 8 13.366l2.532-7.876-5.062.005zm-1.371-.999-.78-2.422-1.818 2.425 2.598-.003zM1.499 5.5l5.113 6.817-2.192-6.82L1.5 5.5zm7.889 6.817 5.123-6.83-2.928.002-2.195 6.828z" />
                        </svg>
                      </span>
                      <span class="text-green text-sm font-medium tracking-tight">+5</span>
                    </span>-->
                  </div>


                  <div class="mt-8 flex items-center justify-between">
                    <div class="text-accent font-display text-sm font-semibold" data-bs-toggle="modal" data-bs-target="#placeBidModal">
                      Enter</div>

                    <div class="flex items-center space-x-1">
                      <span class="js-likes relative cursor-pointer before:absolute before:h-4 before:w-4 before:bg-[url('../img/heart-fill.svg')] before:bg-cover before:bg-center before:bg-no-repeat before:opacity-0" data-tippy-content="Completed">
                        <svg xmlns="http://www.w3.org/2000/svg" x="0px" y="0px" width="20" height="20" viewBox="0 0 32 32" style=" fill:#000000;">
                          <path d="M 16 3 C 8.832031 3 3 8.832031 3 16 C 3 23.167969 8.832031 29 16 29 C 23.167969 29 29 23.167969 29 16 C 29 8.832031 23.167969 3 16 3 Z M 16 5 C 22.085938 5 27 9.914063 27 16 C 27 22.085938 22.085938 27 16 27 C 9.914063 27 5 22.085938 5 16 C 5 9.914063 9.914063 5 16 5 Z M 22.28125 11.28125 L 15 18.5625 L 10.71875 14.28125 L 9.28125 15.71875 L 14.28125 20.71875 L 15 21.40625 L 15.71875 20.71875 L 23.71875 12.71875 Z">
                          </path>
                        </svg>
                      </span>
                      <span class="dark:text-jacarta-200 text-sm"><?php echo $conn->query("SELECT COUNT(*) FROM `completedoffers` WHERE `Wall` = 'AdscendMedia Wall'")->fetch_row()[0] ?></span>
                    </div>
                  </div>
                </a>
              </article>
            </div>
            <div class="swiper-slide">
              <article>
                <a href='offer-cr.html' class="dark:bg-jacarta-700 dark:border-jacarta-700 border-jacarta-100 block rounded-[1.25rem] border bg-white p-[1.1875rem] transition-shadow hover:shadow-lg">
                  <figure>
                    <img src="./img/cpx.png" alt="item 1" style="height:271px;width:271px;object-fit:contain;" class="w-full rounded-[0.625rem]" loading="lazy" />
                  </figure>
                  <div class="mt-4 flex items-center justify-between">
                    <span class="font-display text-jacarta-700 hover:text-accent text-base dark:text-white">CPX Research</span>
                    <!--<span class="dark:border-jacarta-600 border-jacarta-100 flex items-center whitespace-nowrap rounded-md border py-1 px-2">
                      <span data-tippy-content="Gems">
                        <svg xmlns="http://www.w3.org/2000/svg" width="22" height="16" fill="currentColor" class="bi bi-gem" viewBox="0 0 22 16">
                          <path d="M3.1.7a.5.5 0 0 1 .4-.2h9a.5.5 0 0 1 .4.2l2.976 3.974c.149.185.156.45.01.644L8.4 15.3a.5.5 0 0 1-.8 0L.1 5.3a.5.5 0 0 1 0-.6l3-4zm11.386 3.785-1.806-2.41-.776 2.413 2.582-.003zm-3.633.004.961-2.989H4.186l.963 2.995 5.704-.006zM5.47 5.495 8 13.366l2.532-7.876-5.062.005zm-1.371-.999-.78-2.422-1.818 2.425 2.598-.003zM1.499 5.5l5.113 6.817-2.192-6.82L1.5 5.5zm7.889 6.817 5.123-6.83-2.928.002-2.195 6.828z" />
                        </svg>
                      </span>
                      <span class="text-green text-sm font-medium tracking-tight">+5</span>
                    </span>-->
                  </div>


                  <div class="mt-8 flex items-center justify-between">
                    <div class="text-accent font-display text-sm font-semibold" data-bs-toggle="modal" data-bs-target="#placeBidModal">
                      Enter</div>

                    <div class="flex items-center space-x-1">
                      <span class="js-likes relative cursor-pointer before:absolute before:h-4 before:w-4 before:bg-[url('../img/heart-fill.svg')] before:bg-cover before:bg-center before:bg-no-repeat before:opacity-0" data-tippy-content="Completed">
                        <svg xmlns="http://www.w3.org/2000/svg" x="0px" y="0px" width="20" height="20" viewBox="0 0 32 32" style=" fill:#000000;">
                          <path d="M 16 3 C 8.832031 3 3 8.832031 3 16 C 3 23.167969 8.832031 29 16 29 C 23.167969 29 29 23.167969 29 16 C 29 8.832031 23.167969 3 16 3 Z M 16 5 C 22.085938 5 27 9.914063 27 16 C 27 22.085938 22.085938 27 16 27 C 9.914063 27 5 22.085938 5 16 C 5 9.914063 9.914063 5 16 5 Z M 22.28125 11.28125 L 15 18.5625 L 10.71875 14.28125 L 9.28125 15.71875 L 14.28125 20.71875 L 15 21.40625 L 15.71875 20.71875 L 23.71875 12.71875 Z">
                          </path>
                        </svg>
                      </span>
                      <span class="dark:text-jacarta-200 text-sm"><?php echo $conn->query("SELECT COUNT(*) FROM `completedoffers` WHERE `Wall` = 'CPX Research'")->fetch_row()[0] ?></span>
                    </div>
                  </div>
                </a>
              </article>
            </div>
          </div>
        </div>

        <!-- Slider Navigation -->
        <div class="group swiper-button-prev shadow-white-volume absolute top-1/2 -left-4 z-10 -mt-6 flex h-12 w-12 cursor-pointer items-center justify-center rounded-full bg-white p-3 text-base sm:-left-6">
          <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24" class="fill-jacarta-700 group-hover:fill-accent">
            <path fill="none" d="M0 0h24v24H0z" />
            <path d="M10.828 12l4.95 4.95-1.414 1.414L8 12l6.364-6.364 1.414 1.414z" />
          </svg>
        </div>
        <div class="group swiper-button-next shadow-white-volume absolute top-1/2 -right-4 z-10 -mt-6 flex h-12 w-12 cursor-pointer items-center justify-center rounded-full bg-white p-3 text-base sm:-right-6">
          <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24" class="fill-jacarta-700 group-hover:fill-accent">
            <path fill="none" d="M0 0h24v24H0z" />
            <path d="M13.172 12l-4.95-4.95 1.414-1.414L16 12l-6.364 6.364-1.414-1.414z" />
          </svg>
        </div>
      </div>
    </div>
  </section>




  <section class="relative py-24">
    <div class="container">
      <iframe src="https://wall.adgaterewards.com/oKqTrg/<?php echo $_SESSION["userid"] ?>" height="500" width="100%"></iframe>
    </div>
  </section>
  <?php
  require_once("footer.php");
  ?>