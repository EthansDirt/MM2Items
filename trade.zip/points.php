<?php
session_start();
include "commands.php";
if (!isset($_SESSION["userid"])) {
    jsonError("You are Not Logged In!");
}
if (getCurrentUserData()["Rank"] <= 0) {
    jsonError("You do not have permission to delete this!");
}
if (isset($_GET["id"]) and isset($_GET["points"])) {
    $id = intval($_GET["id"]);
    $points = intval($_GET["points"]);
    if (!$conn->query("UPDATE `users` SET `Gems`='$points' WHERE `UserId`='$id'")) {
        jsonError($mysqli -> error);
    }
    jsonError(false);
} else {
    jsonError("Feature Under Maintenance!");
}
?>