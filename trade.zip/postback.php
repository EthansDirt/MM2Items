<?php
header("Content-Type: text/plain");
/**
 * For a plain PHP page to receive the postback data from AdGate Media you may simply
 * retrieve the array from the global $_GET variable. To ensure that the data is coming
 * from AdGate Media check that the server sending the data is from AdGate Media by the ip
 * address as listed on your affiliate panel at http://adgatemedia.com under
 * the Postbacks Section and the Postback Information heading.
 */
define('AdGate_IP', '52.42.57.125');
define("OfferToro_IP",'54.175.173.245');
define("Personaly_IPa",'52.200.142.249');
define("Personaly_IPb",'159.203.84.146');
define("Kiwi_IP",'34.193.235.172');
$AdscendIps = ['54.204.57.82',
'52.117.122.183',
'52.117.127.192',
'52.117.121.196',
'188.40.3.73',
'157.90.97.92',
'2a01:4f8:d0a:30ff::2',
'39.40.224.192'
];
$ip = $_SERVER['REMOTE_ADDR'];
$data = null;

/**
 * Check the Remote Address is AdGate Media
 * if it is not throw an Exception
 */
if($ip === AdGate_IP or $ip === OfferToro_IP or $ip === Personaly_IPa or $ip === Personaly_IPb or $ip === Kiwi_IP or in_array($ip,$AdscendIps))
{
    $data = $_GET;
} else {
    exit();
}

include "commands.php";
$user = $data["user"];
$cid = $data["offer_id"];
$reward = intval($data["reward"]);
$wall = $data["wall"];
$offername = $data["offer"];
$payout = $data["payout"];

if($data['status'] != 1)
{
    offerChargeback($user,$cid,$reward,$offername,$payout,$wall);
    echo 1;
    die();
} else {
    newOfferCompleted($user,$cid,$reward,$offername,$payout,$wall);
    echo 1;
    die();
}