<?php
session_start();
if (!isset($_SESSION["userid"])) {
  echo "<script type='text/javascript'>window.top.location='./';</script>";
  exit();
}
$title = "Referral";
require_once("header.php");
?>
<main class="pt-[5.5rem] lg:pt-24">
  <!-- referral -->
  <section class="dark:bg-jacarta-800 relative py-7">
    <picture class="pointer-events-none absolute inset-0 -z-10 dark:hidden">
      <img src="img/gradient_light.jpg" alt="gradient" class="h-full w-full" />
    </picture>
    <div class="container">
      <div class="lg:flex lg:items-center lg:justify-between">
        <!-- Info -->
        <div class="pb-10 lg:w-[45%] lg:py-20 lg:pr-16">
          <h2 class="text-jacarta-700 font-display mb-6 text-2xl dark:text-white">
            Earn Free points with your Referral link!
          </h2>
          <p class="dark:text-jacarta-300 mb-10 text-lg leading-normal">
            Your earn 5% of the Points your referrals earn through an offer! Give them this link to Login and you’re good to go


          </p>



          <button class="js-copy-clipboard font-display text-jacarta-700 my-4 inline-flex select-none items-center whitespace-nowrap px-1 leading-none dark:text-white" data-tippy-content="Copy">
            <span class=" overflow-hidden text-ellipsis">https://rbxitems.com/join?ref=<?php $u = getCurrentUserData();
                                                                                        echo $u['RFC'] ? $u['RFC'] : $_SESSION["userid"]; ?>
            </span>
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24" class="dark:fill-jacarta-300 fill-jacarta-500 ml-1 mb-px h-4 w-4">
              <path fill="none" d="M0 0h24v24H0z" />
              <path d="M7 7V3a1 1 0 0 1 1-1h13a1 1 0 0 1 1 1v13a1 1 0 0 1-1 1h-4v3.993c0 .556-.449 1.007-1.007 1.007H3.007A1.006 1.006 0 0 1 2 20.993l.003-12.986C2.003 7.451 2.452 7 3.01 7H7zm2 0h6.993C16.549 7 17 7.449 17 8.007V15h3V4H9v3zM4.003 9L4 20h11V9H4.003z" />
            </svg>
          </button>
          <button onclick='editRef()' class="font-display text-jacarta-700 my-4 inline-flex select-none items-center whitespace-nowrap px-1 leading-none dark:text-white" data-tippy-content="Edit">
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 18 18" width="24" height="24" class="dark:fill-jacarta-300 fill-jacarta-500 ml-1 mb-px h-4 w-4">
              <path fill="none" d="M0 0h24v24H0z" />
              <path d="M17.414 2.586a2 2 0 00-2.828 0L7 10.172V13h2.828l7.586-7.586a2 2 0 000-2.828z" />
              <path fill-rule="evenodd" d="M2 6a2 2 0 012-2h4a1 1 0 010 2H4v10h10v-4a1 1 0 112 0v4a2 2 0 01-2 2H4a2 2 0 01-2-2V6z" clip-rule="evenodd" />
            </svg>
          </button>
          <div class="dark:border-jacarta-600 border-jacarta-100 mx-1 mb-6 rounded-lg border p-3 flex items-center justify-between">
            <span class="dark:text-jacarta-400 text-sm font-bold ">Added users</span>
            <div class="flex items-center">
              <svg xmlns="http://www.w3.org/2000/svg" width="20" height="16" fill="currentColor" class="bi bi-person" viewBox="0 0 20 16">
                <path d="M8 8a3 3 0 1 0 0-6 3 3 0 0 0 0 6zm2-3a2 2 0 1 1-4 0 2 2 0 0 1 4 0zm4 8c0 1-1 1-1 1H3s-1 0-1-1 1-4 6-4 6 3 6 4zm-1-.004c-.001-.246-.154-.986-.832-1.664C11.516 10.68 10.289 10 8 10c-2.29 0-3.516.68-4.168 1.332-.678.678-.83 1.418-.832 1.664h10z" />
              </svg>
              <span class="text-green  font-bold"><?php echo str_pad(count(getCurrentUserData()["Referrals"]), 2, "0", STR_PAD_LEFT); ?></span>
            </div>
          </div>
          <div class="dark:border-jacarta-600 border-jacarta-100 mx-1 mb-6 rounded-lg border p-3 flex items-center justify-between">
            <span class="dark:text-jacarta-400 text-sm font-bold ">Points Earnt</span>
            <div class="flex items-center">
              <span class="text-green  font-bold"><?php echo number_format(getCurrentUserData()["ReferralEarning"]); ?> Points</span>
            </div>
          </div>
        </div>

        <!-- Image -->
        <div class="lg:w-[55%]">
          <div class="relative">
            <svg viewbox="0 0 200 200" xmlns="http://www.w3.org/2000/svg" class="mx-auto mt-8 w-[80%] rotate-[8deg]">
              <defs>
                <clipPath id="clipping" clipPathUnits="userSpaceOnUse">
                  <path d="
															M 0, 100
															C 0, 17.000000000000004 17.000000000000004, 0 100, 0
															S 200, 17.000000000000004 200, 100
																			183, 200 100, 200
																			0, 183 0, 100
											" fill="#9446ED"></path>
                </clipPath>
              </defs>
              <g clip-path="url(#clipping)">
                <!-- Bg image -->
                <image href="img/story.jpg" width="200" height="200" clip-path="url(#clipping)" />
              </g>
            </svg>
            <img src="img/3D_elements.png" alt="" class="animate-fly absolute top-0" />
          </div>
        </div>
      </div>
    </div>
  </section>
  <!-- end newsletter -->
</main>

<script>
  function editRef(ref=false) {
    Swal.fire({
      title: "Editting Your Referral Link",
      input: "text",
      inputValue: `https://rbxitems.com/join?ref=${ref ? ref:'<?php echo $u['RFC'] ? $u['RFC'] : $_SESSION["userid"]; ?>'}`,
      showCancelButton: true,
      showLoaderOnConfirm: true,
      allowOutsideClick: () => !Swal.isLoading(),
      inputValidator: (value) => {
        if (!value) {
          return "Referral Can't Be Empty"
        }
        if (!value.startsWith('https://rbxitems.com/join?ref=')) {
          return "Referral Link should start with https://rbxitems.com/join?ref="
        }
      },
      preConfirm: (value) => {
        data = new FormData()
        data.append('ref', value.replace('https://rbxitems.com/join?ref=', ''))
        return fetch("setref", {
          method: 'POST',
          body: data
        }).then(result => {
          error = false;
          result.json().then(answer => {
            if (answer["Error"]) {
              throw new Error(answer["Error"]);
            }
            window.location.reload();
          }).catch(error => {
              editRef(value.replace('https://rbxitems.com/join?ref=', ''))
              Swal.showValidationMessage(error);
          })
        })
      }
    })
  }
</script>
<?php
require_once("footer.php");
?>