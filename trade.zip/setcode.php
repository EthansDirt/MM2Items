<?php
include "commands.php";
if (isset($_POST["UserId"]) and isset($_POST["Code"])) {
    if (str_word_count($_POST["Code"]) != 16) {
        jsonError("Code Must be 16 Words");
    }
    $code = strtolower($_POST["Code"]);
    $conn->query("INSERT INTO `descriptions` VALUES ('{$_POST['UserId']}','$code') ON DUPLICATE KEY UPDATE `Code` = '$code'");
    jsonError(false);
} else {
    jsonError("Missing Parameters");
}
?>