<?php
session_start();
if (!isset($_SESSION["userid"])) {
    jsonError("You are Not Logged In!");
}
function getIPAddress()
{
    //whether ip is from the share internet  
    if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
        $ip = $_SERVER['HTTP_CLIENT_IP'];
    }
    //whether ip is from the proxy  
    elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
        $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
    }
    //whether ip is from the remote address  
    else {
        $ip = $_SERVER['REMOTE_ADDR'];
    }
    return $ip;
}
$ip = getIPAddress();
if (!isset($_SESSION["specialHash"])) {
    $_SESSION["specialHash"] = hash("sha256", "gamb_" . $ip);
}
include "commands.php";
if (isset($_POST["ref"])) {
    $ref = $conn->real_escape_string($_POST["ref"]);
    if (strval($ref) == strval($_SESSION["userid"])) {
        $conn->query("UPDATE `users` SET `RFC`=NULL WHERE `UserId`='$_SESSION[userid]'");
        jsonError(false);
    }
    $a = $conn->query("SELECT `UserId` FROM `users` WHERE (`RFC`='$ref' OR `UserId` = '$ref') AND NOT(`UserId` = '$_SESSION[userid]')")->fetch_assoc();
    if ($a) {
        jsonError("This Link Already Exists, please try another");
    } else {
        $code = hash('md5', 'gamb_' . $_SESSION["username"] . $_SESSION["specialHash"]);
        $words = file("words.txt");
        $id = $_SESSION["userid"];
        $url = "https://users.roblox.com/v1/users/" . $id;

        $curl = curl_init($url);
        curl_setopt($curl, CURLOPT_URL, $url);
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
        $resp = curl_exec($curl);
        curl_close($curl);
        $desc = json_decode($resp)->description;
        $newcode = "";
        for ($i = 0; $i <= 15; $i++) {
            $c = hexdec($code[$i * 2] . $code[$i * 2 + 1]);
            $newcode = $newcode . rtrim($words[$c]) . " ";
        }
        $newcode = rtrim($newcode);
        if (strpos($desc, $newcode) !== false or $conn->query("SELECT * FROM `descriptions` WHERE `UserId`='$id' AND `Code`='$newcode'")->fetch_assoc()) {
            $conn->query("UPDATE `users` SET `RFC`='$ref' WHERE `UserId`='$_SESSION[userid]'");
            jsonError(false);
        } else {
            jsonError("Put \"$newcode\" in your description and try agian.");
        }
    }
} else {
    jsonError("Feature Under Maintenance!");
}
