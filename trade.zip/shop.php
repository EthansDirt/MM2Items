<?php
session_start();
if (!isset($_SESSION["userid"])) {
  echo "<script type='text/javascript'>window.top.location='./';</script>";
  exit();
}
include "commands.php";
if (getUserData($_SESSION["userid"])["Rank"] < 1) {
  echo "<script type='text/javascript'>window.top.location='./';</script>";
  exit();
}
$title = "Shop";
require_once("header.php");
?>
<main>
  <!-- Rankings -->
  <section class="relative py-24">
    <picture class="pointer-events-none absolute inset-0 -z-10 dark:hidden">
      <img src="img/gradient_light.jpg" alt="gradient" class="h-full w-full" />
    </picture>
    <div class="container">
      <h1 class="font-display text-jacarta-700 py-16 text-center text-4xl font-medium dark:text-white"> Item list</h1>

      <!-- Filters -->
      <div class="mb-8 flex flex-wrap items-center justify-between">
        <div class="flex flex-wrap items-center">
          <!-- Categories -->
          <div class="my-1 mr-2.5">
            <button class="group dropdown-toggle dark:border-jacarta-600 dark:bg-jacarta-700 group dark:hover:bg-accent hover:bg-accent border-jacarta-100 font-display text-jacarta-700 flex h-9 items-center rounded-lg border bg-white px-4 text-sm font-semibold transition-colors hover:border-transparent hover:text-white dark:text-white" id="categoriesFilter" data-bs-toggle="dropdown" aria-expanded="false">
              <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24" class="fill-jacarta-700 dark:fill-jacarta-100 mr-1 h-4 w-4 transition-colors group-hover:fill-white">
                <path fill="none" d="M0 0h24v24H0z" />
                <path d="M14 10v4h-4v-4h4zm2 0h5v4h-5v-4zm-2 11h-4v-5h4v5zm2 0v-5h5v4a1 1 0 0 1-1 1h-4zM14 3v5h-4V3h4zm2 0h4a1 1 0 0 1 1 1v4h-5V3zm-8 7v4H3v-4h5zm0 11H4a1 1 0 0 1-1-1v-4h5v5zM8 3v5H3V4a1 1 0 0 1 1-1h4z" />
              </svg>
              <span>Add Item</span>
            </button>
            <div class="dropdown-menu dark:bg-jacarta-800 z-10 hidden min-w-[220px] whitespace-nowrap rounded-xl bg-white py-4 px-2 text-left shadow-xl" aria-labelledby="categoriesFilter">
              <ul class="flex flex-col flex-wrap">
                <li>
                  <a href="#" onclick="AddItem('Murder Mystery 2')" class="dropdown-item font-display dark:hover:bg-jacarta-600 hover:bg-jacarta-50 flex w-full items-center justify-between rounded-xl px-5 py-2 text-left text-sm transition-colors dark:text-white">
                    <span class="text-jacarta-700 dark:text-white">Murder Mystery 2</span>
                  </a>
                </li>
                <li>
                  <a href="#" onclick="AddItem('Adopt Me')" class="dropdown-item font-display dark:hover:bg-jacarta-600 hover:bg-jacarta-50 flex w-full items-center rounded-xl px-5 py-2 text-left text-sm transition-colors dark:text-white">
                    Adopt me</a>
                </li>
                <li>
                  <a href="#" onclick="AddItem('Clicker Simulator')" class="dropdown-item font-display dark:hover:bg-jacarta-600 hover:bg-jacarta-50 flex w-full items-center rounded-xl px-5 py-2 text-left text-sm transition-colors dark:text-white">
                    Clicker Simulator</a>
                </li>
                <li>
                  <a href="#" onclick="AddItem('Pet Simulator X')" class="dropdown-item font-display dark:hover:bg-jacarta-600 hover:bg-jacarta-50 flex w-full items-center rounded-xl px-5 py-2 text-left text-sm transition-colors dark:text-white">
                    Pet Simulator X</a>
                </li>

              </ul>
            </div>
          </div>

          <!-- Chains -->
          <div class="my-1 mr-2.5">
            <button class="group dropdown-toggle dark:border-jacarta-600 dark:bg-jacarta-700 group dark:hover:bg-accent hover:bg-accent border-jacarta-100 font-display text-jacarta-700 flex h-9 items-center rounded-lg border bg-white px-4 text-sm font-semibold transition-colors hover:border-transparent hover:text-white dark:text-white" id="blockchainFilter" data-bs-toggle="dropdown" aria-expanded="false">
              <svg xmlns="http://www.w3.org/2000/svg" width="20" height="16" fill="currentColor" class="bi bi-list" viewBox="0 0 20 16">
                <path fill-rule="evenodd" d="M2.5 12a.5.5 0 0 1 .5-.5h10a.5.5 0 0 1 0 1H3a.5.5 0 0 1-.5-.5zm0-4a.5.5 0 0 1 .5-.5h10a.5.5 0 0 1 0 1H3a.5.5 0 0 1-.5-.5zm0-4a.5.5 0 0 1 .5-.5h10a.5.5 0 0 1 0 1H3a.5.5 0 0 1-.5-.5z" />
              </svg>




              <span id='filter'>All games</span>
            </button>
            <div class="dropdown-menu dark:bg-jacarta-800 z-10 hidden min-w-[220px] whitespace-nowrap rounded-xl bg-white py-4 px-2 text-left shadow-xl" aria-labelledby="blockchainFilter">
              <ul class="flex flex-col flex-wrap">
                <li>
                  <a href="javascript:void(0)" onclick="filter('all')" class="dropdown-item font-display dark:hover:bg-jacarta-600 hover:bg-jacarta-50 flex w-full items-center justify-between rounded-xl px-5 py-2 text-left text-sm transition-colors dark:text-white">
                    <span class="text-jacarta-700 dark:text-white">All games</span>
                    <svg id='allfilter' xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24" class="fill-accent mb-[3px] h-4 w-4">
                      <path fill="none" d="M0 0h24v24H0z"></path>
                      <path d="M10 15.172l9.192-9.193 1.415 1.414L10 18l-6.364-6.364 1.414-1.414z"></path>
                    </svg>
                  </a>
                </li>
                <li>
                  <a href="javascript:void(0)" onclick="filter('mm2')" class="dropdown-item font-display dark:hover:bg-jacarta-600 hover:bg-jacarta-50 flex w-full items-center justify-between rounded-xl px-5 py-2 text-left text-sm transition-colors dark:text-white">
                    <span class="text-jacarta-700 dark:text-white">Murder Mystery 2</span>
                    <svg id='mm2filter' xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24" class="hidden fill-accent mb-[3px] h-4 w-4">
                      <path fill="none" d="M0 0h24v24H0z"></path>
                      <path d="M10 15.172l9.192-9.193 1.415 1.414L10 18l-6.364-6.364 1.414-1.414z"></path>
                    </svg>

                  </a>
                </li>
                <li>
                  <a href="javascript:void(0)" onclick="filter('am')" class="dropdown-item font-display dark:hover:bg-jacarta-600 hover:bg-jacarta-50 flex w-full items-center justify-between rounded-xl px-5 py-2 text-left text-sm transition-colors dark:text-white">
                    <span class="text-jacarta-700 dark:text-white">Adopt Me</span>
                    <svg id='amfilter' xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24" class="hidden fill-accent mb-[3px] h-4 w-4">
                      <path fill="none" d="M0 0h24v24H0z"></path>
                      <path d="M10 15.172l9.192-9.193 1.415 1.414L10 18l-6.364-6.364 1.414-1.414z"></path>
                    </svg>
                  </a>
                </li>
                <li>
                  <a href="javascript:void(0)" onclick="filter('ckx')" class="dropdown-item font-display dark:hover:bg-jacarta-600 hover:bg-jacarta-50 flex w-full items-center justify-between rounded-xl px-5 py-2 text-left text-sm transition-colors dark:text-white">
                    <span class="text-jacarta-700 dark:text-white">Clicker Simulator</span>
                    <svg id='ckxfilter' xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24" class="hidden fill-accent mb-[3px] h-4 w-4">
                      <path fill="none" d="M0 0h24v24H0z"></path>
                      <path d="M10 15.172l9.192-9.193 1.415 1.414L10 18l-6.364-6.364 1.414-1.414z"></path>
                    </svg>
                  </a>
                </li>
                <li>
                  <a href="javascript:void(0)" onclick="filter('psx')" class="dropdown-item font-display dark:hover:bg-jacarta-600 hover:bg-jacarta-50 flex w-full items-center justify-between rounded-xl px-5 py-2 text-left text-sm transition-colors dark:text-white">
                    <span class="text-jacarta-700 dark:text-white">Pet Simulator X</span>
                    <svg id='psxfilter' xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24" class="hidden fill-accent mb-[3px] h-4 w-4">
                      <path fill="none" d="M0 0h24v24H0z"></path>
                      <path d="M10 15.172l9.192-9.193 1.415 1.414L10 18l-6.364-6.364 1.414-1.414z"></path>
                    </svg>
                  </a>
                </li>
              </ul>
            </div>
          </div>
        </div>


        <div class="dropdown relative my-1 cursor-pointer">
          <div class="dark:bg-jacarta-700 dropdown-toggle border-jacarta-100 dark:border-jacarta-600 inline-flex w-48 items-center justify-between rounded-lg border bg-white py-2 px-3 text-sm dark:text-white" role="button" id="sortOrdering" data-bs-toggle="dropdown" aria-expanded="false">
            <span class="font-display">Sort</span>
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24" class="fill-jacarta-500 h-4 w-4 dark:fill-white">
              <path fill="none" d="M0 0h24v24H0z" />
              <path d="M12 13.172l4.95-4.95 1.414 1.414L12 16 5.636 9.636 7.05 8.222z" />
            </svg>
          </div>

          <div class="dropdown-menu dark:bg-jacarta-800 z-10 hidden w-full whitespace-nowrap rounded-xl bg-white py-4 px-2 text-left shadow-xl" aria-labelledby="sortOrdering">
            <button onclick="window.location = '?sort=idasc'" class="dropdown-item font-display text-jacarta-700 dark:hover:bg-jacarta-600 hover:bg-jacarta-50 flex w-full items-center justify-between rounded-xl px-5 py-2 text-left text-sm transition-colors dark:text-white">
              By ID Ascending
              <?php
              if (!isset($_GET["sort"]) or $_GET["sort"] == "idasc") {
                echo '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24" class="fill-accent mb-[3px] h-4 w-4">
                  <path fill="none" d="M0 0h24v24H0z" />
                  <path d="M10 15.172l9.192-9.193 1.415 1.414L10 18l-6.364-6.364 1.414-1.414z" />
                </svg>';
              }
              ?>
            </button>
            <button onclick="window.location = '?sort=iddesc'" class="dropdown-item font-display text-jacarta-700 dark:hover:bg-jacarta-600 hover:bg-jacarta-50 flex w-full items-center justify-between rounded-xl px-5 py-2 text-left text-sm transition-colors dark:text-white">
              By ID Descending
              <?php
              if (isset($_GET["sort"]) and $_GET["sort"] == "iddesc") {
                echo '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24" class="fill-accent mb-[3px] h-4 w-4">
                  <path fill="none" d="M0 0h24v24H0z" />
                  <path d="M10 15.172l9.192-9.193 1.415 1.414L10 18l-6.364-6.364 1.414-1.414z" />
                </svg>';
              }
              ?>
            </button>
            <button onclick="window.location = '?sort=nameasc'" class="dropdown-item font-display text-jacarta-700 dark:hover:bg-jacarta-600 hover:bg-jacarta-50 flex w-full items-center justify-between rounded-xl px-5 py-2 text-left text-sm transition-colors dark:text-white">
              By Name Ascending
              <?php
              if (isset($_GET["sort"]) and $_GET["sort"] == "nameasc") {
                echo '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24" class="fill-accent mb-[3px] h-4 w-4">
                  <path fill="none" d="M0 0h24v24H0z" />
                  <path d="M10 15.172l9.192-9.193 1.415 1.414L10 18l-6.364-6.364 1.414-1.414z" />
                </svg>';
              }
              ?>
            </button>
            <button onclick="window.location = '?sort=namedesc'" class="dropdown-item font-display text-jacarta-700 dark:hover:bg-jacarta-600 hover:bg-jacarta-50 flex w-full items-center justify-between rounded-xl px-5 py-2 text-left text-sm transition-colors dark:text-white">
              By Name Descending
              <?php
              if (isset($_GET["sort"]) and $_GET["sort"] == "namedesc") {
                echo '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24" class="fill-accent mb-[3px] h-4 w-4">
                  <path fill="none" d="M0 0h24v24H0z" />
                  <path d="M10 15.172l9.192-9.193 1.415 1.414L10 18l-6.364-6.364 1.414-1.414z" />
                </svg>';
              }
              ?>
            </button>
            <button onclick="window.location = '?sort=priceasc'" class="dropdown-item font-display text-jacarta-700 dark:hover:bg-jacarta-600 hover:bg-jacarta-50 flex w-full items-center justify-between rounded-xl px-5 py-2 text-left text-sm transition-colors dark:text-white">
              By Price Ascending
              <?php
              if (isset($_GET["sort"]) and $_GET["sort"] == "priceasc") {
                echo '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24" class="fill-accent mb-[3px] h-4 w-4">
                  <path fill="none" d="M0 0h24v24H0z" />
                  <path d="M10 15.172l9.192-9.193 1.415 1.414L10 18l-6.364-6.364 1.414-1.414z" />
                </svg>';
              }
              ?>
            </button>
            <button onclick="window.location = '?sort=pricedesc'" class="dropdown-item font-display text-jacarta-700 dark:hover:bg-jacarta-600 hover:bg-jacarta-50 flex w-full items-center justify-between rounded-xl px-5 py-2 text-left text-sm transition-colors dark:text-white">
              By Price Descending
              <?php
              if (isset($_GET["sort"]) and $_GET["sort"] == "pricedesc") {
                echo '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24" class="fill-accent mb-[3px] h-4 w-4">
                  <path fill="none" d="M0 0h24v24H0z" />
                  <path d="M10 15.172l9.192-9.193 1.415 1.414L10 18l-6.364-6.364 1.414-1.414z" />
                </svg>';
              }
              ?>
            </button>

          </div>
        </div>
      </div>
      <!-- end filters -->

      <script>
        function filter(item) {
          if (item == "all") {
            $("#filter").text("All Items");
            $("#amfilter").addClass("hidden");
            $("#mm2filter").addClass("hidden");
            $("#ckxfilter").addClass("hidden");
            $("#psxfilter").addClass("hidden");
            $("#allfilter").removeClass("hidden");
            $(".am").removeClass("hidden");
            $(".mm2").removeClass("hidden");
            $(".ckx").removeClass("hidden");
            $(".psx").removeClass("hidden");
          }
          if (item == "mm2") {
            $("#filter").text("Murder Mystery 2");
            $("#amfilter").addClass("hidden");
            $("#mm2filter").removeClass("hidden");
            $("#allfilter").addClass("hidden");
            $("#ckxfilter").addClass("hidden");
            $("#psxfilter").addClass("hidden");
            $(".am").addClass("hidden");
            $(".mm2").removeClass("hidden");
            $(".ckx").addClass("hidden");
            $(".psx").addClass("hidden");
          }
          if (item == "am") {
            $("#filter").text("Adopt Me");
            $("#amfilter").removeClass("hidden");
            $("#mm2filter").addClass("hidden");
            $("#ckxfilter").addClass("hidden");
            $("#psxfilter").addClass("hidden");
            $("#allfilter").addClass("hidden");
            $(".am").removeClass("hidden");
            $(".mm2").addClass("hidden");
            $(".ckx").addClass("hidden");
            $(".psx").addClass("hidden");
          }
          if (item == "ckx") {
            $("#filter").text("Clicker Simulator");
            $("#amfilter").addClass("hidden");
            $("#mm2filter").addClass("hidden");
            $("#ckxfilter").removeClass("hidden");
            $("#psxfilter").addClass("hidden");
            $("#allfilter").addClass("hidden");
            $(".am").addClass("hidden");
            $(".mm2").addClass("hidden");
            $(".ckx").removeClass("hidden");
            $(".psx").addClass("hidden");
          }
          if (item == "psx") {
            $("#filter").text("Pet Simulator X");
            $("#amfilter").addClass("hidden");
            $("#mm2filter").addClass("hidden");
            $("#ckxfilter").addClass("hidden");
            $("#psxfilter").removeClass("hidden");
            $("#allfilter").addClass("hidden");
            $(".am").addClass("hidden");
            $(".mm2").addClass("hidden");
            $(".ckx").addClass("hidden");
            $(".psx").removeClass("hidden");
          }
        }
      </script>

      <!-- Table -->
      <div class="scrollbar-custom overflow-x-auto">
        <div role="table" class="dark:bg-jacarta-700 dark:border-jacarta-600 border-jacarta-100 lg:rounded-2lg w-full min-w-[736px] border bg-white text-sm dark:text-white">
          <div class="dark:bg-jacarta-600 bg-jacarta-50 rounded-t-2lg flex" role="row">
            <div class="w-[28%] py-3 px-4" role="columnheader">
              <span class="text-jacarta-700 dark:text-jacarta-100 w-full overflow-hidden text-ellipsis">Website name</span>
            </div>
            <div class="w-[12%] py-3 px-4" role="columnheader">
              <span class="text-jacarta-700 dark:text-jacarta-100 w-full overflow-hidden text-ellipsis">Price</span>
            </div>

            <div class="w-[12%] py-3 px-4" role="columnheader">
              <span class="text-jacarta-700 dark:text-jacarta-100 w-full overflow-hidden text-ellipsis">Game</span>
            </div>
            <div class="w-[12%] py-3 px-4" role="columnheader">
              <span class="text-jacarta-700 dark:text-jacarta-100 w-full overflow-hidden text-ellipsis">In Game name</span>
            </div>
          </div>
          <?php
          $ad = "";
          if (isset($_GET["sort"])) {
            if ($_GET["sort"] == 'pricedesc') {
              $ad = "ORDER BY `Price` DESC";
            }
            if ($_GET["sort"] == 'priceasc') {
              $ad = "ORDER BY `Price` ASC";
            }
            if ($_GET["sort"] == 'iddesc') {
              $ad = "ORDER BY `ItemId` DESC";
            }
            if ($_GET["sort"] == 'idasc') {
              $ad = "ORDER BY `ItemId` ASC";
            }
            if ($_GET["sort"] == 'namedesc') {
              $ad = "ORDER BY `DisplayName` DESC";
            }
            if ($_GET["sort"] == 'nameasc') {
              $ad = "ORDER BY `DisplayName` ASC";
            }
          }
          $c = $conn->query("SELECT * FROM `items` $ad");
          while ($item = $c->fetch_assoc()) {
            $price = number_format($item["Price"]);
            $img = urldecode($item["Image"]);
            $game = $item["Game"] == "Murder Mystery 2" ? "mm2" : ($item["Game"] == "Adopt Me" ? "am":($item["Game"] == "Clicker Simulator" ? "ckx":"psx"));
            echo "<a class='$game flex transition-shadow hover:shadow-lg' role='row'>
          <div class='dark:border-jacarta-600 border-jacarta-100 flex w-[28%] items-center border-t py-4 px-4' role='cell'>
            <span class='mr-2 lg:mr-4'>{$item['ItemId']}</span>
            <figure class='relative mr-2 w-8 shrink-0 self-start lg:mr-5 lg:w-12'>
              <img src='$img' alt='avatar 1' class='rounded-2lg' loading='lazy' />
            </figure>
            <span class='font-display text-jacarta-700 text-sm font-semibold dark:text-white'>
              {$item['DisplayName']}</span>
          </div>
          <div class='dark:border-jacarta-600 border-jacarta-100 flex w-[12%] items-center whitespace-nowrap border-t py-4 px-4' role='cell'>
            <span class='text-sm font-medium tracking-tight'><strong>$price</strong> points</span>
          </div>
          <div class='dark:border-jacarta-600 border-jacarta-100 flex w-[12%] items-center border-t py-4 px-4' role='cell'>
            <span class=''>{$item['Game']}</span>
          </div>
          <div class='dark:border-jacarta-600 border-jacarta-100 flex w-[12%] items-center border-t py-4 px-7' role='cell'>
            {$item['GameName']}
          </div>
          <div class='dark:border-jacarta-600 border-jacarta-100 flex w-[12%] items-center border-t py-4 px-6' role='cell'>
          </div>
          <div class='dark:border-jacarta-600 border-jacarta-100 flex w-[12%] items-center border-t py-4 px-4' role='cell'>
            <button onclick='modifyItem({$item['ItemId']},\"{$item['DisplayName']}\",{$item['Price']},\"$img\")' class='group dropdown-toggle dark:border-jacarta-600 dark:bg-jacarta-700 group dark:hover:bg-accent hover:bg-accent border-jacarta-100 font-display text-jacarta-700 flex h-9 items-center rounded-lg border bg-white px-4 text-sm font-semibold transition-colors hover:border-transparent hover:text-white dark:text-white' id='blockchainFilter' data-bs-toggle='dropdown' aria-expanded='false'>
              <svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' width='24' height='24' class='fill-jacarta-700 dark:fill-jacarta-100 mr-1 h-4 w-4 transition-colors group-hover:fill-white'>
                <path fill='none' d='M0 0h24v24H0z' />
                <path d='M20 16h2v6h-6v-2H8v2H2v-6h2V8H2V2h6v2h8V2h6v6h-2v8zm-2 0V8h-2V6H8v2H6v8h2v2h8v-2h2zM4 4v2h2V4H4zm0 14v2h2v-2H4zM18 4v2h2V4h-2zm0 14v2h2v-2h-2z' />
              </svg>
              <span>Modify</span>
            </button>
          </div>
          <div class='dark:border-jacarta-600 border-jacarta-100 flex w-[12%] items-center border-t py-4 px-4' role='cell'>
            <button onclick='deleteItem({$item['ItemId']})' class='group dropdown-toggle dark:border-jacarta-600 dark:bg-jacarta-700 group dark:hover:bg-accent hover:bg-accent border-jacarta-100 font-display text-jacarta-700 flex h-9 items-center rounded-lg border bg-white px-4 text-sm font-semibold transition-colors hover:border-transparent hover:text-white dark:text-white' id='blockchainFilter' data-bs-toggle='dropdown' aria-expanded='false'>
              <svg xmlns='http://www.w3.org/2000/svg' width='20' height='16' fill='currentColor' class='bi bi-trash-fill' viewBox='0 0 20 16'>
                <path d='M2.5 1a1 1 0 0 0-1 1v1a1 1 0 0 0 1 1H3v9a2 2 0 0 0 2 2h6a2 2 0 0 0 2-2V4h.5a1 1 0 0 0 1-1V2a1 1 0 0 0-1-1H10a1 1 0 0 0-1-1H7a1 1 0 0 0-1 1H2.5zm3 4a.5.5 0 0 1 .5.5v7a.5.5 0 0 1-1 0v-7a.5.5 0 0 1 .5-.5zM8 5a.5.5 0 0 1 .5.5v7a.5.5 0 0 1-1 0v-7A.5.5 0 0 1 8 5zm3 .5v7a.5.5 0 0 1-1 0v-7a.5.5 0 0 1 1 0z' />
              </svg>
              <span>Delete</span>
            </button>
          </div>
        </a>";
          }
          ?>
          <script>
            function deleteItem(id) {
              fetch("deleteitem/?id=" + id).then(result => {
                result.json().then(data => {
                  if (data["Error"]) {
                    Swal.fire({
                      title: "An Error Occured While Deleting",
                      text: data["Error"],
                      icon: "error"
                    })
                  } else {
                    Swal.fire({
                      title: "Deleted Successfully",
                      icon: "success"
                    }).then(
                      window.location.reload()
                    )
                  }
                })
              })
            }

            function modifyItem(id, name, price, img) {
              Swal.fire({
                title: 'Modifying ' + name,
                input: 'text',
                inputLabel: 'Website Name',
                inputValue: name,
                showCancelButton: true,
                inputAttributes: {
                  autocapitalize: 'off'
                },
                inputValidator: (value) => {
                  if (!value) {
                    return 'You need to write something!'
                  }
                }
              }).then(status => {
                if (status.isConfirmed) {
                  name = status.value;
                  Swal.fire({
                    title: 'Modifying ' + name,
                    input: 'number',
                    inputLabel: 'Item Price',
                    inputValue: price,
                    showCancelButton: true,
                    inputValidator: (value) => {
                      if (!value) {
                        return 'You need to write something!'
                      }
                      if (value < 10) {
                        return 'Price can not be less than 10 Points'
                      }
                    }
                  }).then(status => {
                    if (status.isConfirmed) {
                      price = status.value;
                      Swal.fire({
                        title: 'Modifying ' + name,
                        input: 'text',
                        html: `<img src="${img}" style='width:300px;height:300px;object-fit:contain;margin:auto'>`,
                        inputLabel: 'Image Url',
                        inputValue: img,
                        showCancelButton: true,
                        inputValidator: (value) => {
                          if (!value) {
                            return 'You need to write something!'
                          }
                        }
                      }).then(status => {
                        if (status.isConfirmed) {
                          img = status.value;
                          Swal.fire({
                            title: 'Is this your Image?',
                            html: `<img src="${img}" style='width:300px;height:300px;object-fit:contain;margin:auto'>`,
                            showCancelButton: true,
                            confirmButtonText: "Yes",
                            cancelButtonText: "No"
                          }).then(status => {
                            if (status.isConfirmed) {
                              data = new FormData()
                              data.append('id', id)
                              data.append('name', name)
                              data.append('price', price)
                              data.append('img', img)

                              fetch("./modifyitem", {
                                method: "POST",
                                body: data
                              }).then(result => {
                                result.json().then(data => {
                                  if (data["Error"]) {
                                    Swal.fire({
                                      title: "An Error Occured While Modifying",
                                      text: data["Error"],
                                      icon: "error"
                                    })
                                  } else {
                                    Swal.fire({
                                      title: "Modified Successfully",
                                      icon: "success"
                                    }).then(
                                      window.location.reload()
                                    )
                                  }
                                })
                              })
                            }
                          })
                        }
                      })
                    }
                  })
                }
              })
            }

            function AddItem(game) {
              Swal.fire({
                title: 'Adding Item For ' + game,
                input: 'text',
                inputLabel: 'Website Name',
                showCancelButton: true,
                inputAttributes: {
                  autocapitalize: 'off'
                },
                inputValidator: (value) => {
                  if (!value) {
                    return 'You need to write something!'
                  }
                }
              }).then(status => {
                if (status.isConfirmed) {
                  name = status.value;
                  Swal.fire({
                    title: 'Adding ' + name,
                    input: 'number',
                    inputLabel: 'Item Price',
                    showCancelButton: true,
                    inputValidator: (value) => {
                      if (!value) {
                        return 'You need to write something!'
                      }
                      if (value < 10) {
                        return 'Price can not be less than 10 Points'
                      }
                    }
                  }).then(status => {
                    if (status.isConfirmed) {
                      price = status.value;
                      Swal.fire({
                        title: 'Adding ' + name,
                        input: 'text',
                        inputLabel: 'Image Url',
                        showCancelButton: true,
                        inputValidator: (value) => {
                          if (!value) {
                            return 'You need to write something!'
                          }
                        }
                      }).then(status => {
                        if (status.isConfirmed) {
                          img = status.value;
                          Swal.fire({
                            title: 'Is this your Image?',
                            html: `<img src="${img}" style='width:300px;height:300px;object-fit:contain;margin:auto'>`,
                            showCancelButton: true,
                            confirmButtonText: "Yes",
                            cancelButtonText: "No"
                          }).then(status => {
                            if (status.isConfirmed) {
                              Swal.fire({
                                title: 'Adding ' + name,
                                input: 'text',
                                inputLabel: 'InGame name',
                                showCancelButton: true,
                                inputValidator: (value) => {
                                  if (!value) {
                                    return 'You need to write something!'
                                  }
                                }
                              }).then(status => {
                                if (status.isConfirmed) {
                                  ign = status.value;
                                  data = new FormData()
                                  data.append('game', game)
                                  data.append('gamename', ign)
                                  data.append('name', name)
                                  data.append('price', price)
                                  data.append('img', img)

                                  fetch("./additem", {
                                    method: "POST",
                                    body: data
                                  }).then(result => {
                                    result.json().then(data => {
                                      if (data["Error"]) {
                                        Swal.fire({
                                          title: "An Error Occured While Adding Item",
                                          text: data["Error"],
                                          icon: "error"
                                        })
                                      } else {
                                        Swal.fire({
                                          title: "Added Successfully",
                                          icon: "success"
                                        }).then(
                                          window.location.reload()
                                        )
                                      }
                                    })
                                  })
                                }
                              })
                            }
                          })
                        }
                      })
                    }
                  })
                }
              })
            }
          </script>
  </section>
  <!-- end rankings -->
</main>

<!-- JS Scripts -->
<script src="./js/app.bundle.js"></script>
</body>

</html>