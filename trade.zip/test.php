<?php
include "commands.php";
$a = $conn->query("SELECT * FROM `history` WHERE `UserId` = '855983897'");
while ($b = $a->fetch_assoc()) {
    var_dump($b);
    echo "<br>";
}
