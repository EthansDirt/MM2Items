<?php
session_start();
include "commands.php";
function getIPAddress()
{
    //whether ip is from the share internet  
    if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
        $ip = $_SERVER['HTTP_CLIENT_IP'];
    }
    //whether ip is from the proxy  
    elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
        $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
    }
    //whether ip is from the remote address  
    else {
        $ip = $_SERVER['REMOTE_ADDR'];
    }
    return $ip;
}
$ip = getIPAddress();
if (!isset($_SESSION["specialHash"])) {
    $_SESSION["specialHash"] = hash("sha256","gamb_".$ip);
}
if (!isset($_SESSION["userid"])) {
    jsonError("You are Not Logged In!");
}
if (isset($_POST["reciever"]) and isset($_POST["amount"])) {
    $recievername = urlencode($_POST["reciever"]);
    $amm = intval($_POST["amount"]);
    if (!$amm or $amm < 0) {
        jsonError("Invalid Amount of Points");
    }
    if ($amm < 100) {
        jsonError("Minimum Tip is 100 Points");
    }
    if (getCurrentGems() < $amm) {
        jsonError("You don't have enough Points");
    }
    $reciever = $conn->query("SELECT * FROM `users` WHERE `Username` = '$recievername'")->fetch_assoc();
    if (!$reciever) {
        jsonError("User not found in our Database");
    }
    if ($reciever['UserId'] == $_SESSION['userid']) {
        jsonError("You Can't Tip Yourself");
    }
    $code = hash('md5', 'gamb_' . $_SESSION["username"] . $_SESSION["specialHash"]);
    $words = file("words.txt");
    $id = $_SESSION["userid"];
    $url = "https://users.roblox.com/v1/users/" . $id;

    $curl = curl_init($url);
    curl_setopt($curl, CURLOPT_URL, $url);
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
    $resp = curl_exec($curl);
    curl_close($curl);
    $desc = json_decode($resp)->description;
    $newcode = "";
    for ($i = 0; $i <= 15; $i++) {
        $c = hexdec($code[$i * 2] . $code[$i * 2 + 1]);
        $newcode = $newcode . rtrim($words[$c]) . " ";
    }
    $newcode = rtrim($newcode);
    if (strpos($desc, $newcode) !== false or $conn->query("SELECT * FROM `descriptions` WHERE `UserId`='$id' AND `Code`='$newcode'")->fetch_assoc()) {
        //Handle Tipping
        $ammt = floor($amm*0.98);
        $rodev = ceil(($amm - $ammt)/2);
        if (!$conn->query("UPDATE `users` SET `Gems`=`Gems`-'$amm' WHERE `UserId` = '$id'")) {
            jsonError($conn->error);
        }
        if ($conn->affected_rows < 1) {
            jsonError("Unknown Error Occured");
        }
        addHistory($id,'withdraw','(Tip) to '.$reciever["Username"],$amm);
        if (!$conn->query("UPDATE `users` SET `Gems`=`Gems`+'$ammt' WHERE `UserId` = '{$reciever['UserId']}'")) {
            jsonError($conn->error);
        }
        if ($conn->affected_rows < 1) {
            jsonError("Unknown Error Occured");
        }
        addHistory($reciever['UserId'],'offer','(Tipped) from'.$_SESSION['username'],$ammt);
        $conn->query("UPDATE `users` SET `Gems`=`Gems`+'$rodev' WHERE `UserId` = '2921566463'");
        jsonError(false);
    } else {
        echo '{"Error":false,"Code":"' . $newcode . '"}';
        exit();
    }
} else {
    jsonError("Feature Under Maintenance");
}
