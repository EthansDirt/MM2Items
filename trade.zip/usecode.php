<?php
session_start();
if (!isset($_SESSION["userid"])) {
    jsonError("You are Not Logged In!");
}
include "commands.php";
if (isset($_POST["code"])) {
    $codes = getCodes();
    if (array_key_exists($_POST["code"], $codes)) {
        $code = $codes[$_POST["code"]];
        if (in_array($_POST["code"], getCurrentClaimedCodes())) {
            jsonError("You have already claimed this code!");
        }
        if (($code["Used"] >= $code["Uses"]) and !($code["Uses"] == -1)) {
            jsonError("Code has Expired!");
        }
        addCurrentGems($code["Reward"]);
        addCurrentHistory("code", NULL, $code["Reward"]);
        addCurrentClaimedCodes($_POST["code"]);
        echo '{"Error":false,"Message":"Successfully Claimed ' . number_format($code["Reward"]) . ' Points!"}';
        exit();
    } else {
        jsonError("Code Does Not Exist");
    }
} else {
    jsonError("Feature Under Maintenance!");
}
