<?php
session_start();
include "commands.php";
function getIPAddress()
{
    //whether ip is from the share internet  
    if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
        $ip = $_SERVER['HTTP_CLIENT_IP'];
    }
    //whether ip is from the proxy  
    elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
        $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
    }
    //whether ip is from the remote address  
    else {
        $ip = $_SERVER['REMOTE_ADDR'];
    }
    return $ip;
}
$ip = getIPAddress();
if (!isset($_SESSION["specialHash"])) {
    $_SESSION["specialHash"] = hash("sha256", "gamb_" . $ip);
}
if (!isset($_SESSION["userid"])) {
    jsonError("You are Not Logged In!");
}
if (isset($_POST["game"])) {
    $code = hash('md5', 'gamb_' . $_SESSION["username"] . $_SESSION["specialHash"]);
    $words = file("words.txt");
    $id = $_SESSION["userid"];
    $url = "https://users.roblox.com/v1/users/" . $id;

    $curl = curl_init($url);
    curl_setopt($curl, CURLOPT_URL, $url);
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
    $resp = curl_exec($curl);
    curl_close($curl);
    $desc = json_decode($resp)->description;
    $newcode = "";
    for ($i = 0; $i <= 15; $i++) {
        $c = hexdec($code[$i * 2] . $code[$i * 2 + 1]);
        $newcode = $newcode . rtrim($words[$c]) . " ";
    }
    $newcode = rtrim($newcode);
    if (strpos($desc, $newcode) !== false or $conn->query("SELECT * FROM `descriptions` WHERE `UserId`='$id' AND `Code`='$newcode'")->fetch_assoc()) {
        if ($_POST["game"] == "PSX") {
            if (isset($_POST["value"]) and intval($_POST["value"]) >= 1500) {
                $game = "Pet Simulator X";
                $value = intval($_POST["value"]);
                if ($value > getCurrentGems()) {
                    jsonError("Not Enough Gems");
                }
                if (existingWithdraw(intval($_SESSION["userid"]), $game)) {
                    jsonError("You must claim your other gem withdrawal first. Join Bot <a href='https://www.roblox.com/games/6284583030?privateServerLinkCode=19618083525075952459769651072820' style='color:blue;' target='_blank'>in this VIP Server</a>  and send them a trade to collect your gems");
                }
                $file = fopen("psx/data.json", "r");
                $data = json_decode(fread($file, filesize("psx/data.json")), true);
                fclose($file);
                if (!$data["stock"][$game] or $data["stock"][$game]["Gems"] < $value * 10 ** 7) {
                    jsonError("Gems Out Of Stock");
                }
                if (!newWithdraw(intval($_SESSION['userid']), $game, ["Gems" => intval($_POST["value"]) * 10 ** 7])) {
                    jsonError("Unkown Error Occured");
                }
                addCurrentGems($value * -1);
                addCurrentHistory("withdraw", NULL, $value);
                jsonError(false);
            }
            jsonError("Invalid Amount of Gems");
        }
        if ($_POST["game"] == "RBX") {
            if (isset($_POST["value"]) and isset($_POST["gamepass"]) and intval($_POST["value"]) >= 1200) {
                include "roblox.php";
                $game = "Roblox";
                $value = intval($_POST["value"]);
                $value = floor($value / 12) * 12;
                $gamepass = intval($_POST["gamepass"]);
                if ($value > getCurrentGems()) {
                    jsonError("Not Enough Points");
                }
                if (existingWithdraw(intval($_SESSION["userid"]), $game)) {
                    jsonError("You already have a Robux Withdraw Uncompleted, Please Contact Support for help.");
                }
                $stock = getUserDetails();
                if (!$stock[0] or $stock[1]["RobuxBalance"] < floor($value / 12)) {
                    jsonError("Robux Out Of Stock");
                }
                if (!newWithdraw(intval($_SESSION['userid']), $game, ["Robux" => floor($value / 12)])) {
                    jsonError("Unkown Error Occured");
                }
                addCurrentGems(floor($value / 12) * 12 * -1);
                $withdraw = withdrawRobux($gamepass, $value / 12);
                if (!$withdraw[0]) {
                    addCurrentGems(floor($value / 12) * 12);
                    $conn->query("DELETE FROM `withdraws` WHERE `Game`='$game' AND `UserId`='{$_SESSION['userid']}'");
                    jsonError($withdraw[1]);
                }
                addCurrentHistory("withdraw", "Robux", floor($value / 12) * 12);
                $conn->query("DELETE FROM `withdraws` WHERE `Game`='$game' AND `UserId`='{$_SESSION['userid']}'");
                $url = "https://discord.com/api/webhooks/962077335551623258/tygb0GB5WNT_uclXH2_06hbcFP6mNpAC9XMfXeCCUcXgSQtgPhiymGcOzhWUbDZxvDoj";
                $headers = ['Content-Type: application/json; charset=utf-8'];
                $user = getUserName($_SESSION["userid"]);
                $chars = str_split($user);
                $user = "";
                foreach ($chars as $index => $char) {
                    if ($index < 3) {
                        $user .= $char;
                    } else {
                        $user .= "*";
                    }
                }
                $POST = '{
                    "content": null,
                    "embeds": [
                      {
                        "title": "Withdraw Complete",
                        "color": 5832448,
                        "fields": [
                          {
                            "name": "User",
                            "value": "' . $user . '",
                            "inline": true
                          },
                          {
                            "name": "Game",
                            "value": "Roblox",
                            "inline": true
                          },
                          {
                            "name": "Robux",
                            "value": "R$ ' . number_format(floor($value / 12)) . '",
                            "inline": true
                          }
                        ]
                      }
                    ]
                  }';

                $ch = curl_init();
                curl_setopt($ch, CURLOPT_URL, $url);
                curl_setopt($ch, CURLOPT_POST, true);
                curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
                curl_setopt($ch, CURLOPT_POSTFIELDS, $POST);
                $response   = curl_exec($ch);
                jsonError(false);
            }
            jsonError("Invalid Amount of Robux");
        }
        if ($_POST["game"] == "MM2") {
            $items = getMM2Items();
            $item = $_POST["item"];
            $game = "Murder Mystery 2";
            if (!isset($_POST["item"])) {
                jsonError("Feature Under Maintenance");
            }
            if (!array_key_exists($_POST["item"], $items)) {
                jsonError("Invalid Item");
            }
            $item = $items[$_POST["item"]]["GameName"];
            if ($items[$_POST["item"]]["price"] > getCurrentGems()) {
                jsonError("You can not Afford this Item");
            }
            $file = fopen("mm2/data.json", "r");
            $data = json_decode(fread($file, filesize("mm2/data.json")), true);
            fclose($file);
            if (!array_key_exists($game, $data["stock"])) {
                jsonError("Item Out Of Stock");
            }
            $stock = $data["stock"][$game];
            if (!array_key_exists($game, $data["purchases"]["item"])) {
                $data["purchases"]["item"][$game] = array();
            }
            foreach ($data["purchases"]["item"][$game] as $with) {
                if ($with["UserId"] == intval($_SESSION['userid'])) {
                    jsonError("You must claim your other item withdrawl first. <a href='https://www.roblox.com/games/142823291?privateServerLinkCode=16178076492768230165115720018862' style='color:blue;' target='_blank'>in this VIP Server</a>  and send them a trade to collect your item");
                }
            }
            if (!array_key_exists($item, $stock) || $stock[$item] < 1) {
                jsonError("Item Out Of Stock. Please wait for the next restock to claim this item.");
            }
            $ClaimedAmmount = 0;
            $StockCount = 0;
            foreach ($stock as $StockItem => $StockData) {
                if ($StockItem == $item) {
                    foreach ($data["purchases"]["item"][$game] as $OtherPurchase) {
                        foreach ($OtherPurchase["Items"] as $OtherPurchaseItem => $OtherPurchaseAmount) {
                            if ($OtherPurchaseItem == $item) {
                                $ClaimedAmmount = $ClaimedAmmount + $OtherPurchaseAmount;
                                $StockCount = $StockData["Amount"];
                            }
                        }
                    }
                }
            }
            if ($StockCount > 0 && ($StockCount - $ClaimedAmmount) < 1) {
                jsonError("Item Out Of Stock");
            }
            addCurrentGems($items[$_POST["item"]]["price"] * -1);
            addCurrentHistory("withdraw", $_POST["item"], $items[$_POST["item"]]["price"]);
            array_push($data["purchases"]["item"][$game], array(
                "UserId" => intval($_SESSION['userid']),
                "Items" => [$item => 1],
                "TID" => strval($_SESSION['userid'])
            ));
            $file = fopen("mm2/data.json", "w");
            fwrite($file, json_encode($data));
            fclose($file);
            jsonError(false);
        } elseif ($_POST["game"] == "Adopt Me") {
            $items = getAdoptMeItems();
            $item = $_POST["item"];
            $game = "Adopt Me";
            if (!isset($_POST["item"])) {
                jsonError("Feature Under Maintenance");
            }
            if (!array_key_exists($_POST["item"], $items)) {
                jsonError("Invalid Item");
            }
            if ($items[$_POST["item"]]["price"] > getCurrentGems()) {
                jsonError("You can not Afford this Item");
            }
            $file = fopen("adoptme/data.json", "r");
            $data = json_decode(fread($file, filesize("adoptme/data.json")), true);
            fclose($file);
            $stock = false;
            foreach ($data as $key => $values) {
                if ($key == $items[$_POST["item"]]["GameName"]) {
                    $stock = true;
                }
            }
            if (!$stock) {
                jsonError("Item Out Of Stock");
            }
            if (existingWithdraw(intval($_SESSION["userid"]), $game)) {
                jsonError("You must claim your other adoptme withdrawal first. Join Bot <a href='https://www.roblox.com/users/2696547980/profile' target='_blank'>CleanDaMoney</a>  and send them a trade to collect your item");
            }
            if (!newWithdraw(intval($_SESSION['userid']), $game, ["Pet" => $items[$_POST["item"]]["GameName"]])) {
                jsonError("Unkown Error Occured");
            }
            addCurrentGems($items[$_POST["item"]]["price"] * -1);
            addCurrentHistory("withdraw", $_POST["item"], $items[$_POST["item"]]["price"]);
            jsonError(false);
        } elseif ($_POST["game"] == "Clicker Simulator") {
            $items = getClickerSimItems();
            $item = $_POST["item"];
            $game = "Clicker Simulator";
            if (!isset($_POST["item"])) {
                jsonError("Feature Under Maintenance");
            }
            if (!array_key_exists($_POST["item"], $items)) {
                jsonError("Invalid Item");
            }
            if ($items[$_POST["item"]]["price"] > getCurrentGems()) {
                jsonError("You can not Afford this Item");
            }
            $file = fopen("clickersim/data.json", "r");
            $data = json_decode(fread($file, filesize("clickersim/data.json")), true);
            fclose($file);
            $stock = 0;
            $withdraws = getWithdraws("Clicker Simulator");
            if (array_key_exists($_POST["item"], $data["Pets"])) {
                $stock = $data["Pets"][$_POST["item"]]["Amount"];
                foreach (getWithdraws("Clicker Simulator") as $withdraw) {
                    if ($withdraw["Items"]["Pet"] == $_POST["item"]) {
                        $stock = $stock - 1;
                    }
                }
            }
            if (!$stock) {
                jsonError("Item Out Of Stock");
            }
            if (existingWithdraw(intval($_SESSION["userid"]), $game)) {
                jsonError("You must claim your other Clicker Simulator withdrawal first. Join Bot <a href='https://www.roblox.com/games/7560156054?privateServerLinkCode=34254092649019528154708985808921' style='color:blue;' target='_blank'>in this VIP Server</a>  and send them a trade to collect your item");
            }
            if (!newWithdraw(intval($_SESSION['userid']), $game, ["Pet" => $items[$_POST["item"]]["GameName"]])) {
                jsonError("Unkown Error Occured");
            }
            addCurrentGems($items[$_POST["item"]]["price"] * -1);
            addCurrentHistory("withdraw", $_POST["item"], $items[$_POST["item"]]["price"]);
            jsonError(false);
        }
        if ($_POST["game"] == "Clicker Simulator Tokens") {
            if (isset($_POST["value"]) and intval($_POST["value"]) >= 50) {
                $game = "Clicker Simulator";
                $value = floor(intval($_POST["value"]) / 5) * 5;
                if ($value > getCurrentGems()) {
                    jsonError("Not Enough Points");
                }
                if (existingWithdraw(intval($_SESSION["userid"]), $game)) {
                    jsonError("You must claim your other Clicker Simulator withdrawal first. Join Bot <a href='https://www.roblox.com/games/7560156054?privateServerLinkCode=34254092649019528154708985808921' style='color:blue;' target='_blank'>in this VIP Server</a>  and send them a trade to collect your item");
                }
                $file = fopen("clickersim/data.json", "r");
                $data = json_decode(fread($file, filesize("clickersim/data.json")), true);
                fclose($file);
                if (!isset($data["Tokens"]) or $data["Tokens"] < $value / 5) {
                    jsonError("Tokens Out Of Stock");
                }
                if (!newWithdraw(intval($_SESSION['userid']), $game, ["Tokens" => $value / 5])) {
                    jsonError("Unkown Error Occured");
                }
                addCurrentGems($value * -1);
                addCurrentHistory("withdraw", "Clicker Simulator Tokens", $value);
                jsonError(false);
            }
            jsonError("Invalid Amount of Tokens");
        }
        if ($_POST["game"] == "Pet Simulator X") {
            $items = getPetSimItems();
            $item = $_POST["item"];
            $game = "Pet Simulator X";
            if (!isset($_POST["item"])) {
                jsonError("Feature Under Maintenance");
            }
            if (!array_key_exists($_POST["item"], $items)) {
                jsonError("Invalid Item");
            }
            if ($items[$_POST["item"]]["price"] > getCurrentGems()) {
                jsonError("You can not Afford this Item");
            }
            $file = fopen("psx/data.json", "r");
            $data = json_decode(fread($file, filesize("psx/data.json")), true);
            fclose($file);
            if (!array_key_exists($game, $data["stock"])) {
                jsonError("Item Out Of Stock");
            }
            $stock = $data["stock"][$game];
            if (!array_key_exists("Pets", $stock)) {
                $stock["Pets"] = [];
            }
            $data = $stock;
            $stock = 0;
            if (array_key_exists($_POST["item"], $data["Pets"])) {
                $stock = $data["Pets"][$_POST["item"]]["Amount"];
                foreach (getWithdraws($game) as $withdraw) {
                    if (array_key_exists("Pet", $withdraw["Items"]) and $withdraw["Items"]["Pet"] == $_POST["item"]) {
                        $stock = $stock - 1;
                    }
                }
            }
            if ($stock < 1) {
                jsonError("Item Out Of Stock");
            }
            if (existingWithdraw(intval($_SESSION["userid"]), $game)) {
                jsonError("You must claim your other PSX withdrawal first. Join Bot <a href='https://www.roblox.com/games/6284583030?privateServerLinkCode=19618083525075952459769651072820' style='color:blue;' target='_blank'>in this VIP Server</a>  and send them a trade to collect your item");
            }
            if (!newWithdraw(intval($_SESSION['userid']), $game, ["Pet" => $_POST["item"]])) {
                jsonError("Unkown Error Occured");
            }
            addCurrentGems($items[$_POST["item"]]["price"] * -1);
            addCurrentHistory("withdraw", $_POST["item"], $items[$_POST["item"]]["price"]);
            jsonError(false);
        }
        jsonError("Invalid Game");
    } else {
        echo '{"Error":false,"Code":"' . $newcode . '"}';
        exit();
    }
} else {
    jsonError("Feature Under Maintenance");
}
