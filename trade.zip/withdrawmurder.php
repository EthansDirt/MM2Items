<?php
session_start();
if (!isset($_SESSION["userid"])) {
  echo "<script type='text/javascript'>window.top.location='./';</script>";
  exit();
}
$title = "Murder Mystery 2";
require_once("header.php");
?>

<main class="pt-[5.5rem] lg:pt-24">
  <!-- Banner -->
  <div class="relative"> <img src="img/banner.png" alt="banner" class="h-[18.75rem] object-cover" /> </div>
  <!-- end banner -->
  <!-- Profile -->
  <section class="dark:bg-jacarta-800 bg-light-base relative pb-12 pt-28">
    <!-- Avatar -->
    <div class="absolute left-1/2 top-0 z-10 flex -translate-x-1/2 -translate-y-1/2 items-center justify-center">
      <figure class="relative"> <img src="img/avatar.png" alt="collection avatar" class="dark:border-jacarta-600 rounded-xl border-[5px] border-white" /> </figure>
    </div>
    <div class="container">
      <div class="text-center">
        <h2 class="font-display text-jacarta-700 mb-2 text-4xl font-medium dark:text-white"> Murder Mystery 2</h2>
        <p class="dark:text-jacarta-300 mx-auto max-w-xl text-lg"> Earn points by completing offers then Withdraw them to Murder Mystery 2 items Fast & Safely. Join Our Bot <a href='https://www.roblox.com/games/142823291?privateServerLinkCode=16178076492768230165115720018862' style='color:blue;' target='_blank'>in this VIP Server</a> to Claim</p>
      </div>
    </div>
  </section>
  <!-- end profile -->
  <!-- Collection -->
  <section class="relative py-24">
    <picture class="pointer-events-none absolute inset-0 -z-10 dark:hidden"> <img src="img/gradient_light.jpg" alt="gradient" class="h-full w-full" /> </picture>
    <div class="container">
      <!-- Grid -->
      <?php
      if (getBotsData()["MM2"]) {
        echo '<div class="grid grid-cols-1 gap-[1.875rem] md:grid-cols-2 lg:grid-cols-4">';
        $file = fopen("mm2/data.json", "r");
        $game = "Murder Mystery 2";
        $data = json_decode(fread($file, filesize("mm2/data.json")), true);
        fclose($file);
        if (!array_key_exists($game, $data["stock"])) {
          $data["stock"][$game] = [];
        }
        $stock = $data["stock"][$game];
        if (!array_key_exists($game, $data["purchases"]["item"])) {
          $data["purchases"]["item"][$game] = array();
        }
        foreach (getMM2Items() as $item => $values) {
          if (!array_key_exists($values["GameName"], $stock) || $stock[$values["GameName"]] < 1) {
            $s = 0;
          } else {
            $ClaimedAmmount = 0;
            $StockCount = $stock[$values["GameName"]]["Amount"];
            foreach ($data["purchases"]["item"][$game] as $OtherPurchase) {
              foreach ($OtherPurchase["Items"] as $OtherPurchaseItem => $OtherPurchaseAmount) {
                if ($OtherPurchaseItem == $values["GameName"]) {
                  $ClaimedAmmount = $ClaimedAmmount + $OtherPurchaseAmount;
                }
              }
            }
            $s = $StockCount - $ClaimedAmmount;
          }
          $values["price"] = number_format($values["price"]);
          echo "<article>
          <div class='dark:bg-jacarta-700 dark:border-jacarta-700 border-jacarta-100 block rounded-[1.25rem] border bg-white p-[1.1875rem] transition-shadow hover:shadow-lg'>
              <figure class='relative'>
                  <img src='{$values['img']}' alt='$item' style='aspect-ratio:93/109;' class='w-full rounded-[0.625rem]' loading='lazy' /> </a>
                  <div class='absolute left-3 -bottom-3'>
                      <div class='flex -space-x-2'> </div>
                  </div>
              </figure>
              <div class='mt-4 flex items-center text-center justify-center'>
                  <span class='font-display text-jacarta-700 hover:text-accent dark:text-white text-center'>$item</span>
                  <div class='dark:hover:bg-jacarta-600 dropup hover:bg-jacarta-100 rounded-full'> </div>
              </div>
              <div class=' flex  justify-center'>
                  <span style='position: relative;top: -6px;'>{$values['price']} Points</span>
              </div>
              <div class=' flex  justify-center'>
                  <span style='position: relative;top: -6px;'>Stock: $s</span>
              </div>
              <div class='mt-0 flex items-center justify-center'>
                  <a href='javascript:void(0)' onclick='buy(\"$item\")' class='group flex justify-center'> <span class='group-hover:text-accent font-display dark:text-jacarta-200 text-L font-semibold '>Buy
                      now</span></a>
              </div>
          </div>
      </article>";
        }
        echo "</div>";
      } else {
        echo "<center><h2 class='text-4xl dark:text-white'>Bot Offline</h2></center>";
      }
      ?>
    </div>
  </section>
</main>
<!-- JS Scripts -->
<script>
  function buy(item) {
    data = new FormData()
    data.append("game", "MM2")
    data.append("item", item)
    wdata = data
    fetch("withdraw", {
      method: "POST",
      body: data
    }).then(result => {
      result.json().then(data => {
        if (data["Error"]) {
          Swal.fire({
            title: "Error Occured",
            html: data["Error"],
            icon: "error"
          })
        } else {
          if (data["Code"]) {
            Swal.fire({
              title: `Lets verify it's you`,
              icon: 'info',
              html: `Add "${data["Code"]}" in your account Description or in <a href="https://www.roblox.com/games/9279369615" target="_blank">This Game</a>`,
              confirmButtonText: 'Done',
              showCancelButton: true,
              showLoaderOnConfirm: true,
              preConfirm: () => {
                return fetch("withdraw", {
                    method: "POST",
                    body: wdata
                  })
                  .then(response => {
                    return response.json()
                  })
                  .catch(error => {
                    Swal.showValidationMessage(
                      `Request failed: ${error}`
                    )
                  })
              },
              allowOutsideClick: () => !Swal.isLoading()
            }).then((result) => {
              if (result.isConfirmed) {
                if (result.value.Error) {
                  Swal.fire({
                    title: `${result.value.Error}`,
                    icon: 'error'
                  })
                } else {
                  if (result.value.Code) {
                    Swal.fire({
                      title: `Failed To Find Code in your Description or Game, Try again.`,
                      icon: 'error'
                    })
                  } else {
                    Swal.fire({
                      title: "Withdraw Initiated",
                      html: "Please join our ROBLOX Bot <a href='https://www.roblox.com/games/142823291?privateServerLinkCode=16178076492768230165115720018862' style='color:blue;' target='_blank'>in this VIP Server</a>  and send them a trade to collect your items",
                      icon: "success"
                    }).then(() => {
                      window.top.location = '';
                    })
                  }
                }
              }
            })
          } else {
            Swal.fire({
              title: "Withdraw Initiated",
              html: "Please join our ROBLOX Bot <a href='https://www.roblox.com/games/142823291?privateServerLinkCode=16178076492768230165115720018862' style='color:blue;' target='_blank'>in this VIP Server</a>  and send them a trade to collect your items",
              icon: "success"
            }).then(() => {
              window.top.location = '';
            })
          }
        }
      })
    })
  }
</script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/3.7.0/chart.min.js"></script>
<script src="./js/app.bundle.js"></script>
<script src="./js/charts.bundle.js"></script>
</body>

</html>