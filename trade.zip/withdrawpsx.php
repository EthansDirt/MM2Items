<?php
session_start();
if (!isset($_SESSION["userid"])) {
  echo "<script type='text/javascript'>window.top.location='./';</script>";
  exit();
}
$title = "PSX Gems";
require_once("header.php");
?>
<main class="pt-[5.5rem] lg:pt-24">
  <!-- Banner -->
  <div class="relative">
    <img src="img/banner.png" alt="banner" class="h-[18.75rem] object-cover" />
  </div>
  <!-- end banner -->

  <!-- Profile -->
  <section class="dark:bg-jacarta-800 bg-light-base relative pb-12 pt-28">
    <!-- Avatar -->
    <div class="absolute left-1/2 top-0 z-10 flex -translate-x-1/2 -translate-y-1/2 items-center justify-center">
      <figure class="relative">
        <img src="img/avatarpsx.png" alt="collection avatar" class="dark:border-jacarta-600 rounded-xl border-[5px] border-white" />

      </figure>
    </div>

    <div class="container">
      <div class="text-center">
        <h2 class="font-display text-jacarta-700 mb-2 text-4xl font-medium dark:text-white"> PSX Gems</h2>
      </div>

      <section class="dark:bg-jacarta-800 relative py-24">
        <picture class="pointer-events-none absolute inset-0 -z-10 dark:hidden">
          <img src="img/gradient_light.jpg" alt="gradient" class="h-full w-full" />
        </picture>
        <div class="container">
          <div class="lg:flex">
            <!-- Contact Form -->
            <div class="mb-12 lg:mb-0 lg:w-2/3 lg:pr-12">
              <h2 class="font-display text-jacarta-700 mb-4 text-xl dark:text-white">Pet Simulator X Gems</h2>
              <p class="dark:text-jacarta-300 mb-16 text-lg leading-normal">
                PSX Gems can be used for trading & buying items inside the game. It is the main currency for Pet Trading! </p>
              <form id="contact-form" action="javascript:void(0)" onsubmit="withDraw()">
                <div class="flex space-x-7">
                  <div class="mb-6 w-1/2">
                    <label for="name" class="font-display text-jacarta-700 mb-1 block text-sm dark:text-white">Gems<span class="text-red"></span></label>
                    <input id='ammount' name="name" class="contact-form-input dark:bg-jacarta-700 border-jacarta-100 hover:ring-accent/10 focus:ring-accent dark:border-jacarta-600 dark:placeholder:text-jacarta-300 w-full rounded-lg py-3 hover:ring-2 dark:text-white" type="number" min="10000000" step="1000000" max="<?php echo getCurrentGems() * 1000000 ?>" required />
                  </div>

                  <div class="mb-6 w-1/2">
                    <label for="" class="font-display text-jacarta-700 mb-1 block text-sm dark:text-white">Points<span class="text-red"></span></label>
                    <input id='points' name="result" class="contact-form-input dark:bg-jacarta-700 border-jacarta-100 hover:ring-accent/10 focus:ring-accent dark:border-jacarta-600 dark:placeholder:text-jacarta-300 w-full rounded-lg py-3 hover:ring-2 dark:text-white" type="number" disabled />
                  </div>
                </div>



                <div class="mb-6 flex items-center space-x-2">
                  <!--<input type="checkbox" id="contact-form-consent-input" name="agree-to-terms" class="checked:bg-accent dark:bg-jacarta-600 text-accent border-jacarta-200 focus:ring-accent/20 dark:border-jacarta-500 h-5 w-5 self-start rounded focus:ring-offset-0" />-->
                  <label for="contact-form-consent-input" class="dark:text-jacarta-200 text-sm">Trades will be split in 20 Billion Chunks</label>
                </div>
                <?php
                    if (getBotsData()["PSX"]) :
                ?>
                <button type="submit" class="bg-accent shadow-accent-volume hover:bg-accent-dark rounded-full py-3 px-8 text-center font-semibold text-white transition-all" id="contact-form-submit">
                  Withdraw
                </button>
                <?php else: ?>
                  <button type="submit" disabled class="shadow-accent-volume rounded-full py-3 px-8 text-center font-semibold dark:text-white transition-all" id="contact-form-submit">
                  Bot Off
                </button>
                <?php endif; ?>

                <div id="contact-form-notice" class="relative mt-4 hidden rounded-lg border border-transparent p-4"></div>
              </form>
            </div>

            <!-- Info -->
            <div class="lg:w-1/3 lg:pl-5">
              <br>

              <div class="dark:bg-jacarta-700 dark:border-jacarta-600 border-jacarta-100 rounded-[1.25rem] border bg-white p-10">
                <div class="mb-6 flex items-center space-x-5">
                  <span class="dark:bg-jacarta-700 dark:border-jacarta-600 border-jacarta-100 bg-light-base flex h-11 w-11 shrink-0 items-center justify-center rounded-full border">
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-arrow-left-right" viewBox="0 0 16 16">
                      <path fill-rule="evenodd" d="M1 11.5a.5.5 0 0 0 .5.5h11.793l-3.147 3.146a.5.5 0 0 0 .708.708l4-4a.5.5 0 0 0 0-.708l-4-4a.5.5 0 0 0-.708.708L13.293 11H1.5a.5.5 0 0 0-.5.5zm14-7a.5.5 0 0 1-.5.5H2.707l3.147 3.146a.5.5 0 1 1-.708.708l-4-4a.5.5 0 0 1 0-.708l4-4a.5.5 0 1 1 .708.708L2.707 4H14.5a.5.5 0 0 1 .5.5z" />
                    </svg>
                  </span>

                  <div>
                    <span class="font-display text-jacarta-700 block text-base dark:text-white"> <br>1 Point = 1 Million Gems</span>
                    <a class="hover:text-accent dark:text-jacarta-300 text-sm">Minimum Amount is 10 Points</a>
                  </div>
                </div>

                <div class="mb-6 flex items-center space-x-5">
                  <span class="dark:bg-jacarta-700 dark:border-jacarta-600 border-jacarta-100 bg-light-base flex h-11 w-11 shrink-0 items-center justify-center rounded-full border">
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-arrow-left-right" viewBox="0 0 16 16">
                      <path fill-rule="evenodd" d="M1 11.5a.5.5 0 0 0 .5.5h11.793l-3.147 3.146a.5.5 0 0 0 .708.708l4-4a.5.5 0 0 0 0-.708l-4-4a.5.5 0 0 0-.708.708L13.293 11H1.5a.5.5 0 0 0-.5.5zm14-7a.5.5 0 0 1-.5.5H2.707l3.147 3.146a.5.5 0 1 1-.708.708l-4-4a.5.5 0 0 1 0-.708l4-4a.5.5 0 1 1 .708.708L2.707 4H14.5a.5.5 0 0 1 .5.5z" />
                    </svg>
                  </span>

                  <div>
                    <?php
                    $file = fopen("psx/data.json", "r");
                    $data = json_decode(fread($file, filesize("psx/data.json")), true);
                    fclose($file);
                    $stock = 0;
                    if (array_key_exists("Pet Simulator X", $data["stock"])) {
                      $stock = $data["stock"]["Pet Simulator X"]["Gems"];
                    }
                    ?>
                    <span class="font-display text-jacarta-700 block text-base dark:text-white"> <br><?php echo number_format($stock); ?> Gems</span>
                    <a class="hover:text-accent dark:text-jacarta-300 text-sm">Current Stock</a>
                  </div>
                </div>

                <div class="flex items-center space-x-5">
                  <span class="dark:bg-jacarta-700 dark:border-jacarta-600 border-jacarta-100 bg-light-base flex h-11 w-11 shrink-0 items-center justify-center rounded-full border">
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-plus-circle-fill" viewBox="0 0 16 16">
                      <path d="M16 8A8 8 0 1 1 0 8a8 8 0 0 1 16 0zM8.5 4.5a.5.5 0 0 0-1 0v3h-3a.5.5 0 0 0 0 1h3v3a.5.5 0 0 0 1 0v-3h3a.5.5 0 0 0 0-1h-3v-3z" />
                    </svg>
                  </span>

                  <a href='https://www.roblox.com/games/6284583030?privateServerLinkCode=19618083525075952459769651072820'>
                    <?php
                    if (getBotsData()["PSX"]) :
                    ?>
                      <span class="font-display text-jacarta-700 block text-base dark:text-white" style='color:lime;'>Bot Online</span>
                    <?php else : ?>
                      <span class="font-display text-jacarta-700 block text-base dark:text-white" style='color:red;'>Bot Offline</span>
                    <?php endif; ?>
                    <span class="hover:text-accent dark:text-jacarta-300 text-sm not-italic">Join our Bot in game to withdraw</span>
                  </a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

    </div>
    </div>
  </section>
  <!-- end profile -->

  <!-- Collection -->
</main>

<script>
  function withDraw() {
    data = new FormData()
    data.append("game", "PSX")
    data.append("value", Math.floor(document.getElementById("ammount").value / (10 ** 6)))
    wdata = data
    fetch("withdraw", {
      method: "POST",
      body: data
    }).then(result => {
      result.json().then(data => {
        if (data["Error"]) {
          Swal.fire({
            title: "Error Occured",
            html: data["Error"],
            icon: "error"
          })
        } else {
          if (data["Code"]) {
            Swal.fire({
              title: `Lets verify it's you`,
              icon: 'info',
              html: `Add "${data["Code"]}" in your account Description or in <a href="https://www.roblox.com/games/9279369615" target="_blank">This Game</a>`,
              confirmButtonText: 'Done',
              showCancelButton: true,
              showLoaderOnConfirm: true,
              preConfirm: () => {
                return fetch("withdraw", {
                    method: "POST",
                    body: wdata
                  })
                  .then(response => {
                    return response.json()
                  })
                  .catch(error => {
                    Swal.showValidationMessage(
                      `Request failed: ${error}`
                    )
                  })
              },
              allowOutsideClick: () => !Swal.isLoading()
            }).then((result) => {
              if (result.isConfirmed) {
                if (result.value.Error) {
                  Swal.fire({
                    title: `${result.value.Error}`,
                    icon: 'error'
                  })
                } else {
                  if (result.value.Code) {
                    Swal.fire({
                      title: `Failed To Find Code in your Description or Game, Try again.`,
                      icon: 'error'
                    })
                  } else {
                    Swal.fire({
                      title: "Withdraw Initiated",
                      html: "Please join our ROBLOX Bot <a href='https://www.roblox.com/games/6284583030?privateServerLinkCode=19618083525075952459769651072820' style='color:blue;' target='_blank'>in this VIP Server</a>  and send them a trade to collect your gems. If withdrawing more than 20 Billion Gems, trades will be divided into 20B chunks. Please keep space for 20 billion. If there is an error just decline the trade and trade again, your gems are safe.",
                      icon: "success"
                    }).then(() => {
                      window.top.location = '';
                    })
                  }
                }
              }
            })
          } else {
            Swal.fire({
              title: "Withdraw Initiated",
              html: "Please join our ROBLOX Bot <a href='https://www.roblox.com/games/6284583030?privateServerLinkCode=19618083525075952459769651072820' style='color:blue;' target='_blank'>in this VIP Server</a>  and send them a trade to collect your gems. If withdrawing more than 20 Billion Gems, trades will be divided into 20B chunks. Please keep space for 20 billion. If there is an error just decline the trade and trade again, your gems are safe.",
              icon: "success"
            }).then(() => {
              window.top.location = '';
            })
          }
        }
      })
    })
  }
</script>
<script>
  function updateGemsThing(e) {
    document.getElementById("points").value = Math.floor(e.target.value / (10 ** 6))
  }
  document.getElementById("ammount").addEventListener("input", updateGemsThing);
</script>

<!-- JS Scripts -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/3.7.0/chart.min.js"></script>
<script src="./js/app.bundle.js"></script>
<script src="./js/charts.bundle.js"></script>
</body>

</html>